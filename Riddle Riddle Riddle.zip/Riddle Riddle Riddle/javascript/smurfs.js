var p = 1 ;
var ans = "" ;
var sagot = "";
var right_ans = "" ;
var life = 3;
var score = 0;
var numb = 1;
var let_num = "";






function hi()
{

$("#f_hint,#f_hint2,#f_hint3").hide();
$("#f_thint,#f_thint2,#f_thint3").hide();
$("#f_mhint,#f_mhint2,#f_mhint3").hide();




p = 1 ;
ans = "" ;
sagot = "";
right_ans = "" ;
life = life - life + 3;
score = score - score + 0;
numb = 1 ;
let_num = "";

document.getElementById("score").innerHTML = "score : " + score;

$("#hint,#hint2,#hint3,#lif1,#lif2,#lif3").show();






 document.getElementById("dito").innerHTML = "";
 reset();
 $("#a,#c,#b,#d,#e,#g,#f,#h,#i,#j").show();
 
 
 
 
 document.getElementById("tdito").innerHTML = "";
 treset();
 $("#ta,#tc,#tb,#td,#te,#tg,#tf,#th,#ti,#tj").show();
 
 
 
 document.getElementById("mdito").innerHTML = "";
 mreset();
 $("#ma,#mc,#mb,#md,#me,#mg,#mf,#mh,#mi,#mj").show();


 document.getElementById("anst").innerHTML = "";
 document.getElementById("tanst").innerHTML = "";
 document.getElementById("manst").innerHTML = "";
 
 




document.getElementById("submit").href = "";
document.getElementById("tsubmit").href = "";
document.getElementById("msubmit").href = "";









tp = 1 ;
tans = "" ;
tsagot = "";
tright_ans = "" ;
tlife = tlife - tlife + 3;
tscore = tscore - tscore + 0;
tnumb = 1;
let_num2 = "";

document.getElementById("tscore").innerHTML = "score : " + tscore;

$("#thint,#thint2,#thint3,#tlif1,#tlif2,#tlif3").show();









mp = 1 ;
mans = "" ;
msagot = "";
mright_ans = "" ;
mlife = mlife - mlife + 3;
mscore = mscore - mscore + 0;
mnumb = 1 ;
let_num3 = "";

document.getElementById("mscore").innerHTML = "score : " + mscore;

$("#mhint,#mhint2,#mhint3,#mlif1,#mlif2,#mlif3").show();










timesstop();
pt = 1 ;
anst = "" ;
sagott = "";
right_anst = "" ;
scoret = scoret - scoret + 0;
numbt = 1 ;
let_num4 = "";
s = s - s + 59;
m = m - m + 9;

$("#try1,#questiont,#anst,#at,#bt,#ct,#dt,#et,#ft,#gt,#ht,#it,#jt").show();
		$("#submitt,#resett").show();

	
	$("#gameover").hide();

document.getElementById("scoret").innerHTML = "score : " + scoret;





timesstop2();
tpt = 1 ;
tanst = "" ;
tsagott = "";
tright_anst = "" ;
tscoret = tscoret - tscoret + 0;
tnumbt = 1 ;
let_num5 = "";
s2 = s2 - s2 + 59;
m2 = m2 - m2 + 9;

$("#try2,#tquestiont,#tanst,#tat,#tbt,#tct,#tdt,#tet,#tft,#tgt,#tht,#tit,#tjt").show();
		$("#tsubmitt,#tresett").show();

	$("#tgameover").hide();
	
document.getElementById("tscoret").innerHTML = "score : " + tscoret;









timesstop3();
mpt = 1 ;
manst = "" ;
msagott = "";
mright_anst = "" ;
mscoret = mscoret - mscoret + 0;
mnumbt = 1 ;
let_num6 = "";
s3 = s3 - s3 + 59;
m3 = m3 - m3 + 9;

$("#try3,#mquestiont,#manst,#mat,#mbt,#mct,#mdt,#met,#mft,#mgt,#mht,#mit,#mjt").show();
		$("#msubmitt,#mresett").show();

	
	$("#mgameover").hide();

document.getElementById("mscoret").innerHTML = "score : " + mscoret;














}



function bura()
{
var dine = sagot.length - 1;

sagot = sagot.substring(0,dine);
document.getElementById("ans").innerHTML = sagot;

var dindin = let_num.length - 1;
var pj = let_num.charAt(dindin);
if(pj == "a")
{$("#a").show(200);
let_num = let_num.substring(0,dindin);
}
else if(pj == "b")
{$("#b").show(200);
let_num = let_num.substring(0,dindin);}
else if(pj == "c")
{$("#c").show(200);
let_num = let_num.substring(0,dindin);}
else if(pj == "d")
{$("#d").show(200);
let_num = let_num.substring(0,dindin);}
else if(pj == "e")
{$("#e").show(200);
let_num = let_num.substring(0,dindin);}
else if(pj == "f")
{$("#f").show(200);
let_num = let_num.substring(0,dindin);}
else if(pj == "g")
{$("#g").show(200);
let_num = let_num.substring(0,dindin);}
else if(pj == "h")
{$("#h").show(200);
let_num = let_num.substring(0,dindin);}
else if(pj == "i")
{$("#i").show(200);
let_num = let_num.substring(0,dindin);}
else if(pj == "j")
{$("#j").show(200);
let_num = let_num.substring(0,dindin);}




}

















function homing()
{
  var x;
    if (confirm("You want to quit?") == true) {
 document.getElementById("home_b").href =  "#page1";
  } else {
 document.getElementById("home_b").href =  "";
    }
}





$(document).ready(function(){
$("#tog").click(function(){
$("#hint,#hint2,#hint3").toggle(1500);
});
});








$(document).ready(function(){
$("#a").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#b").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#c").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#d").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#e").click(function(){
$(this).hide(200);
});
});








$(document).ready(function(){
$("#f").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#g").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#h").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#i").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#j").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#reset").click(function(){
$("#a,#c,#b,#d,#e,#g,#f,#h,#i,#j").show(200);
});
});


$(document).ready(function(){
$("#submit").click(function(){
$("#a,#c,#b,#d,#e,#g,#f,#h,#i,#j").show(200);
});
});





$(document).ready(function(){
$("#hint").click(function(){
$(this).hide();
$("#f_hint").show();
});
});


$(document).ready(function(){
$("#hint2").click(function(){
$(this).hide();
$("#f_hint2").show();
});
});


$(document).ready(function(){
$("#hint3").click(function(){
$(this).hide();
$("#f_hint3").show();
});
});



function hint()
{




var hinto = right_ans.length;

$("#dito").show(500);

document.getElementById("dito").innerHTML =  "the answer is consists of " + hinto + " Letters";

}




function hint2()
{

var hinto = right_ans.charAt(0);

$("#dito").show(500);

document.getElementById("dito").innerHTML =  "It starts with letter " + hinto;

}


function hint3()
{
var x = right_ans.length - 1;
var hinto = right_ans.charAt(x);

$("#dito").show(500);

document.getElementById("dito").innerHTML =  "It ends with letter " + hinto;

}




function gokay_e_u()
{
var p = 1 ;
var ans = "" ;
var sagot = "";
var right_ans = "" ;
var life = 3;
var score = 0;
var numb = 1;


}




function cokay_e_u()
{
var p = 1 ;
var ans = "" ;
var sagot = "";
var right_ans = "" ;
var life = 3;
var score = 0;
var numb = 1;


}

function start_e_u()
{

var random = Math.floor(Math.random()*2);
if(random==0){random++;}






if(p==1)
	{
		
	eques1();

	}
	else if(p==2)
	{
		
	eques2();

	}
	else if(p==3)
		
	{
	eques3();

	}

	else if(p==4)
		
	{
	eques4();

	}
	else if(p==5)
		
	{
	eques5();

	}

	else if(p==6)
		
	{
	eques6();

	}
	else if(p==7)
		
	{
	eques7();

	}
	else if(p==8)
		
	{
	eques8();

	}
	else if(p==9)
		
	{
	eques9();

	}
	else if(p==10)
		
	{
	eques10();

	}


	else if(p==11)
	{
		
	eques11();

	}
	else if(p==12)
	{
		
	eques12();

	}
	else if(p==13)
		
	{
	eques13();

	}

	else if(p==14)
		
	{
	eques14();

	}
	else if(p==15)
		
	{
	eques15();

	}

	else if(p==16)
		
	{
	eques16();

	}
	else if(p==17)
		
	{
	eques17();

	}
	else if(p==18)
		
	{
	eques18();

	}
	else if(p==19)
		
	{
	eques19();

	}
	else if(p==20)
		
	{
	eques20();

	}

	
	else if(p==21)
	{
		
	eques21();

	}
	else if(p==22)
	{
		
	eques22();

	}
	else if(p==23)
		
	{
	eques23();

	}

	else if(p==24)
		
	{
	eques24();

	}
	else if(p==25)
		
	{
	eques25();

	}

	else if(p==26)
		
	{
	eques26();

	}
	else if(p==27)
		
	{
	eques27();

	}
	else if(p==28)
		
	{
	eques28();

	}
	else if(p==29)
		
	{
	eques29();

	}
	else if(p==30)
		
	{
	eques30();

	}

	
	else if(p==31)
	{
		
	eques31();

	}
	else if(p==32)
	{
		
	eques32();

	}
	else if(p==33)
		
	{
	eques33();

	}

	else if(p==34)
		
	{
	eques34();

	}
	else if(p==35)
		
	{
	eques35();

	}

	else if(p==36)
		
	{
	eques36();

	}
	else if(p==37)
		
	{
	eques37();

	}
	else if(p==38)
		
	{
	eques38();

	}
	else if(p==39)
		
	{
	eques39();

	}
	else if(p==40)
		
	{
	eques40();

	}


	else if(p==41)
	{
		
	eques41();

	}
	else if(p==42)
	{
		
	eques42();

	}
	else if(p==43)
		
	{
	eques43();

	}

	else if(p==44)
		
	{
	eques44();

	}
	else if(p==45)
		
	{
	eques45();

	}

	else if(p==46)
		
	{
	eques46();

	}
	else if(p==47)
		
	{
	eques47();

	}
	else if(p==48)
		
	{
	eques48();

	}
	else if(p==49)
		
	{
	eques49();

	}
	else if(p==50)
		
	{
	eques50();

	}

	
	else if(p==51)
	{
		
	eques51();

	}
	else if(p==52)
	{
		
	eques52();

	}
	else if(p==53)
		
	{
	eques53();

	}

	else if(p==54)
		
	{
	eques54();

	}
	else if(p==55)
		
	{
	eques55();

	}

	else if(p==56)
		
	{
	eques56();

	}
	else if(p==57)
		
	{
	eques57();

	}
	else if(p==58)
		
	{
	eques58();

	}
	else if(p==59)
		
	{
	eques59();

	}
	else if(p==60)
		
	{
	eques60();

	}
	
	
	else if(p==61)
	{
		
	eques61();

	}
	else if(p==62)
	{
		
	eques62();

	}
	else if(p==63)
		
	{
	eques63();

	}

	else if(p==64)
		
	{
	eques64();

	}
	else if(p==65)
		
	{
	eques65();

	}

	else if(p==66)
		
	{
	eques66();

	}
	else if(p==67)
		
	{
	eques67();

	}
	else if(p==68)
		
	{
	eques68();

	}
	else if(p==69)
		
	{
	eques69();

	}
	else if(p==70)
		
	{
	eques70();

	}
	
	
	else if(p==71)
	{
		
	eques71();

	}
	else if(p==72)
	{
		
	eques72();

	}
	else if(p==73)
		
	{
	eques73();

	}

	else if(p==74)
		
	{
	eques74();

	}
	else if(p==75)
		
	{
	eques75();

	}

	else if(p==76)
		
	{
	eques76();

	}
	else if(p==77)
		
	{
	eques77();

	}
	else if(p==78)
		
	{
	eques78();

	}
	else if(p==79)
		
	{
	eques79();

	}
	else if(p==80)
		
	{
	eques80();

	}
	
	
	else if(p==81)
	{
		
	eques81();

	}
	else if(p==82)
	{
		
	eques82();

	}
	else if(p==83)
		
	{
	eques83();

	}

	else if(p==84)
		
	{
	eques84();

	}
	else if(p==85)
		
	{
	eques85();

	}

	else if(p==86)
		
	{
	eques86();

	}
	else if(p==87)
		
	{
	eques87();

	}
	else if(p==88)
		
	{
	eques88();

	}
	else if(p==89)
		
	{
	eques89();

	}
	else if(p==90)
		
	{
	eques90();

	}
	
	
	
	
	else if(p==91)
	{
		
	eques91();

	}
	else if(p==92)
	{
		
	eques92();

	}
	else if(p==93)
		
	{
	eques93();

	}

	else if(p==94)
		
	{
	eques94();

	}
	else if(p==95)
		
	{
	eques95();

	}

	else if(p==96)
		
	{
	eques96();

	}
	else if(p==97)
		
	{
	eques97();

	}
	else if(p==98)
		
	{
	eques98();

	}
	else if(p==99)
		
	{
	eques99();

	}
	else if(p==100)
		
	{
	eques100();

	}
	
	
	

	else if(p==101)
	{
		
	eques101();

	}
	else if(p==102)
	{
		
	eques102();

	}
	else if(p==103)
		
	{
	eques103();

	}

	else if(p==104)
		
	{
	eques104();

	}
	else if(p==105)
		
	{
	eques105();

	}

	else if(p==106)
		
	{
	eques106();

	}
	else if(p==107)
		
	{
	eques107();

	}
	else if(p==108)
		
	{
	eques108();

	}
	else if(p==109)
		
	{
	eques109();

	}
	else if(p==110)
		
	{
	eques110();

	}

	

	else if(p==111)
	{
		
	eques111();

	}
	else if(p==112)
	{
		
	eques112();

	}
	else if(p==113)
		
	{
	eques113();

	}

	else if(p==114)
		
	{
	eques114();

	}
	else if(p==115)
		
	{
	eques115();

	}

	else if(p==116)
		
	{
	eques116();

	}
	else if(p==117)
		
	{
	eques117();

	}
	else if(p==118)
		
	{
	eques118();

	}
	else if(p==119)
		
	{
	eques119();

	}
	else if(p==120)
		
	{
	eques120();

	}

	else if(p==121)
	{
		
	eques121();

	}
	else if(p==122)
	{
		
	eques122();

	}
	else if(p==123)
		
	{
	eques123();

	}

	else if(p==124)
		
	{
	eques124();

	}
	else if(p==125)
		
	{
	eques125();

	}

	else if(p==126)
		
	{
	eques126();

	}
	else if(p==127)
		
	{
	eques127();

	}
	else if(p==128)
		
	{
	eques128();

	}
	else if(p==129)
		
	{
	eques129();

	}
	else if(p==130)
		
	{
	eques130();

	}
	
	
	else if(p==131)
	{
		
	eques131();

	}
	else if(p==132)
	{
		
	eques132();

	}
	else if(p==133)
		
	{
	eques133();

	}

	else if(p==134)
		
	{
	eques134();

	}
	else if(p==135)
		
	{
	eques135();

	}

	else if(p==136)
		
	{
	eques136();

	}
	else if(p==137)
		
	{
	eques137();

	}
	else if(p==138)
		
	{
	eques138();

	}
	else if(p==139)
		
	{
	eques139();

	}
	else if(p==140)
		
	{
	eques140();

	}
	
	
	
	else if(p==141)
	{
		
	eques141();

	}
	else if(p==142)
	{
		
	eques142();

	}
	else if(p==143)
		
	{
	eques143();

	}

	else if(p==144)
		
	{
	eques144();

	}
	else if(p==145)
		
	{
	eques145();

	}

	else if(p==146)
		
	{
	eques146();

	}
	else if(p==147)
		
	{
	eques147();

	}
	else if(p==148)
		
	{
	eques148();

	}
	else if(p==149)
		
	{
	eques149();

	}
	else if(p==150)
		
	{
	eques150();

	}
	
	
	
	else if(p==151)
	{
		
	eques151();

	}
	else if(p==152)
	{
		
	eques152();

	}
	else if(p==153)
		
	{
	eques153();

	}

	else if(p==154)
		
	{
	eques154();

	}
	else if(p==155)
		
	{
	eques155();

	}

	else if(p==156)
		
	{
	eques156();

	}
	else if(p==157)
		
	{
	eques157();

	}
	else if(p==158)
		
	{
	eques158();

	}
	else if(p==159)
		
	{
	eques159();

	}
	else if(p==160)
		
	{
	eques160();

	}
	
	
	else if(p==161)
	{
		
	eques161();

	}
	else if(p==162)
	{
		
	eques162();

	}
	else if(p==163)
		
	{
	eques163();

	}

	else if(p==164)
		
	{
	eques164();

	}
	else if(p==165)
		
	{
	eques165();

	}

	else if(p==166)
		
	{
	eques166();

	}
	else if(p==167)
		
	{
	eques167();

	}
	else if(p==168)
		
	{
	eques168();

	}
	else if(p==169)
		
	{
	eques169();

	}
	else if(p==170)
		
	{
	eques170();

	}
	
	
	else if(p==171)
	{
		
	eques171();

	}
	else if(p==172)
	{
		
	eques172();

	}
	else if(p==173)
		
	{
	eques173();

	}

	else if(p==174)
		
	{
	eques174();

	}
	else if(p==175)
		
	{
	eques175();

	}

	else if(p==176)
		
	{
	eques176();

	}
	else if(p==177)
		
	{
	eques177();

	}
	else if(p==178)
		
	{
	eques178();

	}
	else if(p==179)
		
	{
	eques179();

	}
	else if(p==180)
		
	{
	eques180();

	}
	
	
	else if(p==181)
	{
		
	eques181();

	}
	else if(p==182)
	{
		
	eques182();

	}
	else if(p==183)
		
	{
	eques183();

	}

	else if(p==184)
		
	{
	eques184();

	}
	else if(p==185)
		
	{
	eques185();

	}

	else if(p==186)
		
	{
	eques186();

	}
	else if(p==187)
		
	{
	eques187();

	}
	else if(p==188)
		
	{
	eques188();

	}
	else if(p==189)
		
	{
	eques189();

	}
	else if(p==190)
		
	{
	eques190();

	}
	
	
	
	
	else if(p==191)
	{
		
	eques191();

	}
	else if(p==192)
	{
		
	eques192();

	}
	else if(p==193)
		
	{
	eques193();

	}

	else if(p==194)
		
	{
	eques194();

	}
	else if(p==195)
		
	{
	eques195();

	}

	else if(p==196)
		
	{
	eques196();

	}
	else if(p==197)
		
	{
	eques197();

	}
	else if(p==198)
		
	{
	eques198();

	}
	else if(p==199)
		
	{
	eques199();

	}
	else if(p==200)
		
	{
	eques200();

	}
	
	
	
	
	else if(p==201)
	{
		
	eques201();

	}
	
	else if(p==202)
	{
		
	eques202();

	}
	else if(p==203)
		
	{
	eques203();

	}

	else if(p==204)
		
	{
	eques204();

	}
	else if(p==205)
		
	{
	eques205();

	}

	else if(p==206)
		
	{
	eques206();

	}
	else if(p==207)
		
	{
	eques207();

	}
	else if(p==208)
		
	{
	eques208();

	}
	else if(p==209)
		
	{
	eques209();

	}
	else if(p==210)
		
	{
	eques210();

	}


	else if(p==211)
	{
		
	eques211();

	}
	else if(p==212)
	{
		
	eques212();

	}
	else if(p==213)
		
	{
	eques213();

	}

	else if(p==214)
		
	{
	eques214();

	}
	else if(p==215)
		
	{
	eques215();

	}

	else if(p==216)
		
	{
	eques216();

	}
	else if(p==217)
		
	{
	eques217();

	}
	else if(p==218)
		
	{
	eques218();

	}
	else if(p==219)
		
	{
	eques219();

	}
	else if(p==220)
		
	{
	eques220();

	}

	
	else if(p==221)
	{
		
	eques221();

	}
	else if(p==222)
	{
		
	eques222();

	}
	else if(p==223)
		
	{
	eques223();

	}

	else if(p==224)
		
	{
	eques224();

	}
	else if(p==225)
		
	{
	eques225();

	}

	else if(p==226)
		
	{
	eques226();

	}
	else if(p==227)
		
	{
	eques227();

	}
	else if(p==228)
		
	{
	eques228();

	}
	else if(p==229)
		
	{
	eques229();

	}
	else if(p==230)
		
	{
	eques230();

	}

	
	else if(p==231)
	{
		
	eques231();

	}
	else if(p==232)
	{
		
	eques232();

	}
	else if(p==233)
		
	{
	eques233();

	}

	else if(p==234)
		
	{
	eques234();

	}
	else if(p==235)
		
	{
	eques235();

	}

	else if(p==236)
		
	{
	eques236();

	}
	else if(p==237)
		
	{
	eques237();

	}
	else if(p==238)
		
	{
	eques238();

	}
	else if(p==239)
		
	{
	eques239();

	}
	else if(p==240)
		
	{
	eques240();

	}


	else if(p==241)
	{
		
	eques241();

	}
	else if(p==242)
	{
		
	eques242();

	}
	else if(p==243)
		
	{
	eques243();

	}

	else if(p==244)
		
	{
	eques244();

	}
	else if(p==245)
		
	{
	eques245();

	}

	else if(p==246)
		
	{
	eques246();

	}
	else if(p==247)
		
	{
	eques247();

	}
	else if(p==248)
		
	{
	eques248();

	}
	else if(p==249)
		
	{
	eques249();

	}
	else if(p==250)
		
	{
	eques250();

	}

	
	
	
	
	
}







	
	
function a()
{


var a = document.getElementById("a").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "a";
}


	
function b()
{


var a = document.getElementById("b").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "b";
}



function c()
{


var a = document.getElementById("c").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "c";
}





function d()
{


var a = document.getElementById("d").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "d";
}



function e()
{

var a = document.getElementById("e").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "e";
}



function f()
{

var a = document.getElementById("f").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "f";
}

function g()
{

var a = document.getElementById("g").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "g";
}

function h()
{

var a = document.getElementById("h").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "h";
}

function i()
{

var a = document.getElementById("i").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "i";
}

function j()
{

var a = document.getElementById("j").value;

sagot = sagot + a;

document.getElementById("ans").innerHTML = sagot;
let_num = let_num + "j";
}




function reset()
{


sagot = "";

document.getElementById("ans").innerHTML = sagot;
}




function eques1()
{

	document.getElementById('question').innerHTML="What's black when you get it, red when you use it, and white when you're all through with it?";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="c";
	document.getElementById('b').value="c";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="y";
	document.getElementById('g').value="y";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="h";
	document.getElementById('i').value="h";
	document.getElementById('j').innerHTML="l";
	document.getElementById('j').value="l";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "charcoal";




	}

	
	
	
function eques2()
{

	document.getElementById('question').innerHTML="Feed me and I live, give me drink and I die. What am I?";
	document.getElementById('a').innerHTML="g";
	document.getElementById('a').value="g";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="f";
	document.getElementById('d').value="f";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="d";
	document.getElementById('f').value="d";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "fire";




	}

	
	
	
	
	
	
function eques3()
{

	document.getElementById('question').innerHTML="It walks on four legs in the morning, two legs at noon and three legs in the evening. What is it?";
	document.getElementById('a').innerHTML="x";
	document.getElementById('a').value="x";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="d";
	document.getElementById('f').value="d";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="m";
	document.getElementById('h').value="m";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "man";




	}

	
	
	
	
	
function eques4()
{

	document.getElementById('question').innerHTML="At night it comes without being fetched. By day it is lost without being stolen. What is it?";
	document.getElementById('a').innerHTML="g";
	document.getElementById('a').value="g";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "star";




	}

	
			
		function eques5()
{

	document.getElementById('question').innerHTML="You throw away the outside and cook the inside. Then you eat the outside and throw away the inside. What did you eat?";
	document.getElementById('a').innerHTML="g";
	document.getElementById('a').value="g";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="p";
	document.getElementById('h').value="p";
	document.getElementById('i').innerHTML="d";
	document.getElementById('i').value="d";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "corn";




	}

	
	
	
	
	
	
	
	
		function eques6()
{

	document.getElementById('question').innerHTML= "Until I am measured I am not known, Yet how you miss me when I have flown.";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="t";
	document.getElementById('g').value="t";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "time";





	}

	
	
		
		function eques7()
{

	document.getElementById('question').innerHTML= "Lighter than what I am made of, More of me is hidden Than is seen.";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="b";
	document.getElementById('c').value="b";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="t";
	document.getElementById('g').value="t";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "iceberg";





	}

	
	
		
		function eques8()
{

	document.getElementById('question').innerHTML="You heard me before, yet you hear me again, Then I die, 'till you call me again.";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="h";
	document.getElementById('d').value="h";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "echo";




	}

	
	
			
		function eques9()
{

	document.getElementById('question').innerHTML="A box without hinges, lock or key, yet golden treasure lies within. What is it?";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="y";
	document.getElementById('j').value="y";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "egg";




	}

	
	
	
				
		function eques10()
{

	document.getElementById('question').innerHTML="Light as a feather, there is nothing in it.";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="k";
	document.getElementById('d').value="k";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="x";
	document.getElementById('g').value="x";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "breath";



	}

	
	
					
		function eques11()
{

	document.getElementById('question').innerHTML="I know a word of letters three. Add two, and fewer there will be!";
	document.getElementById('a').innerHTML="x";
	document.getElementById('a').value="x";
	document.getElementById('b').innerHTML="f";
	document.getElementById('b').value="f";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="k";
	document.getElementById('d').value="k";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="x";
	document.getElementById('g').value="x";
	document.getElementById('h').innerHTML="w";
	document.getElementById('h').value="w";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "few";



	}
	
	
	
		
					
		function eques12()
{

	document.getElementById('question').innerHTML="I have four legs but no tail. Usually I am heard only at night. What am I?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="f";
	document.getElementById('b').value="f";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="f";
	document.getElementById('d').value="f";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="x";
	document.getElementById('g').value="x";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="x";
	document.getElementById('i').value="x";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "frog";



	}
	
	
	
	
	
	
		
					
		function eques13()
{

	document.getElementById('question').innerHTML="When young, I am sweet in the sun. When middle-aged, I make you gay. When old, I am valued more than ever.";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="f";
	document.getElementById('b').value="f";
	document.getElementById('c').innerHTML="w";
	document.getElementById('c').value="w";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="v";
	document.getElementById('e').value="v";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="x";
	document.getElementById('g').value="x";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "wine";



	}
	
	
	
	
		
					
		function eques14()
{

	document.getElementById('question').innerHTML="All about, but cannot be seen, Can be captured, cannot be held, No throat, but can be heard.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="w";
	document.getElementById('c').value="w";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="x";
	document.getElementById('g').value="x";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "wind";



	}
	
	
	
	
		
					
		function eques15()
{

	document.getElementById('question').innerHTML="Each morning I appear to lie at your feet, All day I will follow no matter how fast you run, Yet I nearly perish in the midday sun.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="w";
	document.getElementById('b').value="w";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="x";
	document.getElementById('g').value="x";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="o";
	document.getElementById('i').value="o";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "shadow";



	}
	
	
	
		
					
		function eques16()
{

	document.getElementById('question').innerHTML="My life can be measured in hours, I serve by being devoured. Thin, I am quick Fat, I am slow Wind is my foe.";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "candle";



	}
	
	
	
	
		
					
		function eques17()
{

	document.getElementById('question').innerHTML="I am seen in the water if seen in the sky, I am in the rainbow, a jay�s feather,and lapis lazuli.";
	document.getElementById('a').innerHTML="u";
	document.getElementById('a').value="u";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "blue";



	}
	
	

	
						
		function eques18()
{

	document.getElementById('question').innerHTML="Glittering points that downward thrust, Sparkling spears that never rust.";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="c";
	document.getElementById('c').value="c";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="c";
	document.getElementById('e').value="c";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "icicle";



	}
	
	

	
						
		function eques19()
{

	document.getElementById('question').innerHTML="At the sound of me, men may dream or stamp their feet, At the sound of me, women may laugh or sometimes weep.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="c";
	document.getElementById('c').value="c";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="c";
	document.getElementById('e').value="c";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="u";
	document.getElementById('g').value="u";
	document.getElementById('h').innerHTML="m";
	document.getElementById('h').value="m";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "music";



	}
	
	
	
						
		function eques20()
{

	document.getElementById('question').innerHTML="I build up castles. I tear down mountains. I make some men blind, I help others to see. What am I?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="n";
	document.getElementById('b').value="n";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="f";
	document.getElementById('h').value="f";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "sand";



	}
	
	
	
					
		function eques21()
{

	document.getElementById('question').innerHTML="It cannot be seen, it weighs nothing, but when put into a barrel, it makes it lighter. What is it?";
	document.getElementById('a').innerHTML="v";
	document.getElementById('a').value="v";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="x";
	document.getElementById('h').value="x";
	document.getElementById('i').innerHTML="d";
	document.getElementById('i').value="d";
	document.getElementById('j').innerHTML="k";
	document.getElementById('j').value="k";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "hole";



	}
	
	
	
					
		function eques22()
{

	document.getElementById('question').innerHTML="What starts with a T, ends with a T, and has T in it?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="p";
	document.getElementById('f').value="p";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="x";
	document.getElementById('h').value="x";
	document.getElementById('i').innerHTML="d";
	document.getElementById('i').value="d";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "teapot";



	}
	
	
					
		function eques23()
{

	document.getElementById('question').innerHTML="You saw me where I never was and where I could not be. And yet within that very place, my face you often see. What am I?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="x";
	document.getElementById('h').value="x";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "reflection";



	}
	
	
	
					
		function eques24()
{

	document.getElementById('question').innerHTML="Say my name and I disappear. What am I?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "silence";



	}
	
	
			function eques25()
{

	document.getElementById('question').innerHTML="Soft and fragile is my skin, I get my growth in mud I'm dangerous as much as pretty, for if not careful, I draw blood.";
	document.getElementById('a').innerHTML="h";
	document.getElementById('a').value="h";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="o";
	document.getElementById('i').value="o";
	document.getElementById('j').innerHTML="h";
	document.getElementById('j').value="h";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "thorn";



	}
	
	
	


		
			function eques26()
{

	document.getElementById('question').innerHTML="It is greater than God and more evil than the devil. The poor have it, the rich need it and if you eat it you'll die. What is it?";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="g";
	document.getElementById('b').value="g";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "nothing";



	}
	
	


		
			function eques27()
{

	document.getElementById('question').innerHTML="What always runs but never walks, often murmurs, never talks, has a bed but never sleeps, has a mouth but never eats?";
	document.getElementById('a').innerHTML="v";
	document.getElementById('a').value="v";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="v";
	document.getElementById('d').value="v";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "river";



	}
	
	

		
			function eques28()
{

	document.getElementById('question').innerHTML="I never was, am always to be. No one ever saw me, nor ever will. And yet I am the confidence of all, To live and breath on this terrestrial ball. What am I?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="u";
	document.getElementById('b').value="u";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="f";
	document.getElementById('i').value="f";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "future";



	}
	
	

	
			function eques29()
{

	document.getElementById('question').innerHTML="I drive men mad For love of me, Easily beaten, Never free.";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="d";
	document.getElementById('f').value="d";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "gold";



	}
	
	

	
			function eques30()
{

	document.getElementById('question').innerHTML="I am a box that holds keys without locks, yet they can unlock your soul. What am I?";
	document.getElementById('a').innerHTML="d";
	document.getElementById('a').value="d";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="d";
	document.getElementById('f').value="d";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "piano";



	}
	
	
	
			function eques31()
{

	document.getElementById('question').innerHTML="What gets wetter as it dries?";
	document.getElementById('a').innerHTML="g";
	document.getElementById('a').value="g";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="f";
	document.getElementById('d').value="f";
	document.getElementById('e').innerHTML="j";
	document.getElementById('e').value="j";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "towel";



	}
	
	
	
			function eques32()
{

	document.getElementById('question').innerHTML="I'm full of holes, yet I'm full of water. What am I?";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="p";
	document.getElementById('i').value="p";
	document.getElementById('j').innerHTML="s";
	document.getElementById('j').value="s";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "sponge";



	}
	
	


			function eques33()
{

	document.getElementById('question').innerHTML="It's red, blue, purple and green, no one can reach it, not even the queen. What is it?";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="b";
	document.getElementById('d').value="b";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="d";
	document.getElementById('i').value="d";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "rainbow";



	}
	
	

			function eques34()
{

	document.getElementById('question').innerHTML="What has a neck and no head, two arms but no hands?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="y";
	document.getElementById('d').value="y";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="m";
	document.getElementById('f').value="m";
	document.getElementById('g').innerHTML="t";
	document.getElementById('g').value="t";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="h";
	document.getElementById('i').value="h";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "shirt";



	}
	
	

		function eques35()
{

	document.getElementById('question').innerHTML="I live in water If you cut my head I'm at your door, If you cut my tail I'm fruit, If you cut both I'm with you";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="h";
	document.getElementById('d').value="h";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="p";
	document.getElementById('i').value="p";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "pearl";



	}
	
	

		function eques36()
{

	document.getElementById('question').innerHTML="What makes a loud noise when changing its jacket, becomes larger but weighs less?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="c";
	document.getElementById('b').value="c";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="p";
	document.getElementById('i').value="p";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "popcorn";



	}
	
	
	
		function eques37()
{

	document.getElementById('question').innerHTML="I never was, am always to be, No one ever saw me, nor ever will And yet I am the confidence of all To live and breathe on this terrestrial ball.";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="p";
	document.getElementById('i').value="p";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "tomorrow";



	}
	
	
	
	
		function eques38()
{

	document.getElementById('question').innerHTML="Die without me, Never thank me. Walk right through me, never feel me. Always watching, never speaking. Always lurking, never seen.";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="g";
	document.getElementById('e').value="g";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="k";
	document.getElementById('h').value="k";
	document.getElementById('i').innerHTML="x";
	document.getElementById('i').value="x";
	document.getElementById('j').innerHTML="z";
	document.getElementById('j').value="z";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "air";



	}
	
	
	
		function eques39()
{

	document.getElementById('question').innerHTML="Pregnant every time you see her, yet she will never give birth.";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "fullmoon";



	}
	
	
	
		function eques40()
{

	document.getElementById('question').innerHTML="I go around in circles, But always straight ahead Never complain, No matter where I am led.";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="w";
	document.getElementById('b').value="w";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "wheel";



	}
	
	
		
		function eques41()
{

	document.getElementById('question').innerHTML="If dead, has a longer life. If alive, has a short life.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="w";
	document.getElementById('b').value="w";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="c";
	document.getElementById('e').value="c";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="d";
	document.getElementById('i').value="d";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "candle";



	}
	
	
			
		function eques42()
{

	document.getElementById('question').innerHTML="I bought a servant whose rank is higher than mine.";
	document.getElementById('a').innerHTML="x";
	document.getElementById('a').value="x";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="m";
	document.getElementById('e').value="m";
	document.getElementById('f').innerHTML="d";
	document.getElementById('f').value="d";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "hat";



	}
	
	
				
		function eques43()
{

	document.getElementById('question').innerHTML="Has head, no hair, has stomach, no navel.";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="m";
	document.getElementById('g').value="m";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="z";
	document.getElementById('j').value="z";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "frog";



	}
	
	
					
		function eques44()
{

	document.getElementById('question').innerHTML="What goes up and down stairs without moving?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="c";
	document.getElementById('b').value="c";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="u";
	document.getElementById('d').value="u";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="p";
	document.getElementById('g').value="p";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="r";
	document.getElementById('j').value="r";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "carpet";



	}
	
	
						
		function eques45()
{

	document.getElementById('question').innerHTML="	What goes around the world and stays in a corner?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="p";
	document.getElementById('e').value="p";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="d";
	document.getElementById('g').value="d";
	document.getElementById('h').innerHTML="k";
	document.getElementById('h').value="k";
	document.getElementById('i').innerHTML="h";
	document.getElementById('i').value="h";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "stamp";



	}
	
	
							
		function eques46()
{

	document.getElementById('question').innerHTML="The more there is, the less you see.";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="k";
	document.getElementById('h').value="k";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "darkness";



	}
	
	
							
		function eques47()
{

	document.getElementById('question').innerHTML="I look at you, you look at me, I raise my right, you raise your left. What is this object?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="k";
	document.getElementById('b').value="k";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "mirror";



	}
	
	
							
		function eques48()
{

	document.getElementById('question').innerHTML="What kind of room has no windows or doors?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "mushroom";



	}
	
	
								
		function eques49()
{

	document.getElementById('question').innerHTML="It has no top or bottom but it can hold flesh, bones, and blood all at the same time. What is this object?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="f";
	document.getElementById('e').value="f";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "ring";



	}
	
	
		
								
		function eques50()
{

	document.getElementById('question').innerHTML="Take off my skin, I won't cry, but you will. What am I?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="v";
	document.getElementById('i').value="v";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "onion";



	}
	
	
	
		
								
		function eques51()
{

	document.getElementById('question').innerHTML="I'm the son of water but when I return to water, I die Who am I?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="c";
	document.getElementById('b').value="c";
	document.getElementById('c').innerHTML="i";
	document.getElementById('c').value="i";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="y";
	document.getElementById('e').value="y";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="x";
	document.getElementById('j').value="x";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "ice";



	}
	
	
	
			
								
		function eques52()
{

	document.getElementById('question').innerHTML="I travel the world and I am drunk constantly. Who am I?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="i";
	document.getElementById('c').value="i";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="g";
	document.getElementById('g').value="g";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="x";
	document.getElementById('j').value="x";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "water";



	}
	
	
	
		
	
			
								
		function eques53()
{

	document.getElementById('question').innerHTML="You answer me, although I never ask you questions. What am I?";
	document.getElementById('a').innerHTML="h";
	document.getElementById('a').value="h";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "telephone";



	}
	
	
	
				
								
		function eques54()
{

	document.getElementById('question').innerHTML="What has to be broken before it can be used?";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="i";
	document.getElementById('c').value="i";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "egg";



	}
	
	
	
				
								
		function eques55()
{

	document.getElementById('question').innerHTML="If you have it, you want to share it. If you share it, you don't have it. What is it?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="k";
	document.getElementById('c').value="k";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="x";
	document.getElementById('i').value="x";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "secret";



	}
	
	
	
		
				
								
		function eques56()
{

	document.getElementById('question').innerHTML="He has married many women but has never married. Who is he?";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="p";
	document.getElementById('c').value="p";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "priest";



	}
	
	
	
	
				
								
		function eques57()
{

	document.getElementById('question').innerHTML="	The more you take the more you leave behind.";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "footstep";



	}
	
	
	
	
								
		function eques58()
{

	document.getElementById('question').innerHTML="What can run but never walks, has a mouth but never talks, has a head but never weeps, has a bed but never sleeps?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="v";
	document.getElementById('b').value="v";
	document.getElementById('c').innerHTML="j";
	document.getElementById('c').value="j";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "river";



	}
	
	
	
	
								
		function eques59()
{

	document.getElementById('question').innerHTML="As I walked along the path I saw something with four fingers and one thumb, but it was not flesh, fish, bone, or fowl.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="v";
	document.getElementById('b').value="v";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="d";
	document.getElementById('g').value="d";
	document.getElementById('h').innerHTML="k";
	document.getElementById('h').value="k";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "gloves";



	}
	
	
	
	
								
		function eques60()
{

	document.getElementById('question').innerHTML="What can fill a room but takes up no space?";
	document.getElementById('a').innerHTML="m";
	document.getElementById('a').value="m";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "light";



	}
	
	
								
		function eques61()
{

	document.getElementById('question').innerHTML="What kind of dog keeps the best time?";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "watchdog";



	}
	
	
	
	
	
								
		function eques62()
{

	document.getElementById('question').innerHTML="What time of day, when written in capital letters, is the same forwards, backwards and upside down?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="z";
	document.getElementById('c').value="z";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="x";
	document.getElementById('f').value="x";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "noon";



	}
	
	
	
								
		function eques63()
{

	document.getElementById('question').innerHTML="A tasty reward given to well behaved dogs and kids.";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="x";
	document.getElementById('f').value="x";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "treat";



	}
	
	
								
		function eques64()
{

	document.getElementById('question').innerHTML="A Caribbean shape that makes ships disappear.";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="i";
	document.getElementById('c').value="i";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "triangle";



	}
	
	
	
	
								
		function eques65()
{

	document.getElementById('question').innerHTML="What has a face and two hands but no arms or legs?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="k";
	document.getElementById('b').value="k";
	document.getElementById('c').innerHTML="c";
	document.getElementById('c').value="c";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="c";
	document.getElementById('j').value="c";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "clock";



	}
	
	
	
		
				
								
		function eques66()
{

	document.getElementById('question').innerHTML="What five-letter word becomes shorter when you add two letters to it?";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "short";



	}
	
	
	
	
				
								
		function eques67()
{

	document.getElementById('question').innerHTML="What word begins and ends with an 'e' but only has one letter";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="v";
	document.getElementById('f').value="v";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "envelope";



	}
	
	
	
	
								
		function eques68()
{

	document.getElementById('question').innerHTML=" What has a neck but no head?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="b";
	document.getElementById('b').value="b";
	document.getElementById('c').innerHTML="l";
	document.getElementById('c').value="l";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "bottle";



	}
	
	
	
	
								
		function eques69()
{

	document.getElementById('question').innerHTML="What type of cheese is made backwards?";
	document.getElementById('a').innerHTML="m";
	document.getElementById('a').value="m";
	document.getElementById('b').innerHTML="v";
	document.getElementById('b').value="v";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="d";
	document.getElementById('g').value="d";
	document.getElementById('h').innerHTML="k";
	document.getElementById('h').value="k";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "edam";



	}
	
	
	
	
								
		function eques70()
{

	document.getElementById('question').innerHTML="What gets wetter as it dries?";
	document.getElementById('a').innerHTML="w";
	document.getElementById('a').value="w";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "towel";



	}
	
	
	
	
								
		function eques71()
{

	document.getElementById('question').innerHTML="starts with a 'p', ends with an 'e' and has thousands of letters?";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="p";
	document.getElementById('d').value="p";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="f";
	document.getElementById('h').value="f";
	document.getElementById('i').innerHTML="f";
	document.getElementById('i').value="f";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "postoffice";



	}
	
	
	
	
	
								
		function eques72()
{

	document.getElementById('question').innerHTML="What has to be broken before you can eat it?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "egg";



	}
	
	
	
								
		function eques73()
{

	document.getElementById('question').innerHTML="What begins with T, ends with T and has T in it?";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="x";
	document.getElementById('f').value="x";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "teapot";



	}
	
	
								
		function eques74()
{

	document.getElementById('question').innerHTML="What belongs to you but others use it more than you do?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="m";
	document.getElementById('c').value="m";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "name";



	}
	
	
	
	
								
		function eques75()
{

	document.getElementById('question').innerHTML="The more you take away, the larger it becomes. What is it?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="k";
	document.getElementById('b').value="k";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="h";
	document.getElementById('j').value="h";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "hole";



	}
	
	
	
		
				
								
		function eques76()
{

	document.getElementById('question').innerHTML="Where do fish keep their money";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="k";
	document.getElementById('b').value="k";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="v";
	document.getElementById('j').value="v";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "riverbank";



	}
	
	
	
	
				
								
		function eques77()
{

	document.getElementById('question').innerHTML="What is it that you will break every time you name it?";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "silence";



	}
	
	
	
	
								
		function eques78()
{

	document.getElementById('question').innerHTML="What flies without wings?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="b";
	document.getElementById('b').value="b";
	document.getElementById('c').innerHTML="m";
	document.getElementById('c').value="m";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "time";



	}
	
	
	
	
								
		function eques79()
{

	document.getElementById('question').innerHTML="What Kind of Fish chases a mouse?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="d";
	document.getElementById('g').value="d";
	document.getElementById('h').innerHTML="k";
	document.getElementById('h').value="k";
	document.getElementById('i').innerHTML="h";
	document.getElementById('i').value="h";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "catfish";



	}
	
	
	
	
								
		function eques80()
{

	document.getElementById('question').innerHTML="What goes up and down without moving?";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "stairs";



	}
	
	
	
		
	
	
	
	
								
		function eques81()
{

	document.getElementById('question').innerHTML="I have a face, two arms, and two hands, yet I cannot move. I count to twelve, yet I cannot speak. I can still tell you something?";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="f";
	document.getElementById('h').value="f";
	document.getElementById('i').innerHTML="f";
	document.getElementById('i').value="f";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "clock";



	}
	
	
	
	
	
								
		function eques82()
{

	document.getElementById('question').innerHTML="What is round on both ends and hi in the middle?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "ohio";



	}
	
	
	
								
		function eques83()
{

	document.getElementById('question').innerHTML="What do you call a dog that sweats so much?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="x";
	document.getElementById('f').value="x";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "hotdog";



	}
	
	
								
		function eques84()
{

	document.getElementById('question').innerHTML="What rains at the north pole?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "reindeer";



	}
	
	
	
	
								
		function eques85()
{

	document.getElementById('question').innerHTML="What calls for help, when written in capital letters, is the same forwards, backwards and upside down?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="k";
	document.getElementById('b').value="k";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="g";
	document.getElementById('i').value="g";
	document.getElementById('j').innerHTML="h";
	document.getElementById('j').value="h";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "sos";



	}
	
	
	
		
				
								
		function eques86()
{

	document.getElementById('question').innerHTML="Commits friendly home invasions one night a year";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="u";
	document.getElementById('g').value="u";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="c";
	document.getElementById('j').value="c";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "santaclaus";



	}
	
	
	
	
				
								
		function eques87()
{

	document.getElementById('question').innerHTML="Everyone claims to know a way to stop these involuntary contractions but none of them work";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="u";
	document.getElementById('b').value="u";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="h";
	document.getElementById('i').value="h";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "hiccup";



	}
	
	
	
	
								
		function eques88()
{

	document.getElementById('question').innerHTML="One of the best things you can hope for after whacking a ball with a stick?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="u";
	document.getElementById('b').value="u";
	document.getElementById('c').innerHTML="m";
	document.getElementById('c').value="m";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="h";
	document.getElementById('i').value="h";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "homerun";



	}
	
	
	
	
								
		function eques89()
{

	document.getElementById('question').innerHTML="They put the heat in pop tarts";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="d";
	document.getElementById('g').value="d";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "toaster";



	}
	
	
	
	
								
		function eques90()
{

	document.getElementById('question').innerHTML="What has a ring, but no finger?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="p";
	document.getElementById('c').value="p";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "telephone";



	}
	
	
	
	
	
	
		
	
	
	
	
								
		function eques91()
{

	document.getElementById('question').innerHTML="What has four legs, but can't walk?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="f";
	document.getElementById('h').value="f";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "table";



	}
	
	
	
	
	
								
		function eques92()
{

	document.getElementById('question').innerHTML="What is higher without the head, than with it?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="w";
	document.getElementById('g').value="w";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="p";
	document.getElementById('i').value="p";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "pillow";



	}
	
	
	
								
		function eques93()
{

	document.getElementById('question').innerHTML="What's harder to catch the faster you run?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "breath";



	}
	
	
								
		function eques94()
{

	document.getElementById('question').innerHTML="What invention lets you look right through a wall?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="w";
	document.getElementById('b').value="w";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="w";
	document.getElementById('f').value="w";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "window";



	}
	
	
	
	
								
		function eques95()
{

	document.getElementById('question').innerHTML="What is made of wood, but can't be sawed";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="d";
	document.getElementById('i').value="d";
	document.getElementById('j').innerHTML="h";
	document.getElementById('j').value="h";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "sawdust";



	}
	
	
	
		
				
								
		function eques96()
{

	document.getElementById('question').innerHTML="What is a witch's favorite school subject?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="u";
	document.getElementById('g').value="u";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "spelling";



	}
	
	
	
	
				
								
		function eques97()
{

	document.getElementById('question').innerHTML="What is black and white and read all over?";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="p";
	document.getElementById('d').value="p";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "newspaper";



	}
	
	
	
	
								
		function eques98()
{

	document.getElementById('question').innerHTML="Easy to get into, but hard to get out ";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="u";
	document.getElementById('b').value="u";
	document.getElementById('c').innerHTML="m";
	document.getElementById('c').value="m";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="f";
	document.getElementById('f').value="f";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "trouble";



	}
	
	
	
	
								
		function eques99()
{

	document.getElementById('question').innerHTML="What is as big as you are and yet does not weigh anything?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="a";
	document.getElementById('e').value="a";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="d";
	document.getElementById('g').value="d";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "shadow";



	}
	
	
	
	
								
		function eques100()
{

	document.getElementById('question').innerHTML="When you have me, you feel like sharing me, but, if you do share me, you don't have me. ";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="p";
	document.getElementById('c').value="p";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "secret";



	}
	
	
	
	
	
		
	
	
		
	
	
	
	
								
		function eques101()
{

	document.getElementById('question').innerHTML="It is an insect and the first part of it's name is the name of another insect. What is it?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "beetle";



	}
	
	
	
	
	
								
		function eques102()
{

	document.getElementById('question').innerHTML="What becomes white when it is dirty?";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="c";
	document.getElementById('c').value="c";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "blackboard";



	}
	
	
	
								
		function eques103()
{

	document.getElementById('question').innerHTML="What word of five letters has only left when two letters are removed?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "stone";



	}
	
	
								
		function eques104()
{

	document.getElementById('question').innerHTML="Which vehicle is spelled the same forwards and backwards?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="n";
	document.getElementById('g').value="n";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "racecar";



	}
	
	
	
	
								
		function eques105()
{

	document.getElementById('question').innerHTML="I am lighter than air but a million men cannot lift me up. What am I?";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="h";
	document.getElementById('j').value="h";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "bubble";



	}
	
	
	
		
				
								
		function eques106()
{

	document.getElementById('question').innerHTML="It is everything to someone, and nothing to everyone else. What is it?";
	document.getElementById('a').innerHTML="d";
	document.getElementById('a').value="d";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="u";
	document.getElementById('g').value="u";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "mind";



	}
	
	
	
	
				
								
		function eques107()
{

	document.getElementById('question').innerHTML="Forward I am heavy, backwards I am not. What am I?";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "not";



	}
	
	
	
	
								
		function eques108()
{

	document.getElementById('question').innerHTML="What object has keys that open no locks, space but no room, and you can enter but not go in?";
	document.getElementById('a').innerHTML="d";
	document.getElementById('a').value="d";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="y";
	document.getElementById('f').value="y";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="k";
	document.getElementById('i').value="k";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "keyboard";



	}
	
	
	
	
								
		function eques109()
{

	document.getElementById('question').innerHTML="What bone has a sense of humor?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="u";
	document.getElementById('e').value="u";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="d";
	document.getElementById('g').value="d";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="u";
	document.getElementById('i').value="u";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "humorous";



	}
	
	
	
	
								
		function eques110()
{

	document.getElementById('question').innerHTML="What turns everything around, but does not move?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "mirror";



	}
	
	
	
	
		
	
	
	
	
								
		function eques111()
{

	document.getElementById('question').innerHTML="What is half of two plus two?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "three";



	}
	
	
	
	
	
								
		function eques112()
{

	document.getElementById('question').innerHTML="What word looks the same upside down and backwards?";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="c";
	document.getElementById('c').value="c";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="m";
	document.getElementById('g').value="m";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "swims";



	}
	
	
	
								
		function eques113()
{

	document.getElementById('question').innerHTML="What�s the difference between here and there?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "t";



	}
	
	
								
		function eques114()
{

	document.getElementById('question').innerHTML="What sits in a corner while traveling all around the world?";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="m";
	document.getElementById('b').value="m";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="t";
	document.getElementById('g').value="t";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "stamp";



	}
	
	
	
	
								
		function eques115()
{

	document.getElementById('question').innerHTML=" What body part is pronounced as one letter but written three, only two different letters are used?";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="u";
	document.getElementById('d').value="u";
	document.getElementById('e').innerHTML="y";
	document.getElementById('e').value="y";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "eye";



	}
	
	
	
		
				
								
		function eques116()
{

	document.getElementById('question').innerHTML="What keeps things green and keeps kids occupied in the summertime";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="k";
	document.getElementById('d').value="k";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "sprinkler";



	}
	
	
	
	
				
								
		function eques117()
{

	document.getElementById('question').innerHTML="A shower that lights up the sky";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "meteor";



	}
	
	
	
	
								
		function eques118()
{

	document.getElementById('question').innerHTML="Longer than a decade and shorter than a millennium";
	document.getElementById('a').innerHTML="y";
	document.getElementById('a').value="y";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="u";
	document.getElementById('c').value="u";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="c";
	document.getElementById('i').value="c";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "century";



	}
	
	
	
	
								
		function eques119()
{

	document.getElementById('question').innerHTML="I never was, am always to be. No one ever saw me, nor ever will. And yet I am the confidence of all, To live and breath on this terrestrial ball. What am I?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="u";
	document.getElementById('e').value="u";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="u";
	document.getElementById('i').value="u";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "future";



	}
	
	
	
	
								
		function eques120()
{

	document.getElementById('question').innerHTML="What has a head, a tail, and has no legs?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "coin";



	}
	
	
		
		
	
	
								
		function eques121()
{

	document.getElementById('question').innerHTML="Each morning I appear to lie at your feet, All day I will follow no matter how fast you run, Yet I nearly perish in the midday sun.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "shadow";



	}
	
	
	
	
	
								
		function eques122()
{

	document.getElementById('question').innerHTML="My life can be measured in hours, I serve by being devoured. Thin, I am quick Fat, I am slow Wind is my foe.";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="c";
	document.getElementById('c').value="c";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="d";
	document.getElementById('g').value="d";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "candle";



	}
	
	
	
								
		function eques123()
{

	document.getElementById('question').innerHTML="I am seen in the water if seen in the sky, I am in the rainbow.";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="b";
	document.getElementById('b').value="b";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "blue";



	}
	
	
								
		function eques124()
{

	document.getElementById('question').innerHTML="Three lives have I. Gentle enough to soothe the skin, Light enough to caress the sky, Hard enough to crack rocks.";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="c";
	document.getElementById('f').value="c";
	document.getElementById('g').innerHTML="t";
	document.getElementById('g').value="t";
	document.getElementById('h').innerHTML="w";
	document.getElementById('h').value="w";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="r";
	document.getElementById('j').value="r";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "water";



	}
	
	
	
	
								
		function eques125()
{

	document.getElementById('question').innerHTML="Two in a corner, 1 in a room, 0 in a house, but 1 in a shelter. What am I?";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="u";
	document.getElementById('d').value="u";
	document.getElementById('e').innerHTML="y";
	document.getElementById('e').value="y";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "r";



	}
	
	
	
		
				
								
		function eques126()
{

	document.getElementById('question').innerHTML="It cannot be seen, it weighs nothing, but when put into a barrel, it makes it lighter. What is it?";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="k";
	document.getElementById('d').value="k";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "hole";



	}
	
	
	
	
				
								
		function eques127()
{

	document.getElementById('question').innerHTML="I can be long, or I can be short. I can be grown, and I can be bought. I can be painted, or left bare. I can be round, or square. What am I?";
	document.getElementById('a').innerHTML="t";
	document.getElementById('a').value="t";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="l";
	document.getElementById('j').value="l";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "nail";



	}
	
	
	
	
								
		function eques128()
{

	document.getElementById('question').innerHTML="Soft and fragile is my skin, I get my growth in mud I'm dangerous as much as pretty, for if not careful, I draw blood.";
	document.getElementById('a').innerHTML="y";
	document.getElementById('a').value="y";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="u";
	document.getElementById('c').value="u";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "thorn";



	}
	
	
	
	
								
		function eques129()
{

	document.getElementById('question').innerHTML="My first is twice in apple but not once in tart. My second is in liver but not in heart. My third is in giant and also in ghost. Whole I'm best when I am roast. What am I?";
	document.getElementById('a').innerHTML="g";
	document.getElementById('a').value="g";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="p";
	document.getElementById('e').value="p";
	document.getElementById('f').innerHTML="s";
	document.getElementById('f').value="s";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="u";
	document.getElementById('i').value="u";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "pig";



	}
	
	
	
	
								
		function eques130()
{

	document.getElementById('question').innerHTML="A mile from end to end, yet as close to as a friend. A precious commodity, freely given. What is it?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "smile";



	}
	
	
		
			
	
	
								
		function eques131()
{

	document.getElementById('question').innerHTML="Alive without breath, As cold as death, Never thirsty, Ever drinking, Drowns on dry land.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="f";
	document.getElementById('c').value="f";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "fish";



	}
	
	
	
	
	
								
		function eques132()
{

	document.getElementById('question').innerHTML="Die without me, Never thank me. Walk right through me, never feel me. Always watching, never speaking. Always lurking, never seen.";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="c";
	document.getElementById('c').value="c";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "air";



	}
	
	
	
								
		function eques133()
{

	document.getElementById('question').innerHTML="Take one out and scratch my head, I am now black but once was red.";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="m";
	document.getElementById('e').value="m";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "match";



	}
	
	
								
		function eques134()
{

	document.getElementById('question').innerHTML="Only two backbones and thousands of ribs.";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="w";
	document.getElementById('h').value="w";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="l";
	document.getElementById('j').value="l";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "railroad";



	}
	
	
	
	
								
		function eques135()
{

	document.getElementById('question').innerHTML="Big as a biscuit, deep as a cup, Even a river can't fill it up. What is it?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "strainer";



	}
	
	
	
		
				
								
		function eques136()
{

	document.getElementById('question').innerHTML="It is greater than God and more evil than the devil. The poor have it, the rich need it and if you eat it you'll die. What is it?";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="n";
	document.getElementById('b').value="n";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="o";
	document.getElementById('i').value="o";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "nothing";



	}
	
	
	
	
				
								
		function eques137()
{

	document.getElementById('question').innerHTML="I am always hungry, I must always be fed,The finger I touch, Will soon turn red.";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="f";
	document.getElementById('j').value="f";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "fire";



	}
	
	
	
	
								
		function eques138()
{

	document.getElementById('question').innerHTML="All about, but cannot be seen, Can be captured, cannot be held, No throat, but can be heard.";
	document.getElementById('a').innerHTML="d";
	document.getElementById('a').value="d";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="u";
	document.getElementById('c').value="u";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "wind";



	}
	
	
	
	
								
		function eques139()
{

	document.getElementById('question').innerHTML="How far will a blind dog walk into a forest?";
	document.getElementById('a').innerHTML="y";
	document.getElementById('a').value="y";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="w";
	document.getElementById('c').value="w";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="p";
	document.getElementById('e').value="p";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "halfway";



	}
	
	
	
	
								
		function eques140()
{

	document.getElementById('question').innerHTML="I am, in truth, a yellow fork from tables in the sky, The apparatus of the dark to ignorance revealed.";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="g";
	document.getElementById('g').value="g";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "lightning";



	}
	
	
		
	
	
								
		function eques141()
{

	document.getElementById('question').innerHTML="Pedro hides but you can still see his head.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="f";
	document.getElementById('c').value="f";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="b";
	document.getElementById('i').value="b";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "nail";



	}
	
	
	
	
	
								
		function eques142()
{

	document.getElementById('question').innerHTML="Riddle me, riddle me, here comes a roaring chain";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "train";



	}
	
	
	
								
		function eques143()
{

	document.getElementById('question').innerHTML="Here comes Kaka, walking with an open leg.";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="s";
	document.getElementById('j').value="s";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "scissor";



	}
	
	
								
		function eques144()
{

	document.getElementById('question').innerHTML="Adam's hair, you can't count.";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="w";
	document.getElementById('h').value="w";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "rain";



	}
	
	
	
	
								
		function eques145()
{

	document.getElementById('question').innerHTML="Rice cake of the king, that you cannot divide.";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="w";
	document.getElementById('e').value="w";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "water";



	}
	
	
	
		
				
								
		function eques146()
{

	document.getElementById('question').innerHTML="Cute hares that hop and deliver eggs at Easter are called by this nickname.";
	document.getElementById('a').innerHTML="y";
	document.getElementById('a').value="y";
	document.getElementById('b').innerHTML="n";
	document.getElementById('b').value="n";
	document.getElementById('c').innerHTML="n";
	document.getElementById('c').value="n";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="o";
	document.getElementById('i').value="o";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "bunny";



	}
	
	
	
	
				
								
		function eques147()
{

	document.getElementById('question').innerHTML="This monkey food makes people slip and fall in cartoons.";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="b";
	document.getElementById('d').value="b";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "banana";



	}
	
	
	
	
								
		function eques148()
{

	document.getElementById('question').innerHTML="Owned by Old McDonald.";
	document.getElementById('a').innerHTML="d";
	document.getElementById('a').value="d";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="f";
	document.getElementById('c').value="f";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="w";
	document.getElementById('j').value="w";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "farm";



	}
	
	
	
	
								
		function eques149()
{

	document.getElementById('question').innerHTML="Poorly behaved children often find themselves sitting in these.";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="r";
	document.getElementById('j').value="r";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "corners";



	}
	
	
	
	
								
		function eques150()
{

	document.getElementById('question').innerHTML="It keeps things green and keeps the kids occupied in the summertime.";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="p";
	document.getElementById('c').value="p";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "sprinkler";



	}
	
	
		
	
	
	
	
	
								
		function eques151()
{

	document.getElementById('question').innerHTML="If a dog were filling out a resume, he might list his mastery of this game under �skills.";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="f";
	document.getElementById('c').value="f";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "fetch";



	}
	
	
	
	
	
								
		function eques152()
{

	document.getElementById('question').innerHTML="Sleep-inducing melody";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="u";
	document.getElementById('i').value="u";
	document.getElementById('j').innerHTML="y";
	document.getElementById('j').value="y";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "lullaby";



	}
	
	
	
								
		function eques153()
{

	document.getElementById('question').innerHTML="He crushed on Wendy Darling.";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "peterpan";



	}
	
	
								
		function eques154()
{

	document.getElementById('question').innerHTML="This guy crossed a road and everyone wants an explanation";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="w";
	document.getElementById('h').value="w";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "chicken";



	}
	
	
	
	
								
		function eques155()
{

	document.getElementById('question').innerHTML="A twiggy home";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="w";
	document.getElementById('e').value="w";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "nest";



	}
	
	
	
		
				
								
		function eques156()
{

	document.getElementById('question').innerHTML="Very helpful if you intend to go gently down a stream";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="w";
	document.getElementById('b').value="w";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="b";
	document.getElementById('f').value="b";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="o";
	document.getElementById('i').value="o";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "rowboat";



	}
	
	
	
	
				
								
		function eques157()
{

	document.getElementById('question').innerHTML="A storage facility for criminals and fire-breathing reptiles.";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="u";
	document.getElementById('c').value="u";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "dungeon";



	}
	
	
	
	
								
		function eques158()
{

	document.getElementById('question').innerHTML="Casper was a friendly one and Demi Moore made a clay pot with one.";
	document.getElementById('a').innerHTML="h";
	document.getElementById('a').value="h";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="f";
	document.getElementById('c').value="f";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="g";
	document.getElementById('g').value="g";
	document.getElementById('h').innerHTML="i";
	document.getElementById('h').value="i";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "ghost";



	}
	
	
	
	
								
		function eques159()
{

	document.getElementById('question').innerHTML="Where everyone wants to run home and stealing is encouraged.";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="b";
	document.getElementById('g').value="b";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "baseball";



	}
	
	
	
	
								
		function eques160()
{

	document.getElementById('question').innerHTML="Special abilities and brightly colored underwear are all you need to be one of these.";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="p";
	document.getElementById('c').value="p";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "superhero";



	}
	
	
	
		
								
		function eques161()
{

	document.getElementById('question').innerHTML="Consuming food would be pretty tough without these chompers.";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "teeth";



	}
	
	
	
	
	
								
		function eques162()
{

	document.getElementById('question').innerHTML="A shower that lights up the sky";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "meteor";



	}
	
	
	
								
		function eques163()
{

	document.getElementById('question').innerHTML="If you blow past your destination, you�ll have to throw your car into this.";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="v";
	document.getElementById('i').value="v";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "reverse";



	}
	
	
								
		function eques164()
{

	document.getElementById('question').innerHTML="The state of holding a person in your person";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="g";
	document.getElementById('e').value="g";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "pregnant";



	}
	
	
	
	
								
		function eques165()
{

	document.getElementById('question').innerHTML="Between daylight and darkness when sparkling blood suckers like to come out";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="w";
	document.getElementById('e').value="w";
	document.getElementById('f').innerHTML="h";
	document.getElementById('f').value="h";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "twilight";



	}
	
	
	
		
				
								
		function eques166()
{

	document.getElementById('question').innerHTML="Longer than a decade and shorter than a millennium";
	document.getElementById('a').innerHTML="y";
	document.getElementById('a').value="y";
	document.getElementById('b').innerHTML="c";
	document.getElementById('b').value="c";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="u";
	document.getElementById('f').value="u";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "century";



	}
	
	
	
	
				
								
		function eques167()
{

	document.getElementById('question').innerHTML="Fuels backyard get-togethers.";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="c";
	document.getElementById('b').value="c";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "charcoal";



	}
	
	
	
	
								
		function eques168()
{

	document.getElementById('question').innerHTML="Only you can prevent forest fires.";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="f";
	document.getElementById('c').value="f";
	document.getElementById('d').innerHTML="k";
	document.getElementById('d').value="k";
	document.getElementById('e').innerHTML="y";
	document.getElementById('e').value="y";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="g";
	document.getElementById('g').value="g";
	document.getElementById('h').innerHTML="m";
	document.getElementById('h').value="m";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "smokey";



	}
	
	
	
	
								
		function eques169()
{

	document.getElementById('question').innerHTML="A defendant will go free if a reasonable amount of this exists.";
	document.getElementById('a').innerHTML="u";
	document.getElementById('a').value="u";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="d";
	document.getElementById('d').value="d";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="b";
	document.getElementById('g').value="b";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "doubt";



	}
	
	
	
	
								
		function eques170()
{

	document.getElementById('question').innerHTML="Godzilla calls this place home";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="p";
	document.getElementById('c').value="p";
	document.getElementById('d').innerHTML="j";
	document.getElementById('d').value="j";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "japan";



	}
	
	
	
		
	
	
	
	
	
		
								
		function eques171()
{

	document.getElementById('question').innerHTML="This would be a good place to find Can-Can girls and drunk Cowboys.";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "saloon";



	}
	
	
	
	
	
								
		function eques172()
{

	document.getElementById('question').innerHTML="Santa�s reindeer make this noise.";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="i";
	document.getElementById('c').value="i";
	document.getElementById('d').innerHTML="l";
	document.getElementById('d').value="l";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="j";
	document.getElementById('f').value="j";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="l";
	document.getElementById('j').value="l";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "jingle";



	}
	
	
	
								
		function eques173()
{

	document.getElementById('question').innerHTML="He prefers to travel on vines and pal around with gorillas.";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="z";
	document.getElementById('c').value="z";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="v";
	document.getElementById('i').value="v";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "tarzan";



	}
	
	
								
		function eques174()
{

	document.getElementById('question').innerHTML="Angels and pilots earn these.";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="w";
	document.getElementById('c').value="w";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="g";
	document.getElementById('e').value="g";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "wing";



	}
	
	
	
	
								
		function eques175()
{

	document.getElementById('question').innerHTML="What becomes wetter the more it dries?";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="w";
	document.getElementById('e').value="w";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "towel";



	}
	
	
	
		
				
								
		function eques176()
{

	document.getElementById('question').innerHTML="What is so fragile, even saying its name can break it?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="c";
	document.getElementById('b').value="c";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="u";
	document.getElementById('f').value="u";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="c";
	document.getElementById('j').value="c";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "silence";



	}
	
	
	
	
				
								
		function eques177()
{

	document.getElementById('question').innerHTML="What can run but never walks, often murmurs, never talks, has a mouth but never eats, has a bed but never sleeps?";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="v";
	document.getElementById('h').value="v";
	document.getElementById('i').innerHTML="l";
	document.getElementById('i').value="l";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "river";



	}
	
	
	
	
								
		function eques178()
{

	document.getElementById('question').innerHTML="Anyone can hold me, even without their hands, yet no one can do it for long. What am I?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="f";
	document.getElementById('c').value="f";
	document.getElementById('d').innerHTML="h";
	document.getElementById('d').value="h";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="g";
	document.getElementById('g').value="g";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="b";
	document.getElementById('j').value="b";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "breath";



	}
	
	
	
	
								
		function eques179()
{

	document.getElementById('question').innerHTML="I have a hundred eyes, yet cannot see. What am I?";
	document.getElementById('a').innerHTML="u";
	document.getElementById('a').value="u";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="d";
	document.getElementById('d').value="d";
	document.getElementById('e').innerHTML="b";
	document.getElementById('e').value="b";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="t";
	document.getElementById('g').value="t";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "potato";



	}
	
	
	
	
								
		function eques180()
{

	document.getElementById('question').innerHTML="I am invisible, weigh nothing, and if you put me in a barrel, it will become lighter. What am I?";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="l";
	document.getElementById('c').value="l";
	document.getElementById('d').innerHTML="j";
	document.getElementById('d').value="j";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "hole";



	}
	
	
	
	
	
	
	
	
	
	
		
								
		function eques181()
{

	document.getElementById('question').innerHTML="I am always there, some distance away, somewhere between land and sky I lay, you may move toward me, yet distant I'll stay. What am I?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="i";
	document.getElementById('g').value="i";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="z";
	document.getElementById('i').value="z";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "horizon";



	}
	
	
	
	
	
								
		function eques182()
{

	document.getElementById('question').innerHTML="What has four fingers and a thumb, but is not made of flesh, fish, bone, or fowl?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="i";
	document.getElementById('c').value="i";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="j";
	document.getElementById('f').value="j";
	document.getElementById('g').innerHTML="v";
	document.getElementById('g').value="v";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="l";
	document.getElementById('j').value="l";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "glove";



	}
	
	
	
								
		function eques183()
{

	document.getElementById('question').innerHTML="The man who made it doesn't want it. The man who bought it doesn't need it. The man who needs it doesn't know it. What is it?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="z";
	document.getElementById('c').value="z";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "coffin";



	}
	
	
								
		function eques184()
{

	document.getElementById('question').innerHTML="What can go around the world, yet stays in a corner?";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="w";
	document.getElementById('c').value="w";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="g";
	document.getElementById('e').value="g";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="m";
	document.getElementById('h').value="m";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "stamp";



	}
	
	
	
	
								
		function eques185()
{

	document.getElementById('question').innerHTML="I am not alive, yet I grow; I have no lungs, yet I need air; I have no mouth, yet I can drown. What am I?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="w";
	document.getElementById('e').value="w";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "fire";



	}
	
	
	
		
				
								
		function eques186()
{

	document.getElementById('question').innerHTML="Throw me off the highest building, and I shall not break, but toss me in the smallest pool, and my life's at stake. What am I?";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="u";
	document.getElementById('b').value="u";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="u";
	document.getElementById('f').value="u";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="c";
	document.getElementById('j').value="c";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "tissue";



	}
	
	
	
	
				
								
		function eques187()
{

	document.getElementById('question').innerHTML="For what crime can an offender be arrested for attempting, but not committing?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="v";
	document.getElementById('h').value="v";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "suicide";



	}
	
	
	
	
								
		function eques188()
{

	document.getElementById('question').innerHTML="What can you always count on when trying to solve math problems?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="n";
	document.getElementById('b').value="n";
	document.getElementById('c').innerHTML="f";
	document.getElementById('c').value="f";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="g";
	document.getElementById('g').value="g";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="b";
	document.getElementById('j').value="b";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "fingers";



	}
	
	
	
	
								
		function eques189()
{

	document.getElementById('question').innerHTML="The rich want it, and the poor have it; it is greater than God, but worse than Satan; and if you eat it you will die. What is it?";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="h";
	document.getElementById('e').value="h";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="t";
	document.getElementById('g').value="t";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "nothing";



	}
	
	
	
	
								
		function eques190()
{

	document.getElementById('question').innerHTML="If you have me, you want to share me. If you share me, I no longer exist. What am I?";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="s";
	document.getElementById('b').value="s";
	document.getElementById('c').innerHTML="l";
	document.getElementById('c').value="l";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="t";
	document.getElementById('g').value="t";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "secret";



	}
	
	
	
	
	
	
		
								
		function eques191()
{

	document.getElementById('question').innerHTML="Before Mount Everest was discovered, what was the tallest mountain in the world?";
	document.getElementById('a').innerHTML="v";
	document.getElementById('a').value="v";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="z";
	document.getElementById('i').value="z";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "everest";



	}
	
	
	
	
	
								
		function eques192()
{

	document.getElementById('question').innerHTML="If a plane crashed on the border between the US and Mexico, where would the survivors be buried?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="j";
	document.getElementById('f').value="j";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "nowhere";



	}
	
	
	
								
		function eques193()
{

	document.getElementById('question').innerHTML="A man living in the UK cannot be buried in America because he is?";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="z";
	document.getElementById('c').value="z";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="t";
	document.getElementById('e').value="t";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="v";
	document.getElementById('g').value="v";
	document.getElementById('h').innerHTML="n";
	document.getElementById('h').value="n";
	document.getElementById('i').innerHTML="i";
	document.getElementById('i').value="i";
	document.getElementById('j').innerHTML="g";
	document.getElementById('j').value="g";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "living";



	}
	
	
								
		function eques194()
{

	document.getElementById('question').innerHTML="What has been around for millions of years, but is never more than a month old?";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="g";
	document.getElementById('e').value="g";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="m";
	document.getElementById('h').value="m";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "moon";



	}
	
	
	
	
								
		function eques195()
{

	document.getElementById('question').innerHTML="What belongs to you, but is used mostly by others?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="w";
	document.getElementById('e').value="w";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="m";
	document.getElementById('h').value="m";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "name";



	}
	
	
	
		
				
								
		function eques196()
{

	document.getElementById('question').innerHTML="Here there is no north or west or east, and the weather, it is fitting for no man or bird or beast.";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="p";
	document.getElementById('g').value="p";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "north pole";



	}
	
	
	
	
				
								
		function eques197()
{

	document.getElementById('question').innerHTML="What goes up but never comes down?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="a";
	document.getElementById('g').value="a";
	document.getElementById('h').innerHTML="v";
	document.getElementById('h').value="v";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "age";



	}
	
	
	
	
								
		function eques198()
{

	document.getElementById('question').innerHTML="The more there is, the less you see. What is it?";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "darkness";



	}
	
	
	
	
								
		function eques199()
{

	document.getElementById('question').innerHTML="What can go up and come down without moving?";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="v";
	document.getElementById('b').value="v";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="u";
	document.getElementById('e').value="u";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "volume";



	}
	
	
	
	
								
		function eques200()
{

	document.getElementById('question').innerHTML="What turns everything around without moving?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="l";
	document.getElementById('c').value="l";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="o";
	document.getElementById('h').value="o";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "mirror";



	}
	
	
	
	
	
	
	
	
	
		
								
		function eques201()
{

	document.getElementById('question').innerHTML="What two things can always see what the other sees, but can never see each other?";
	document.getElementById('a').innerHTML="v";
	document.getElementById('a').value="v";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="z";
	document.getElementById('i').value="z";
	document.getElementById('j').innerHTML="y";
	document.getElementById('j').value="y";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "eyes";



	}
	
	
	
	
	
								
		function eques202()
{

	document.getElementById('question').innerHTML="What type of building has the most stories?";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="y";
	document.getElementById('i').value="y";
	document.getElementById('j').innerHTML="l";
	document.getElementById('j').value="l";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "library";



	}
	
	
	
								
		function eques203()
{

	document.getElementById('question').innerHTML="Always coming but never arrives";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="w";
	document.getElementById('h').value="w";
	document.getElementById('i').innerHTML="o";
	document.getElementById('i').value="o";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "tomorrow";



	}
	
	
								
		function eques204()
{

	document.getElementById('question').innerHTML="Look at me one way and I weigh a whole lot. Turn me around and you�ll see that I am not. ";
	document.getElementById('a').innerHTML="o";
	document.getElementById('a').value="o";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="g";
	document.getElementById('e').value="g";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="m";
	document.getElementById('h').value="m";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "ton";



	}
	
	
	
	
								
		function eques205()
{

	document.getElementById('question').innerHTML="Pedro hides but you can still see his head.";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="w";
	document.getElementById('e').value="w";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="f";
	document.getElementById('g').value="f";
	document.getElementById('h').innerHTML="m";
	document.getElementById('h').value="m";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "nail";



	}
	
	
	
		
				
								
		function eques206()
{

	document.getElementById('question').innerHTML="Riddle me, riddle me, here comes a roaring chain";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="p";
	document.getElementById('g').value="p";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "train";



	}
	
	
	
	
				
								
		function eques207()
{

	document.getElementById('question').innerHTML="Here comes Kaka, walking with an open leg.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "scissors";



	}
	
	
	
	
								
		function eques208()
{

	document.getElementById('question').innerHTML="Adam's hair, you can't count.";
	document.getElementById('a').innerHTML="k";
	document.getElementById('a').value="k";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "rain";



	}
	
	
	
	
								
		function eques209()
{

	document.getElementById('question').innerHTML="Rice cake of the king, that you cannot divide.";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="v";
	document.getElementById('b').value="v";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="u";
	document.getElementById('e').value="u";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "water";



	}
	
	
	
	
								
		function eques210()
{

	document.getElementById('question').innerHTML="Roll in the morning, leaf in the afternoon.";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="l";
	document.getElementById('c').value="l";
	document.getElementById('d').innerHTML="m";
	document.getElementById('d').value="m";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="r";
	document.getElementById('i').value="r";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "mat";



	}
	
	
	
	
	
	
		
								
		function eques211()
{

	document.getElementById('question').innerHTML="It has one entrance, but has three exit.";
	document.getElementById('a').innerHTML="v";
	document.getElementById('a').value="v";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="z";
	document.getElementById('i').value="z";
	document.getElementById('j').innerHTML="d";
	document.getElementById('j').value="d";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "dress";



	}
	
	
	
	
	
								
		function eques212()
{

	document.getElementById('question').innerHTML="Big Square Bag of Mr Jacob, to use it you have to turn it upside down.";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="a";
	document.getElementById('d').value="a";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="g";
	document.getElementById('h').value="g";
	document.getElementById('i').innerHTML="y";
	document.getElementById('i').value="y";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "net";



	}
	
	
	
								
		function eques213()
{

	document.getElementById('question').innerHTML="Two birds, trying to balance in one twig.";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="n";
	document.getElementById('b').value="n";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="t";
	document.getElementById('d').value="t";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "earrings";



	}
	
	
								
		function eques214()
{

	document.getElementById('question').innerHTML="It's here it's here, but you cannot see";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="g";
	document.getElementById('e').value="g";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "wind";



	}
	
	
	
	
								
		function eques215()
{

	document.getElementById('question').innerHTML="My cow in Manila, you can hear his moo.";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="r";
	document.getElementById('c').value="r";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="w";
	document.getElementById('e').value="w";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="u";
	document.getElementById('h').value="u";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "thunder";



	}
	
	
	
		
				
								
		function eques216()
{

	document.getElementById('question').innerHTML="General Negro pass by and eveybody die.";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="t";
	document.getElementById('c').value="t";
	document.getElementById('d').innerHTML="g";
	document.getElementById('d').value="g";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="p";
	document.getElementById('g').value="p";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="i";
	document.getElementById('j').value="i";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "night";



	}
	
	
	
	
				
								
		function eques217()
{

	document.getElementById('question').innerHTML="I have a friend and he is with me everywhere I go.";
	document.getElementById('a').innerHTML="w";
	document.getElementById('a').value="w";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="i";
	document.getElementById('e').value="i";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "shadow";



	}
	
	
	
	
								
		function eques218()
{

	document.getElementById('question').innerHTML="I have a pet, his body is full of coins.";
	document.getElementById('a').innerHTML="y";
	document.getElementById('a').value="y";
	document.getElementById('b').innerHTML="r";
	document.getElementById('b').value="r";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="x";
	document.getElementById('d').value="x";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="b";
	document.getElementById('h').value="b";
	document.getElementById('i').innerHTML="o";
	document.getElementById('i').value="o";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "moneybox";



	}
	
	
	
	
								
		function eques219()
{

	document.getElementById('question').innerHTML="I can't see it in the light but I can see it in the dark.";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="v";
	document.getElementById('b').value="v";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="u";
	document.getElementById('e').value="u";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="t";
	document.getElementById('j').value="t";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "star";



	}
	
	
	
	
								
		function eques220()
{

	document.getElementById('question').innerHTML="Maria's skirt, in different colors.";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="l";
	document.getElementById('c').value="l";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="o";
	document.getElementById('j').value="o";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "rainbow";



	}
	
	
	
	
	
	
	
	
	
		
								
		function eques221()
{

	document.getElementById('question').innerHTML="One plate, can be seen around the world.";
	document.getElementById('a').innerHTML="v";
	document.getElementById('a').value="v";
	document.getElementById('b').innerHTML="o";
	document.getElementById('b').value="o";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="m";
	document.getElementById('j').value="m";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "moon";



	}
	
	
	
	
	
								
		function eques222()
{

	document.getElementById('question').innerHTML="House of the Lieutenant ,with only one post.";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="e";
	document.getElementById('b').value="e";
	document.getElementById('c').innerHTML="m";
	document.getElementById('c').value="m";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="y";
	document.getElementById('i').value="y";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "umbrella";



	}
	
	
	
								
		function eques223()
{

	document.getElementById('question').innerHTML="A princess sitting in a cup.";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="s";
	document.getElementById('d').value="s";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "cashew";



	}
	
	
								
		function eques224()
{

	document.getElementById('question').innerHTML="Shape like a heart, gold in color, sweet to smell and good to eat.";
	document.getElementById('a').innerHTML="m";
	document.getElementById('a').value="m";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="g";
	document.getElementById('e').value="g";
	document.getElementById('f').innerHTML="n";
	document.getElementById('f').value="n";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "mango";



	}
	
	
	
	
								
		function eques225()
{

	document.getElementById('question').innerHTML="Seed that is wrap in steel, steel that is wrap in crystal.";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="z";
	document.getElementById('d').value="z";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="h";
	document.getElementById('g').value="h";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="n";
	document.getElementById('i').value="n";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "lanzones";



	}
	
	
	
		
				
								
		function eques226()
{

	document.getElementById('question').innerHTML="What fruit in the world that the seed is out?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="h";
	document.getElementById('b').value="h";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="p";
	document.getElementById('g').value="p";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="c";
	document.getElementById('j').value="c";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "cashew";



	}
	
	
	
	
				
								
		function eques227()
{

	document.getElementById('question').innerHTML="Here comes Ingkong, sitting in a fish catcher.";
	document.getElementById('a').innerHTML="w";
	document.getElementById('a').value="w";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="c";
	document.getElementById('j').value="c";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "cashew";



	}
	
	
	
	
								
		function eques228()
{

	document.getElementById('question').innerHTML="The princess is on her back, but her head is still facing us.";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="p";
	document.getElementById('d').value="p";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="r";
	document.getElementById('g').value="r";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="s";
	document.getElementById('j').value="s";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "starapple";



	}
	
	
	
	
								
		function eques229()
{

	document.getElementById('question').innerHTML="Her skin is green, her seed is black, her tissue is red, who is she?";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="m";
	document.getElementById('i').value="m";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "watermelon";



	}
	
	
	
	
								
		function eques230()
{

	document.getElementById('question').innerHTML="House of Pedro, full of stone.";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="p";
	document.getElementById('c').value="p";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="y";
	document.getElementById('g').value="y";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="p";
	document.getElementById('i').value="p";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "papaya";



	}
	
	
	
	
	
	
	
	
	
		
								
		function eques231()
{

	document.getElementById('question').innerHTML="An island of pig with a hair as hard as a nail.";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="u";
	document.getElementById('e').value="u";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="k";
	document.getElementById('g').value="k";
	document.getElementById('h').innerHTML="c";
	document.getElementById('h').value="c";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="j";
	document.getElementById('j').value="j";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "jackfruit";



	}
	
	
	
	
	
								
		function eques232()
{

	document.getElementById('question').innerHTML="The virgin gave birth, but throw the nappy.";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="n";
	document.getElementById('b').value="n";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="y";
	document.getElementById('i').value="y";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "banana";



	}
	
	
	
								
		function eques233()
{

	document.getElementById('question').innerHTML="The queen tilt her head but the crown did not fall.";
	document.getElementById('a').innerHTML="g";
	document.getElementById('a').value="g";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="u";
	document.getElementById('d').value="u";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="v";
	document.getElementById('j').value="v";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "guava";



	}
	
	
								
		function eques234()
{

	document.getElementById('question').innerHTML="There is a sky, there is soil, there is water, but no fish.";
	document.getElementById('a').innerHTML="u";
	document.getElementById('a').value="u";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="c";
	document.getElementById('e').value="c";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="d";
	document.getElementById('h').value="d";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "coconut";



	}
	
	
	
	
								
		function eques235()
{

	document.getElementById('question').innerHTML="Not a princess, not a queen, but wears a crown.";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="o";
	document.getElementById('c').value="o";
	document.getElementById('d').innerHTML="z";
	document.getElementById('d').value="z";
	document.getElementById('e').innerHTML="s";
	document.getElementById('e').value="s";
	document.getElementById('f').innerHTML="v";
	document.getElementById('f').value="v";
	document.getElementById('g').innerHTML="g";
	document.getElementById('g').value="g";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "guava";



	}
	
	
	
		
				
								
		function eques236()
{

	document.getElementById('question').innerHTML="A beautiful girl, you can't count her eyes.";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="p";
	document.getElementById('g').value="p";
	document.getElementById('h').innerHTML="s";
	document.getElementById('h').value="s";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "pineapple";



	}
	
	
	
	
				
								
		function eques237()
{

	document.getElementById('question').innerHTML="Flavors your food and divides the year up.";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="c";
	document.getElementById('j').value="c";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "season";



	}
	
	
	
	
								
		function eques238()
{

	document.getElementById('question').innerHTML="This creature travels in a gaggle.";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="g";
	document.getElementById('b').value="g";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="s";
	document.getElementById('j').value="s";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "goose";



	}
	
	
	
	
								
		function eques239()
{

	document.getElementById('question').innerHTML="Nature�s way of applauding a lightning strike.";
	document.getElementById('a').innerHTML="e";
	document.getElementById('a').value="e";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="d";
	document.getElementById('e').value="d";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="u";
	document.getElementById('g').value="u";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="h";
	document.getElementById('i').value="h";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "thunder";



	}
	
	
	
	
								
		function eques240()
{

	document.getElementById('question').innerHTML="These help engines spin and trousers stay up.";
	document.getElementById('a').innerHTML="b";
	document.getElementById('a').value="b";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="y";
	document.getElementById('g').value="y";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="p";
	document.getElementById('i').value="p";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "belt";



	}
	
	
	
	
			
								
		function eques241()
{

	document.getElementById('question').innerHTML="Throw me off the highest building, and I shall not break, but toss me in the smallest pool, and my life's at stake.";
	document.getElementById('a').innerHTML="f";
	document.getElementById('a').value="f";
	document.getElementById('b').innerHTML="i";
	document.getElementById('b').value="i";
	document.getElementById('c').innerHTML="s";
	document.getElementById('c').value="s";
	document.getElementById('d').innerHTML="r";
	document.getElementById('d').value="r";
	document.getElementById('e').innerHTML="u";
	document.getElementById('e').value="u";
	document.getElementById('f').innerHTML="t";
	document.getElementById('f').value="t";
	document.getElementById('g').innerHTML="k";
	document.getElementById('g').value="k";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="j";
	document.getElementById('j').value="j";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "tissue";



	}
	
	
	
	
	
								
		function eques242()
{

	document.getElementById('question').innerHTML="A word I know, six letters it contains, subtract one, and twelve remains.";
	document.getElementById('a').innerHTML="s";
	document.getElementById('a').value="s";
	document.getElementById('b').innerHTML="n";
	document.getElementById('b').value="n";
	document.getElementById('c').innerHTML="d";
	document.getElementById('c').value="d";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="n";
	document.getElementById('e').value="n";
	document.getElementById('f').innerHTML="a";
	document.getElementById('f').value="a";
	document.getElementById('g').innerHTML="l";
	document.getElementById('g').value="l";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="z";
	document.getElementById('i').value="z";
	document.getElementById('j').innerHTML="u";
	document.getElementById('j').value="u";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "dozens";



	}
	
	
	
								
		function eques243()
{

	document.getElementById('question').innerHTML="What cannot talk, but will always respond when spoken to?";
	document.getElementById('a').innerHTML="c";
	document.getElementById('a').value="c";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="h";
	document.getElementById('c').value="h";
	document.getElementById('d').innerHTML="u";
	document.getElementById('d').value="u";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="g";
	document.getElementById('f').value="g";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="w";
	document.getElementById('i').value="w";
	document.getElementById('j').innerHTML="e";
	document.getElementById('j').value="e";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "echo";



	}
	
	
								
		function eques244()
{

	document.getElementById('question').innerHTML="What is always too late?";
	document.getElementById('a').innerHTML="r";
	document.getElementById('a').value="r";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="g";
	document.getElementById('c').value="g";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="c";
	document.getElementById('e').value="c";
	document.getElementById('f').innerHTML="e";
	document.getElementById('f').value="e";
	document.getElementById('g').innerHTML="e";
	document.getElementById('g').value="e";
	document.getElementById('h').innerHTML="r";
	document.getElementById('h').value="r";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "regret";



	}
	
	
	
	
								
		function eques245()
{

	document.getElementById('question').innerHTML="Ligaya's house, full of eyes";
	document.getElementById('a').innerHTML="a";
	document.getElementById('a').value="a";
	document.getElementById('b').innerHTML="p";
	document.getElementById('b').value="p";
	document.getElementById('c').innerHTML="i";
	document.getElementById('c').value="i";
	document.getElementById('d').innerHTML="n";
	document.getElementById('d').value="n";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="p";
	document.getElementById('f').value="p";
	document.getElementById('g').innerHTML="g";
	document.getElementById('g').value="g";
	document.getElementById('h').innerHTML="l";
	document.getElementById('h').value="l";
	document.getElementById('i').innerHTML="e";
	document.getElementById('i').value="e";
	document.getElementById('j').innerHTML="p";
	document.getElementById('j').value="p";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "pineapple";



	}
	
	
	
		
				
								
		function eques246()
{

	document.getElementById('question').innerHTML="Opens without mouth, smiles silently.";
	document.getElementById('a').innerHTML="p";
	document.getElementById('a').value="p";
	document.getElementById('b').innerHTML="l";
	document.getElementById('b').value="l";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="e";
	document.getElementById('d').value="e";
	document.getElementById('e').innerHTML="f";
	document.getElementById('e').value="f";
	document.getElementById('f').innerHTML="i";
	document.getElementById('f').value="i";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="w";
	document.getElementById('h').value="w";
	document.getElementById('i').innerHTML="a";
	document.getElementById('i').value="a";
	document.getElementById('j').innerHTML="r";
	document.getElementById('j').value="r";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "flower";



	}
	
	
	
	
				
								
		function eques247()
{

	document.getElementById('question').innerHTML="Kill him to save him.";
	document.getElementById('a').innerHTML="n";
	document.getElementById('a').value="n";
	document.getElementById('b').innerHTML="d";
	document.getElementById('b').value="d";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="c";
	document.getElementById('d').value="c";
	document.getElementById('e').innerHTML="e";
	document.getElementById('e').value="e";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="s";
	document.getElementById('g').value="s";
	document.getElementById('h').innerHTML="h";
	document.getElementById('h').value="h";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="c";
	document.getElementById('j').value="c";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "candle";



	}
	
	
	
	
								
		function eques248()
{

	document.getElementById('question').innerHTML="Can cook without heat, smoking without cold.";
	document.getElementById('a').innerHTML="i";
	document.getElementById('a').value="i";
	document.getElementById('b').innerHTML="g";
	document.getElementById('b').value="g";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="o";
	document.getElementById('d').value="o";
	document.getElementById('e').innerHTML="l";
	document.getElementById('e').value="l";
	document.getElementById('f').innerHTML="o";
	document.getElementById('f').value="o";
	document.getElementById('g').innerHTML="c";
	document.getElementById('g').value="c";
	document.getElementById('h').innerHTML="a";
	document.getElementById('h').value="a";
	document.getElementById('i').innerHTML="t";
	document.getElementById('i').value="t";
	document.getElementById('j').innerHTML="s";
	document.getElementById('j').value="s";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "ice";



	}
	
	
	
	
								
		function eques249()
{

	document.getElementById('question').innerHTML="Throw me and I'll be back.";
	document.getElementById('a').innerHTML="y";
	document.getElementById('a').value="y";
	document.getElementById('b').innerHTML="t";
	document.getElementById('b').value="t";
	document.getElementById('c').innerHTML="a";
	document.getElementById('c').value="a";
	document.getElementById('d').innerHTML="w";
	document.getElementById('d').value="w";
	document.getElementById('e').innerHTML="o";
	document.getElementById('e').value="o";
	document.getElementById('f').innerHTML="r";
	document.getElementById('f').value="r";
	document.getElementById('g').innerHTML="o";
	document.getElementById('g').value="o";
	document.getElementById('h').innerHTML="e";
	document.getElementById('h').value="e";
	document.getElementById('i').innerHTML="y";
	document.getElementById('i').value="y";
	document.getElementById('j').innerHTML="n";
	document.getElementById('j').value="n";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "yoyo";



	}
	
	
	
	
								
		function eques250()
{

	document.getElementById('question').innerHTML="Water into stone, stone into water.";
	document.getElementById('a').innerHTML="l";
	document.getElementById('a').value="l";
	document.getElementById('b').innerHTML="a";
	document.getElementById('b').value="a";
	document.getElementById('c').innerHTML="e";
	document.getElementById('c').value="e";
	document.getElementById('d').innerHTML="i";
	document.getElementById('d').value="i";
	document.getElementById('e').innerHTML="r";
	document.getElementById('e').value="r";
	document.getElementById('f').innerHTML="l";
	document.getElementById('f').value="l";
	document.getElementById('g').innerHTML="y";
	document.getElementById('g').value="y";
	document.getElementById('h').innerHTML="t";
	document.getElementById('h').value="t";
	document.getElementById('i').innerHTML="s";
	document.getElementById('i').value="s";
	document.getElementById('j').innerHTML="a";
	document.getElementById('j').value="a";	
	document.getElementById("numero").innerHTML = "riddle no: " + numb;

right_ans = "salt";



	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function submit()
{


 document.getElementById("dito").innerHTML = "";
 

if(sagot==right_ans)
{


score++;
numb++;




document.getElementById("score").innerHTML = "score: " + score;
document.getElementById("ans").innerHTML = "";
alert("You are Correct!!!");


if(numb == 6 || numb == 11 || numb == 16 || numb == 21 || numb == 26 || numb == 31 || numb == 36 || numb == 41 || numb == 46 || numb == 51 || numb == 56 || numb == 61 || numb == 66 || numb == 71 || numb == 76 || numb == 81 || numb == 86 || numb == 91 || numb == 96 || numb == 101 || numb == 106 || numb == 111 || numb == 116 || numb == 121 || numb == 126 || numb == 131 || numb == 136 || numb == 141 || numb == 146 || numb == 151 || numb == 156 || numb == 161 || numb == 166 || numb == 171 || numb == 176 || numb == 181 || numb == 186 || numb == 191 || numb == 196 || numb == 201 || numb == 206 || numb == 211 || numb == 216 || numb == 221 || numb == 226 || numb == 231 || numb == 236 || numb == 241 || numb == 246)
{

$("#hint").show(1500);
$("#hint2").show(1500);
$("#hint3").show(1500);

$("#f_hint").hide();
$("#f_hint2").hide();
$("#f_hint3").hide();

}


p++;
sagot = "";






if(numb>250)
{
document.getElementById("submit").href = "#winner_e_u";

document.getElementById("fscore_e_u").innerHTML = "score: " + score;
}

else{
start_e_u();
}
}
else
{



life--;


if (life == 0){$("#lif3").hide();}
document.getElementById("score").innerHTML = "score: " + score;
document.getElementById("ans").innerHTML = "";
alert("You are Wrong!!");


if (life == 2){$("#lif1").hide(1500);}
else if (life == 1){$("#lif2").hide(1500);}




if(life == 0)
{

document.getElementById("submit").href = "#exit_e_u";

document.getElementById("gfscore_e_u").innerHTML = "score: " + score;

}


else{
numb++;

p++;

sagot = "";


if(numb == 6 || numb == 11 || numb == 16 || numb == 21 || numb == 26 || numb == 31 || numb == 36 || numb == 41 || numb == 46 || numb == 51 || numb == 56 || numb == 61 || numb == 66 || numb == 71 || numb == 76 || numb == 81 || numb == 86 || numb == 91 || numb == 96 || numb == 101 || numb == 106 || numb == 111 || numb == 116 || numb == 121 || numb == 126 || numb == 131 || numb == 136 || numb == 141 || numb == 146 || numb == 151 || numb == 156 || numb == 161 || numb == 166 || numb == 171 || numb == 176 || numb == 181 || numb == 186 || numb == 191 || numb == 196 || numb == 201 || numb == 206 || numb == 211 || numb == 216 || numb == 221 || numb == 226 || numb == 231 || numb == 236 || numb == 241 || numb == 246)
{

$("#hint").show(1500);
$("#hint2").show(1500);
$("#hint3").show(1500);

$("#f_hint").hide();
$("#f_hint2").hide();
$("#f_hint3").hide();

}

if(numb>250)
{
document.getElementById("submit").href = "#winner_e_u";

document.getElementById("fscore_e_u").innerHTML = "score: " + score;
}


start_e_u();
}

}


changeColor();
}


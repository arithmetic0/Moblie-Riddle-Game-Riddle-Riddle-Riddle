
var status = 0;

function changeColor(){
	
	
	
	

	

		if(status == 0)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#03eba2";
		status++;
		}
		else if(status == 1)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#ed6d6d";
		status++;
		}
		else if(status == 2)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#fabb84";
		status++;
		}
		else if(status == 3)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#baf04f";
		status++;
		}
		else if(status == 4)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#ebe154";
		status++;
		}
		else if(status == 5)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#ebc681";
		status++;
		}
		else if(status == 6)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#4ff07a";
		status++;
		}
		else if(status == 7)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#4f6af0";
		status++;
		}
		else if(status == 8)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#ed517a";
		status++;
		}
		else if(status == 9)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#ed51d8";
		status++;
		}
		else if(status == 10)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#51c3ed";
		status++;
		}
		else if(status == 11)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#4ff0c5";
		status++;
		}
		else if(status == 12)
		{
		document.getElementById("e_untimed").style.backgroundColor = "#b651f0";
		status++;
		}
		
		
		

		else{
		document.getElementById("e_untimed").style.backgroundColor = "#eb5252";
		status = 0;	
		}
}


function changeColor2(){
	
	
	
	

	

		if(status == 0)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#03eba2";
		status++;
		}
		else if(status == 1)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#ed6d6d";
		status++;
		}
		else if(status == 2)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#fabb84";
		status++;
		}
		else if(status == 3)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#baf04f";
		status++;
		}
		else if(status == 4)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#ebe154";
		status++;
		}
		else if(status == 5)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#ebc681";
		status++;
		}
		else if(status == 6)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#4ff07a";
		status++;
		}
		else if(status == 7)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#4f6af0";
		status++;
		}
		else if(status == 8)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#ed517a";
		status++;
		}
		else if(status == 9)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#ed51d8";
		status++;
		}
		else if(status == 10)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#51c3ed";
		status++;
		}
		else if(status == 11)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#4ff0c5";
		status++;
		}
		else if(status == 12)
		{
		document.getElementById("t_untimed").style.backgroundColor = "#b651f0";
		status++;
		}
		
		
		

		else{
		document.getElementById("t_untimed").style.backgroundColor = "#eb5252";
		status = 0;	
		}
}



function changeColor3(){
	
	
	
	

	

		if(status == 0)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#03eba2";
		status++;
		}
		else if(status == 1)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#ed6d6d";
		status++;
		}
		else if(status == 2)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#fabb84";
		status++;
		}
		else if(status == 3)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#baf04f";
		status++;
		}
		else if(status == 4)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#ebe154";
		status++;
		}
		else if(status == 5)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#ebc681";
		status++;
		}
		else if(status == 6)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#4ff07a";
		status++;
		}
		else if(status == 7)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#4f6af0";
		status++;
		}
		else if(status == 8)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#ed517a";
		status++;
		}
		else if(status == 9)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#ed51d8";
		status++;
		}
		else if(status == 10)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#51c3ed";
		status++;
		}
		else if(status == 11)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#4ff0c5";
		status++;
		}
		else if(status == 12)
		{
		document.getElementById("m_untimed").style.backgroundColor = "#b651f0";
		status++;
		}
		
		
		

		else{
		document.getElementById("m_untimed").style.backgroundColor = "#eb5252";
		status = 0;	
		}
}



function changeColor4(){
	
	
	
	

	

		if(status == 0)
		{
		document.getElementById("e_timed").style.backgroundColor = "#03eba2";
		status++;
		}
		else if(status == 1)
		{
		document.getElementById("e_timed").style.backgroundColor = "#ed6d6d";
		status++;
		}
		else if(status == 2)
		{
		document.getElementById("e_timed").style.backgroundColor = "#fabb84";
		status++;
		}
		else if(status == 3)
		{
		document.getElementById("e_timed").style.backgroundColor = "#baf04f";
		status++;
		}
		else if(status == 4)
		{
		document.getElementById("e_timed").style.backgroundColor = "#ebe154";
		status++;
		}
		else if(status == 5)
		{
		document.getElementById("e_timed").style.backgroundColor = "#ebc681";
		status++;
		}
		else if(status == 6)
		{
		document.getElementById("e_timed").style.backgroundColor = "#4ff07a";
		status++;
		}
		else if(status == 7)
		{
		document.getElementById("e_timed").style.backgroundColor = "#4f6af0";
		status++;
		}
		else if(status == 8)
		{
		document.getElementById("e_timed").style.backgroundColor = "#ed517a";
		status++;
		}
		else if(status == 9)
		{
		document.getElementById("e_timed").style.backgroundColor = "#ed51d8";
		status++;
		}
		else if(status == 10)
		{
		document.getElementById("e_timed").style.backgroundColor = "#51c3ed";
		status++;
		}
		else if(status == 11)
		{
		document.getElementById("e_timed").style.backgroundColor = "#4ff0c5";
		status++;
		}
		else if(status == 12)
		{
		document.getElementById("e_timed").style.backgroundColor = "#b651f0";
		status++;
		}
		
		
		

		else{
		document.getElementById("e_timed").style.backgroundColor = "#eb5252";
		status = 0;	
		}
}



function changeColor5(){
	
	
	
	

	

		if(status == 0)
		{
		document.getElementById("t_timed").style.backgroundColor = "#03eba2";
		status++;
		}
		else if(status == 1)
		{
		document.getElementById("t_timed").style.backgroundColor = "#ed6d6d";
		status++;
		}
		else if(status == 2)
		{
		document.getElementById("t_timed").style.backgroundColor = "#fabb84";
		status++;
		}
		else if(status == 3)
		{
		document.getElementById("t_timed").style.backgroundColor = "#baf04f";
		status++;
		}
		else if(status == 4)
		{
		document.getElementById("t_timed").style.backgroundColor = "#ebe154";
		status++;
		}
		else if(status == 5)
		{
		document.getElementById("t_timed").style.backgroundColor = "#ebc681";
		status++;
		}
		else if(status == 6)
		{
		document.getElementById("t_timed").style.backgroundColor = "#4ff07a";
		status++;
		}
		else if(status == 7)
		{
		document.getElementById("t_timed").style.backgroundColor = "#4f6af0";
		status++;
		}
		else if(status == 8)
		{
		document.getElementById("t_timed").style.backgroundColor = "#ed517a";
		status++;
		}
		else if(status == 9)
		{
		document.getElementById("t_timed").style.backgroundColor = "#ed51d8";
		status++;
		}
		else if(status == 10)
		{
		document.getElementById("t_timed").style.backgroundColor = "#51c3ed";
		status++;
		}
		else if(status == 11)
		{
		document.getElementById("t_timed").style.backgroundColor = "#4ff0c5";
		status++;
		}
		else if(status == 12)
		{
		document.getElementById("t_timed").style.backgroundColor = "#b651f0";
		status++;
		}
		
		
		

		else{
		document.getElementById("t_timed").style.backgroundColor = "#eb5252";
		status = 0;	
		}
}



function changeColor6(){
	
	
	
	

	

		if(status == 0)
		{
		document.getElementById("m_timed").style.backgroundColor = "#03eba2";
		status++;
		}
		else if(status == 1)
		{
		document.getElementById("m_timed").style.backgroundColor = "#ed6d6d";
		status++;
		}
		else if(status == 2)
		{
		document.getElementById("m_timed").style.backgroundColor = "#fabb84";
		status++;
		}
		else if(status == 3)
		{
		document.getElementById("m_timed").style.backgroundColor = "#baf04f";
		status++;
		}
		else if(status == 4)
		{
		document.getElementById("m_timed").style.backgroundColor = "#ebe154";
		status++;
		}
		else if(status == 5)
		{
		document.getElementById("m_timed").style.backgroundColor = "#ebc681";
		status++;
		}
		else if(status == 6)
		{
		document.getElementById("m_timed").style.backgroundColor = "#4ff07a";
		status++;
		}
		else if(status == 7)
		{
		document.getElementById("m_timed").style.backgroundColor = "#4f6af0";
		status++;
		}
		else if(status == 8)
		{
		document.getElementById("m_timed").style.backgroundColor = "#ed517a";
		status++;
		}
		else if(status == 9)
		{
		document.getElementById("m_timed").style.backgroundColor = "#ed51d8";
		status++;
		}
		else if(status == 10)
		{
		document.getElementById("m_timed").style.backgroundColor = "#51c3ed";
		status++;
		}
		else if(status == 11)
		{
		document.getElementById("m_timed").style.backgroundColor = "#4ff0c5";
		status++;
		}
		else if(status == 12)
		{
		document.getElementById("m_timed").style.backgroundColor = "#b651f0";
		status++;
		}
		
		
		

		else{
		document.getElementById("m_timed").style.backgroundColor = "#eb5252";
		status = 0;	
		}
}





function statusOff(){
	
	status = 0;
}
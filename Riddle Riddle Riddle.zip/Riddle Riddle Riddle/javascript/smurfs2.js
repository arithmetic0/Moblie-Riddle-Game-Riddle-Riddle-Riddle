var tp = 1 ;
var tans = "" ;
var tsagot = "";
var tright_ans = "" ;
var tlife = 3;
var tscore = 0;
var tnumb = 1;
var let_num2 = "";





function bura2()
{
var dine = tsagot.length - 1;

tsagot = tsagot.substring(0,dine);
document.getElementById("tans").innerHTML = tsagot;

var dindin = let_num2.length - 1;
var pj = let_num2.charAt(dindin);
if(pj == "a")
{$("#ta").show(200);
let_num2 = let_num2.substring(0,dindin);
}
else if(pj == "b")
{$("#tb").show(200);
let_num2 = let_num2.substring(0,dindin);}
else if(pj == "c")
{$("#tc").show(200);
let_num2 = let_num2.substring(0,dindin);}
else if(pj == "d")
{$("#td").show(200);
let_num2 = let_num2.substring(0,dindin);}
else if(pj == "e")
{$("#te").show(200);
let_num2 = let_num2.substring(0,dindin);}
else if(pj == "f")
{$("#tf").show(200);
let_num2 = let_num2.substring(0,dindin);}
else if(pj == "g")
{$("#tg").show(200);
let_num2 = let_num2.substring(0,dindin);}
else if(pj == "h")
{$("#th").show(200);
let_num2 = let_num2.substring(0,dindin);}
else if(pj == "i")
{$("#ti").show(200);
let_num2 = let_num2.substring(0,dindin);}
else if(pj == "j")
{$("#tj").show(200);
let_num2 = let_num2.substring(0,dindin);}




}
























function homing2()
{
  var x;
    if (confirm("You want to quit?") == true) {
 document.getElementById("2home_b").href =  "#page1";
  } else {
 document.getElementById("2home_b").href =  "";
    }
}












$(document).ready(function(){
$("#ta").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#tb").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#tc").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#td").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#te").click(function(){
$(this).hide(200);
});
});








$(document).ready(function(){
$("#tf").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#tg").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#th").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#ti").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#tj").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#treset").click(function(){
$("#ta,#tc,#tb,#td,#te,#tg,#tf,#th,#ti,#tj").show(200);
});
});


$(document).ready(function(){
$("#tsubmit").click(function(){
$("#ta,#tc,#tb,#td,#te,#tg,#tf,#th,#ti,#tj").show(200);
});
});





$(document).ready(function(){
$("#thint").click(function(){
$(this).hide();
$("#f_thint").show();
});
});


$(document).ready(function(){
$("#thint2").click(function(){
$(this).hide();
$("#f_thint2").show();
});
});


$(document).ready(function(){
$("#thint3").click(function(){
$(this).hide();
$("#f_thint3").show();
});
});


function thint()
{

var hinto = tright_ans.length;

$("#tdito").show(500);

document.getElementById("tdito").innerHTML =  "consist of " + hinto + " Letters";

}




function thint2()
{

var hinto = tright_ans.charAt(0);

$("#tdito").show(500);

document.getElementById("tdito").innerHTML =  "starts with letter: " + hinto;

}


function thint3()
{
var x = tright_ans.length - 1;
var hinto = tright_ans.charAt(x);

$("#tdito").show(500);

document.getElementById("tdito").innerHTML =  "ends with letter: " + hinto;

}




function gokay_t_u()
{
var tp = 1 ;
var tans = "" ;
var tsagot = "";
var tright_ans = "" ;
var tlife = 3;
var tscore = 0;
var tnumb = 1;


}




function cokay_t_u()
{
var tp = 1 ;
var tans = "" ;
var tsagot = "";
var tright_ans = "" ;
var tlife = 3;
var tscore = 0;
var tnumb = 1;


}

function start_t_u()
{

var random = Math.floor(Math.random()*2);
if(random==0){random++;}




if(tp==1)
	{
		
	tques1();

	}
	else if(tp==2)
	{
		
	tques2();

	}
	else if(tp==3)
		
	{
	tques3();

	}

	else if(tp==4)
		
	{
	tques4();

	}
	else if(tp==5)
		
	{
	tques5();

	}

	else if(tp==6)
		
	{
	tques6();

	}
	else if(tp==7)
		
	{
	tques7();

	}
	else if(tp==8)
		
	{
	tques8();

	}
	else if(tp==9)
		
	{
	tques9();

	}
	else if(tp==10)
		
	{
	tques10();

	}

	

	else if(tp==11)
	{
		
	tques11();

	}
	else if(tp==12)
	{
		
	tques12();

	}
	else if(tp==13)
		
	{
	tques13();

	}

	else if(tp==14)
		
	{
	tques14();

	}
	else if(tp==15)
		
	{
	tques15();

	}

	else if(tp==16)
		
	{
	tques16();

	}
	else if(tp==17)
		
	{
	tques17();

	}
	else if(tp==18)
		
	{
	tques18();

	}
	else if(tp==19)
		
	{
	tques19();

	}
	else if(tp==20)
		
	{
	tques20();

	}

	else if(tp==21)
	{
		
	tques21();

	}
	else if(tp==22)
	{
		
	tques22();

	}
	else if(tp==23)
		
	{
	tques23();

	}

	else if(tp==24)
		
	{
	tques24();

	}
	else if(tp==25)
		
	{
	tques25();

	}

	else if(tp==26)
		
	{
	tques26();

	}
	else if(tp==27)
		
	{
	tques27();

	}
	else if(tp==28)
		
	{
	tques28();

	}
	else if(tp==29)
		
	{
	tques29();

	}
	else if(tp==30)
		
	{
	tques30();

	}
	
	
	else if(tp==31)
	{
		
	tques31();

	}
	else if(tp==32)
	{
		
	tques32();

	}
	else if(tp==33)
		
	{
	tques33();

	}

	else if(tp==34)
		
	{
	tques34();

	}
	else if(tp==35)
		
	{
	tques35();

	}

	else if(tp==36)
		
	{
	tques36();

	}
	else if(tp==37)
		
	{
	tques37();

	}
	else if(tp==38)
		
	{
	tques38();

	}
	else if(tp==39)
		
	{
	tques39();

	}
	else if(tp==40)
		
	{
	tques40();

	}
	
	
	
	else if(tp==41)
	{
		
	tques41();

	}
	else if(tp==42)
	{
		
	tques42();

	}
	else if(tp==43)
		
	{
	tques43();

	}

	else if(tp==44)
		
	{
	tques44();

	}
	else if(tp==45)
		
	{
	tques45();

	}

	else if(tp==46)
		
	{
	tques46();

	}
	else if(tp==47)
		
	{
	tques47();

	}
	else if(tp==48)
		
	{
	tques48();

	}
	else if(tp==49)
		
	{
	tques49();

	}
	else if(tp==50)
		
	{
	tques50();

	}
	
	else if(tp==51)
	{
		
	tques51();

	}
	else if(tp==52)
	{
		
	tques52();

	}
	else if(tp==53)
		
	{
	tques53();

	}

	else if(tp==54)
		
	{
	tques54();

	}
	else if(tp==55)
		
	{
	tques55();

	}

	else if(tp==56)
		
	{
	tques56();

	}
	else if(tp==57)
		
	{
	tques57();

	}
	else if(tp==58)
		
	{
	tques58();

	}
	else if(tp==59)
		
	{
	tques59();

	}
	else if(tp==60)
		
	{
	tques60();

	}
	
	
	else if(tp==61)
	{
		
	tques61();

	}
	else if(tp==62)
	{
		
	tques62();

	}
	else if(tp==63)
		
	{
	tques63();

	}

	else if(tp==64)
		
	{
	tques64();

	}
	else if(tp==65)
		
	{
	tques65();

	}

	else if(tp==66)
		
	{
	tques66();

	}
	else if(tp==67)
		
	{
	tques67();

	}
	else if(tp==68)
		
	{
	tques68();

	}
	else if(tp==69)
		
	{
	tques69();

	}
	else if(tp==70)
		
	{
	tques70();

	}
	
	
	else if(tp==71)
	{
		
	tques71();

	}
	else if(tp==72)
	{
		
	tques72();

	}
	else if(tp==73)
		
	{
	tques73();

	}

	else if(tp==74)
		
	{
	tques74();

	}
	else if(tp==75)
		
	{
	tques75();

	}

	else if(tp==76)
		
	{
	tques76();

	}
	else if(tp==77)
		
	{
	tques77();

	}
	else if(tp==78)
		
	{
	tques78();

	}
	else if(tp==79)
		
	{
	tques79();

	}
	else if(tp==80)
		
	{
	tques80();

	}
	
	
	else if(tp==81)
	{
		
	tques81();

	}
	else if(tp==82)
	{
		
	tques82();

	}
	else if(tp==83)
		
	{
	tques83();

	}

	else if(tp==84)
		
	{
	tques84();

	}
	else if(tp==85)
		
	{
	tques85();

	}

	else if(tp==86)
		
	{
	tques86();

	}
	else if(tp==87)
		
	{
	tques87();

	}
	else if(tp==88)
		
	{
	tques88();

	}
	else if(tp==89)
		
	{
	tques89();

	}
	else if(tp==90)
		
	{
	tques90();

	}
	
	
	
	
	else if(tp==91)
	{
		
	tques91();

	}
	else if(tp==92)
	{
		
	tques92();

	}
	else if(tp==93)
		
	{
	tques93();

	}

	else if(tp==94)
		
	{
	tques94();

	}
	else if(tp==95)
		
	{
	tques95();

	}

	else if(tp==96)
		
	{
	tques96();

	}
	else if(tp==97)
		
	{
	tques97();

	}
	else if(tp==98)
		
	{
	tques98();

	}
	else if(tp==99)
		
	{
	tques99();

	}
	else if(tp==100)
		
	{
	tques100();

	}
	
	
	

	else if(tp==101)
	{
		
	tques101();

	}
	else if(tp==102)
	{
		
	tques102();

	}
	else if(tp==103)
		
	{
	tques103();

	}

	else if(tp==104)
		
	{
	tques104();

	}
	else if(tp==105)
		
	{
	tques105();

	}

	else if(tp==106)
		
	{
	tques106();

	}
	else if(tp==107)
		
	{
	tques107();

	}
	else if(tp==108)
		
	{
	tques108();

	}
	else if(tp==109)
		
	{
	tques109();

	}
	else if(tp==110)
		
	{
	tques110();

	}

	

	else if(tp==111)
	{
		
	tques111();

	}
	else if(tp==112)
	{
		
	tques112();

	}
	else if(tp==113)
		
	{
	tques113();

	}

	else if(tp==114)
		
	{
	tques114();

	}
	else if(tp==115)
		
	{
	tques115();

	}

	else if(tp==116)
		
	{
	tques116();

	}
	else if(tp==117)
		
	{
	tques117();

	}
	else if(tp==118)
		
	{
	tques118();

	}
	else if(tp==119)
		
	{
	tques119();

	}
	else if(tp==120)
		
	{
	tques120();

	}

	else if(tp==121)
	{
		
	tques121();

	}
	else if(tp==122)
	{
		
	tques122();

	}
	else if(tp==123)
		
	{
	tques123();

	}

	else if(tp==124)
		
	{
	tques124();

	}
	else if(tp==125)
		
	{
	tques125();

	}

	else if(tp==126)
		
	{
	tques126();

	}
	else if(tp==127)
		
	{
	tques127();

	}
	else if(tp==128)
		
	{
	tques128();

	}
	else if(tp==129)
		
	{
	tques129();

	}
	else if(tp==130)
		
	{
	tques130();

	}
	
	
	else if(tp==131)
	{
		
	tques131();

	}
	else if(tp==132)
	{
		
	tques132();

	}
	else if(tp==133)
		
	{
	tques133();

	}

	else if(tp==134)
		
	{
	tques134();

	}
	else if(tp==135)
		
	{
	tques135();

	}

	else if(tp==136)
		
	{
	tques136();

	}
	else if(tp==137)
		
	{
	tques137();

	}
	else if(tp==138)
		
	{
	tques138();

	}
	else if(tp==139)
		
	{
	tques139();

	}
	else if(tp==140)
		
	{
	tques140();

	}
	
	
	
	else if(tp==141)
	{
		
	tques141();

	}
	else if(tp==142)
	{
		
	tques142();

	}
	else if(tp==143)
		
	{
	tques143();

	}

	else if(tp==144)
		
	{
	tques144();

	}
	else if(tp==145)
		
	{
	tques145();

	}

	else if(tp==146)
		
	{
	tques146();

	}
	else if(tp==147)
		
	{
	tques147();

	}
	else if(tp==148)
		
	{
	tques148();

	}
	else if(tp==149)
		
	{
	tques149();

	}
	else if(tp==150)
		
	{
	tques150();

	}
	
	
	else if(tp==151)
	{
		
	tques151();

	}
	else if(tp==152)
	{
		
	tques152();

	}
	else if(tp==153)
		
	{
	tques153();

	}

	else if(tp==154)
		
	{
	tques154();

	}
	else if(tp==155)
		
	{
	tques155();

	}

	else if(tp==56)
		
	{
	tques56();

	}
	else if(tp==157)
		
	{
	tques157();

	}
	else if(tp==158)
		
	{
	tques158();

	}
	else if(tp==159)
		
	{
	tques159();

	}
	else if(tp==160)
		
	{
	tques160();

	}
	
	
	else if(tp==161)
	{
		
	tques161();

	}
	else if(tp==162)
	{
		
	tques162();

	}
	else if(tp==163)
		
	{
	tques163();

	}

	else if(tp==164)
		
	{
	tques164();

	}
	else if(tp==165)
		
	{
	tques165();

	}

	else if(tp==166)
		
	{
	tques166();

	}
	else if(tp==167)
		
	{
	tques167();

	}
	else if(tp==168)
		
	{
	tques168();

	}
	else if(tp==169)
		
	{
	tques169();

	}
	else if(tp==170)
		
	{
	tques170();

	}
	
	
	else if(tp==171)
	{
		
	tques171();

	}
	else if(tp==172)
	{
		
	tques172();

	}
	else if(tp==173)
		
	{
	tques173();

	}

	else if(tp==174)
		
	{
	tques174();

	}
	else if(tp==175)
		
	{
	tques175();

	}

	else if(tp==176)
		
	{
	tques176();

	}
	else if(tp==177)
		
	{
	tques177();

	}
	else if(tp==178)
		
	{
	tques178();

	}
	else if(tp==179)
		
	{
	tques179();

	}
	else if(tp==180)
		
	{
	tques180();

	}
	
	
	else if(tp==181)
	{
		
	tques181();

	}
	else if(tp==182)
	{
		
	tques182();

	}
	else if(tp==183)
		
	{
	tques183();

	}

	else if(tp==184)
		
	{
	tques184();

	}
	else if(tp==185)
		
	{
	tques185();

	}

	else if(tp==186)
		
	{
	tques186();

	}
	else if(tp==187)
		
	{
	tques187();

	}
	else if(tp==188)
		
	{
	tques188();

	}
	else if(tp==189)
		
	{
	tques189();

	}
	else if(tp==190)
		
	{
	tques190();

	}
	
	
	
	
	else if(tp==191)
	{
		
	tques191();

	}
	else if(tp==192)
	{
		
	tques192();

	}
	else if(tp==193)
		
	{
	tques193();

	}

	else if(tp==194)
		
	{
	tques194();

	}
	else if(tp==195)
		
	{
	tques195();

	}

	else if(tp==196)
		
	{
	tques196();

	}
	else if(tp==197)
		
	{
	tques197();

	}
	else if(tp==198)
		
	{
	tques198();

	}
	else if(tp==199)
		
	{
	tques199();

	}
	else if(tp==200)
		
	{
	tques200();

	}
	
		else if(tp==201)
	{
		
	tques201();

	}
	
		else if(tp==202)
	{
		
	tques202();

	}
	else if(tp==203)
		
	{
	tques203();

	}

	else if(tp==204)
		
	{
	tques204();

	}
	else if(tp==205)
		
	{
	tques205();

	}

	else if(tp==206)
		
	{
	tques206();

	}
	else if(tp==207)
		
	{
	tques207();

	}
	else if(tp==208)
		
	{
	tques208();

	}
	else if(tp==209)
		
	{
	tques209();

	}
	else if(tp==210)
		
	{
	tques210();

	}

	

	else if(tp==211)
	{
		
	tques211();

	}
	else if(tp==212)
	{
		
	tques212();

	}
	else if(tp==213)
		
	{
	tques213();

	}

	else if(tp==214)
		
	{
	tques214();

	}
	else if(tp==215)
		
	{
	tques215();

	}

	else if(tp==216)
		
	{
	tques216();

	}
	else if(tp==217)
		
	{
	tques217();

	}
	else if(tp==218)
		
	{
	tques218();

	}
	else if(tp==219)
		
	{
	tques219();

	}
	else if(tp==220)
		
	{
	tques220();

	}

	else if(tp==221)
	{
		
	tques221();

	}
	else if(tp==222)
	{
		
	tques222();

	}
	else if(tp==223)
		
	{
	tques223();

	}

	else if(tp==224)
		
	{
	tques224();

	}
	else if(tp==225)
		
	{
	tques225();

	}

	else if(tp==226)
		
	{
	tques226();

	}
	else if(tp==227)
		
	{
	tques227();

	}
	else if(tp==228)
		
	{
	tques228();

	}
	else if(tp==229)
		
	{
	tques229();

	}
	else if(tp==230)
		
	{
	tques230();

	}
	
	
	else if(tp==231)
	{
		
	tques231();

	}
	else if(tp==232)
	{
		
	tques232();

	}
	else if(tp==233)
		
	{
	tques233();

	}

	else if(tp==234)
		
	{
	tques234();

	}
	else if(tp==235)
		
	{
	tques235();

	}

	else if(tp==236)
		
	{
	tques236();

	}
	else if(tp==237)
		
	{
	tques237();

	}
	else if(tp==238)
		
	{
	tques238();

	}
	else if(tp==239)
		
	{
	tques239();

	}
	else if(tp==240)
		
	{
	tques240();

	}
	
	
	
	else if(tp==241)
	{
		
	tques241();

	}
	else if(tp==242)
	{
		
	tques242();

	}
	else if(tp==243)
		
	{
	tques243();

	}

	else if(tp==244)
		
	{
	tques244();

	}
	else if(tp==245)
		
	{
	tques245();

	}

	else if(tp==246)
		
	{
	tques246();

	}
	else if(tp==247)
		
	{
	tques247();

	}
	else if(tp==248)
		
	{
	tques248();

	}
	else if(tp==249)
		
	{
	tques249();

	}
	else if(tp==250)
		
	{
	tques250();

	}
	
	
	
	
	
	
	
}







	
	
function ta()
{


var a = document.getElementById("ta").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "a";
}


	
function tb()
{


var a = document.getElementById("tb").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "b";
}



function tc()
{


var a = document.getElementById("tc").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "c";
}





function td()
{


var a = document.getElementById("td").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "d";
}



function te()
{

var a = document.getElementById("te").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "e";
}



function tf()
{

var a = document.getElementById("tf").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "f";
}

function tg()
{

var a = document.getElementById("tg").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "g";
}

function th()
{

var a = document.getElementById("th").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "h";
}

function ti()
{

var a = document.getElementById("ti").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "i";
}

function tj()
{

var a = document.getElementById("tj").value;

tsagot = tsagot + a;

document.getElementById("tans").innerHTML = tsagot;
let_num2 = let_num2 + "j";
}




function treset()
{


tsagot = "";

document.getElementById("tans").innerHTML = tsagot;
}




function tques1()
{

	document.getElementById('tquestion').innerHTML="Baston ng kapitan, Hindi mahawakan.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="c";
	document.getElementById('tb').value="c";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="y";
	document.getElementById('tg').value="y";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="h";
	document.getElementById('ti').value="h";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "ahas";




	}

	
	
	
function tques2()
{

	document.getElementById('tquestion').innerHTML="Heto na si kuya, May sunong sa baga";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="p";
	document.getElementById('tf').value="p";
	document.getElementById('tg').innerHTML="i";
	document.getElementById('tg').value="i";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alitaptap";




	}

	
	
	
	
	
	
function tques3()
{

	document.getElementById('tquestion').innerHTML="Ang loob ay pilak, Siit namimilipit, Ginto't pilak namumulaklak.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="e";
	document.getElementById('tb').value="e";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="l";
	document.getElementById('td').value="l";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="d";
	document.getElementById('tf').value="d";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="m";
	document.getElementById('th').value="m";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="p";
	document.getElementById('tj').value="p";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "ampalaya";




	}

	
	
	
	
	
function tques4()
{

	document.getElementById('tquestion').innerHTML="Ako'y may kaibigan, Kasama ko kahit saan, Mapatubig ay di nalulunod, Mapaapoy ay di nasusunog.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="m";
	document.getElementById('td').value="m";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "anino";




	}

	
			
		function tques5()
{

	document.getElementById('tquestion').innerHTML="Hindi hayop, hindi tao, Hindi natin kaano-ano, Ate nating pareho.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="c";
	document.getElementById('tf').value="c";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="d";
	document.getElementById('ti').value="d";
	document.getElementById('tj').innerHTML="n";
	document.getElementById('tj').value="n";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "atis";




	}

	
	
	
	
	
	
	
	
		function tques6()
{

	document.getElementById('tquestion').innerHTML= "Tubig na nagiging bato, Bato na nagiging tubig.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="m";
	document.getElementById('td').value="m";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="c";
	document.getElementById('tf').value="c";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "asin";





	}

	
	
		
		function tques7()
{

	document.getElementById('tquestion').innerHTML= "Mataas ang paupo, Kesa patayo.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="c";
	document.getElementById('tf').value="c";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "aso";





	}

	
	
		
		function tques8()
{

	document.getElementById('tquestion').innerHTML="Dinadala ko siya, Dinadala ako niya.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="e";
	document.getElementById('te').value="e";
	document.getElementById('tf').innerHTML="y";
	document.getElementById('tf').value="y";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="h";
	document.getElementById('th').value="h";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bakya";




	}

	
	
			
		function tques9()
{

	document.getElementById('tquestion').innerHTML="Alin dito sa buong lupa, Kung lumakad ay tihaya.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="c";
	document.getElementById('tf').value="c";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bangka";




	}

	
	
	
				
		function tques10()
{

	document.getElementById('tquestion').innerHTML="Nakalantay kung gabi, Kung araw ay nakatabi.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="x";
	document.getElementById('tg').value="x";
	document.getElementById('th').innerHTML="h";
	document.getElementById('th').value="h";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "banig";



	}

	
		
				
		function tques11()
{

	document.getElementById('tquestion').innerHTML="Walang bibig, walang pakpak, kahit hari'y kinakausap?";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="x";
	document.getElementById('tg').value="x";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "aklat";



	}

	
	
				
		function tques12()
{

	document.getElementById('tquestion').innerHTML="Isang biyas ng kawayan, Maraming lamang kayamanan ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="s";
	document.getElementById('tg').value="s";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="y";
	document.getElementById('ti').value="y";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alkansya";



	}

	
			function tques13()
{

	document.getElementById('tquestion').innerHTML="Heto , heto na, Malayo pa'y humahalakhak na. ";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="c";
	document.getElementById('tc').value="c";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="y";
	document.getElementById('ti').value="y";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alon";



	}

	
	
	
		
			function tques14()
{

	document.getElementById('tquestion').innerHTML="Pagkatapos na ang reyna'y Makapagpagawa ng templo, Siya na rin ang napreso.";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="c";
	document.getElementById('tc').value="c";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="y";
	document.getElementById('ti').value="y";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "anay";



	}

	
	
	
	
		
			function tques15()
{

	document.getElementById('tquestion').innerHTML="Mayroon akong matapat na alipin, Sunod nang sunod sa akin.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "anino";



	}

	
	
		
		
			function tques16()
{

	document.getElementById('tquestion').innerHTML="Manok kong pula, Inutusan ko ng umaga, Nang umuwi'y gabi na.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="r";
	document.getElementById('td').value="r";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="w";
	document.getElementById('th').value="w";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "araw";



	}

	
	
			
		
			function tques17()
{

	document.getElementById('tquestion').innerHTML="Buhay na hiram lamang, Pinagmulan ng sangkatauhan. ";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="r";
	document.getElementById('td').value="r";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="f";
	document.getElementById('tg').value="f";
	document.getElementById('th').innerHTML="e";
	document.getElementById('th').value="e";
	document.getElementById('ti').innerHTML="d";
	document.getElementById('ti').value="d";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "babae";



	}

	
	
	
			
			function tques18()
{

	document.getElementById('tquestion').innerHTML="Tubig kung sa isda, Lungga kung sa daga, Kung sa tao'y ano kaya.";
	document.getElementById('ta').innerHTML="x";
	document.getElementById('ta').value="x";
	document.getElementById('tb').innerHTML="d";
	document.getElementById('tb').value="d";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="y";
	document.getElementById('te').value="y";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="f";
	document.getElementById('tg').value="f";
	document.getElementById('th').innerHTML="h";
	document.getElementById('th').value="h";
	document.getElementById('ti').innerHTML="d";
	document.getElementById('ti').value="d";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bahay";



	}

	
	
	
			
			function tques19()
{

	document.getElementById('tquestion').innerHTML="Kung dumating ang bisita ko, Dumarating din ang sa inyo.";
	document.getElementById('ta').innerHTML="w";
	document.getElementById('ta').value="w";
	document.getElementById('tb').innerHTML="r";
	document.getElementById('tb').value="r";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="y";
	document.getElementById('te').value="y";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="r";
	document.getElementById('tg').value="r";
	document.getElementById('th').innerHTML="h";
	document.getElementById('th').value="h";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="x";
	document.getElementById('tj').value="x";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "araw";



	}

	
	
		
			
			function tques20()
{

	document.getElementById('tquestion').innerHTML="Isang biyas ng kawayan, Ang laman ay kamatayan.";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="r";
	document.getElementById('tb').value="r";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="y";
	document.getElementById('te').value="y";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "baril";



	}

	
	
	
				
			function tques21()
{

	document.getElementById('tquestion').innerHTML="May katawa'y walang bituka, May puwit walang paa, Nakakagat tuwina.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="o";
	document.getElementById('te').value="o";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="p";
	document.getElementById('tg').value="p";
	document.getElementById('th').innerHTML="h";
	document.getElementById('th').value="h";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "baso";



	}

	
	
				
			function tques22()
{

	document.getElementById('tquestion').innerHTML="Buhay na hindi kumikibo, Patay na hindi bumabaho.";
	document.getElementById('ta').innerHTML="t";
	document.getElementById('ta').value="t";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="x";
	document.getElementById('ti').value="x";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bato";



	}

		
	
	
		
				
			function tques23()
{

	document.getElementById('tquestion').innerHTML="Isang balong malalim, Punong-puno ng patalim.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="b";
	document.getElementById('tg').value="b";
	document.getElementById('th').innerHTML="c";
	document.getElementById('th').value="c";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bibig";



	}

		
					
			function tques24()
{

	document.getElementById('tquestion').innerHTML="Palayok ni isko, Punong-puno ng bato.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="y";
	document.getElementById('td').value="y";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="b";
	document.getElementById('tg').value="b";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="d";
	document.getElementById('tj').value="d";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bayabas";



	}

		
	
	
						
			function tques25()
{

	document.getElementById('tquestion').innerHTML="Nagsasaing si pusong, Sa ibabaw ang tutong.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bibingka";



	}

		
	
	
						
			function tques26()
{

	document.getElementById('tquestion').innerHTML="Alin sa buong katawan, Nasa likod ang tiyan.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="n";
	document.getElementById('tc').value="n";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="x";
	document.getElementById('ti').value="x";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "binti";



	}

		
	
							
			function tques27()
{

	document.getElementById('tquestion').innerHTML="Itinanim sa kagabihan, Inani sa kaumagahan.";
	document.getElementById('ta').innerHTML="u";
	document.getElementById('ta').value="u";
	document.getElementById('tb').innerHTML="d";
	document.getElementById('tb').value="d";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="x";
	document.getElementById('ti').value="x";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bituin";



	}

		
								
			function tques28()
{

	document.getElementById('tquestion').innerHTML="Kung di pa sa liig pinigilan, Di pa ako bibigyan.";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="e";
	document.getElementById('th').value="e";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bote";



	}


		
								
			function tques29()
{

	document.getElementById('tquestion').innerHTML="Kung sa ilan walang kwenta, Sa gusali mahalaga. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="e";
	document.getElementById('th').value="e";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bato";



	}

				
	
		
								
			function tques29()
{

	document.getElementById('tquestion').innerHTML="Kung sa ilan walang kwenta, Sa gusali mahalaga. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="e";
	document.getElementById('th').value="e";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bato";



	}

				
	
	
	
		
								
			function tques30()
{

	document.getElementById('tquestion').innerHTML="Heto na si lulong, Bubulong bulong.";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="o";
	document.getElementById('tf').value="o";
	document.getElementById('tg').innerHTML="y";
	document.getElementById('tg').value="y";
	document.getElementById('th').innerHTML="e";
	document.getElementById('th').value="e";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bubuyog";



	}

				
	
	
								
			function tques31()
{

	document.getElementById('tquestion').innerHTML="Inisip ng marunong, Sinabi ng gunggong.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="o";
	document.getElementById('tf').value="o";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="e";
	document.getElementById('th').value="e";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bugtong";



	}

				
	
	
								
			function tques32()
{

	document.getElementById('tquestion').innerHTML="Nagsaing si kuruktong, Kumuloy walang gatong.";
	document.getElementById('ta').innerHTML="n";
	document.getElementById('ta').value="n";
	document.getElementById('tb').innerHTML="e";
	document.getElementById('tb').value="e";
	document.getElementById('tc').innerHTML="h";
	document.getElementById('tc').value="h";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="b";
	document.getElementById('tg').value="b";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sabon";



	}
	
	
							
			function tques33()
{

	document.getElementById('tquestion').innerHTML="Isang pinggan, laganapSa buong bayan.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="w";
	document.getElementById('tf').value="w";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="r";
	document.getElementById('tj').value="r";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "buwan";



	}

	
		function tques34()
{

	document.getElementById('tquestion').innerHTML="Mahabang-mahaba, tinutungtungan ng madla.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="d";
	document.getElementById('te').value="d";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="d";
	document.getElementById('tg').value="d";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="h";
	document.getElementById('tj').value="h";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "daan";



	}
	
	
	
	
	
	
		function tques35()
{

	document.getElementById('tquestion').innerHTML="Nagtanim ako ng dayap, sa gitna ng dagat, marami ang nagsihanap, iisa ang nagkapalad.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="d";
	document.getElementById('te').value="d";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="d";
	document.getElementById('tg').value="d";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "dalaga";



	}
	
	
	
		function tques36()
{

	document.getElementById('tquestion').innerHTML="Limang punong niyog, iisa ang matayog.";
	document.getElementById('ta').innerHTML="w";
	document.getElementById('ta').value="w";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="h";
	document.getElementById('td').value="h";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="d";
	document.getElementById('tg').value="d";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "daliri";



	}
	
	
		function tques37()
{

	document.getElementById('tquestion').innerHTML="Munting uling, bibitin-bitin, masarap kanin, mahirap kunin.";
	document.getElementById('ta').innerHTML="d";
	document.getElementById('ta').value="d";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="h";
	document.getElementById('td').value="h";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="d";
	document.getElementById('tg').value="d";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="s";
	document.getElementById('ti').value="s";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "duhat";



	}


	
		function tques38()
{

	document.getElementById('tquestion').innerHTML="Nang maliit ay kastila, nang tumanda ay baluga.";
	document.getElementById('ta').innerHTML="d";
	document.getElementById('ta').value="d";
	document.getElementById('tb').innerHTML="d";
	document.getElementById('tb').value="d";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="u";
	document.getElementById('tg').value="u";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="s";
	document.getElementById('ti').value="s";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "duling";



	}

	
		function tques39()
{

	document.getElementById('tquestion').innerHTML="Takbo roon, takbo rito, hindi makaalis sa tayong ito.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="d";
	document.getElementById('tb').value="d";
	document.getElementById('tc').innerHTML="m";
	document.getElementById('tc').value="m";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="y";
	document.getElementById('te').value="y";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="u";
	document.getElementById('tg').value="u";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="s";
	document.getElementById('ti').value="s";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "duyan";



	}

	
	
		function tques40()
{

	document.getElementById('tquestion').innerHTML="Isang hayop na maliit, dumudumi ng sinulid.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="u";
	document.getElementById('tg').value="u";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gagamba";



	}


	
	
		function tques41()
{

	document.getElementById('tquestion').innerHTML="Bahay ni San Vicente , punong-puno ng diamante.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="r";
	document.getElementById('ti').value="r";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "granada";



	}

	
	
		function tques42()
{

	document.getElementById('tquestion').innerHTML="Bahay ni San Vicente , punong-puno ng diamante.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="r";
	document.getElementById('ti').value="r";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "granada";



	}

	
		function tques43()
{

	document.getElementById('tquestion').innerHTML="Nagsaing si kurukutong, bumubula’y walang gatong.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="r";
	document.getElementById('ti').value="r";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gugo";



	}

	
	
		function tques44()
{

	document.getElementById('tquestion').innerHTML="Aso kong si pula, sumampa sa sanga, nag pakita ng ganda.";
	document.getElementById('ta').innerHTML="e";
	document.getElementById('ta').value="e";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="m";
	document.getElementById('th').value="m";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="e";
	document.getElementById('tj').value="e";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gumamela";



	}

	
	
		function tques45()
{

	document.getElementById('tquestion').innerHTML="Heto na si kaka, bubuka-bukaka.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="n";
	document.getElementById('tc').value="n";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gunting";



	}


	
		function tques46()
{

	document.getElementById('tquestion').innerHTML="Dalawang katawan, tagusan ang tadyang.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="h";
	document.getElementById('tc').value="h";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="d";
	document.getElementById('tf').value="d";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "hagdan";



	}
	
	
		function tques47()
{

	document.getElementById('tquestion').innerHTML="Karga ng karga; walang renta.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="y";
	document.getElementById('tb').value="y";
	document.getElementById('tc').innerHTML="h";
	document.getElementById('tc').value="h";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="d";
	document.getElementById('tf').value="d";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "haligi";



	}



	
	
	
	function tques48()
{

	document.getElementById('tquestion').innerHTML="Heto na, heto na, di mo nakikita.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="h";
	document.getElementById('tb').value="h";
	document.getElementById('tc').innerHTML="h";
	document.getElementById('tc').value="h";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="p";
	document.getElementById('tf').value="p";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="j";
	document.getElementById('ti').value="j";
	document.getElementById('tj').innerHTML="n";
	document.getElementById('tj').value="n";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "hangin";



	}

	
	
	
	function tques49()
{

	document.getElementById('tquestion').innerHTML="Dalawang ibong marikit, nagtitimbangan ng siit.";
	document.getElementById('ta').innerHTML="w";
	document.getElementById('ta').value="w";
	document.getElementById('tb').innerHTML="h";
	document.getElementById('tb').value="h";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="h";
	document.getElementById('ti').value="h";
	document.getElementById('tj').innerHTML="x";
	document.getElementById('tj').value="x";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "hikaw";



	}
	
	
	
	function tques50()
{

	document.getElementById('tquestion').innerHTML="Isang butil ng palay, buong bahay ay nakakalatan.";
	document.getElementById('ta').innerHTML="w";
	document.getElementById('ta').value="w";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="m";
	document.getElementById('th').value="m";
	document.getElementById('ti').innerHTML="y";
	document.getElementById('ti').value="y";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "ilaw";



	}

	
	function tques51()
{

	document.getElementById('tquestion').innerHTML="Dalawang libing, laging may hangin.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="g";
	document.getElementById('tf').value="g";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="m";
	document.getElementById('th').value="m";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="n";
	document.getElementById('tj').value="n";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "ilong";



	}

	
	
	
	function tques52()
{

	document.getElementById('tquestion').innerHTML="Bahay ni Kiko, walang bintana, walang pinto.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="e";
	document.getElementById('tf').value="e";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="m";
	document.getElementById('th').value="m";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="p";
	document.getElementById('tj').value="p";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "itlog";



	}


	
	
	function tques53()
{

	document.getElementById('tquestion').innerHTML="Binili ko nang di kagustuhan,Ginamit ko nang di nalalaman.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="b";
	document.getElementById('te').value="b";
	document.getElementById('tf').innerHTML="e";
	document.getElementById('tf').value="e";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="o";
	document.getElementById('ti').value="o";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kabaong";



	}

	
		
	function tques54()
{

	document.getElementById('tquestion').innerHTML="May binti walang hita, May tuktok walang mukha.";
	document.getElementById('ta').innerHTML="e";
	document.getElementById('ta').value="e";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="b";
	document.getElementById('te').value="b";
	document.getElementById('tf').innerHTML="e";
	document.getElementById('tf').value="e";
	document.getElementById('tg').innerHTML="f";
	document.getElementById('tg').value="f";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="u";
	document.getElementById('ti').value="u";
	document.getElementById('tj').innerHTML="r";
	document.getElementById('tj').value="r";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kabute";



	}

	
	
		
	function tques55()
{

	document.getElementById('tquestion').innerHTML="Ang ina’y gumagapang pa, Ang anak ay umuupo na.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="b";
	document.getElementById('te').value="b";
	document.getElementById('tf').innerHTML="s";
	document.getElementById('tf').value="s";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kalabasa";



	}
	
	
	function tques56()
{

	document.getElementById('tquestion').innerHTML="Araw araw bagong buhay,Taun-taon namamatay.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="d";
	document.getElementById('tc').value="d";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="e";
	document.getElementById('tf').value="e";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="r";
	document.getElementById('th').value="r";
	document.getElementById('ti').innerHTML="o";
	document.getElementById('ti').value="o";
	document.getElementById('tj').innerHTML="n";
	document.getElementById('tj').value="n";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kalendaryo";



	}
	
	
	function tques57()
{

	document.getElementById('tquestion').innerHTML="Putukan nang putukan,hindi nag kakarinigan.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="p";
	document.getElementById('tc').value="p";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="e";
	document.getElementById('tf').value="e";
	document.getElementById('tg').innerHTML="b";
	document.getElementById('tg').value="b";
	document.getElementById('th').innerHTML="h";
	document.getElementById('th').value="h";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="n";
	document.getElementById('tj').value="n";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kampana";



	}
	
	
	
	function tques58()
{

	document.getElementById('tquestion').innerHTML="Akoy ma’y kasama sa pahingi ng awa; ako’y di umiyak, siya ay lumuha.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="e";
	document.getElementById('tf').value="e";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kandila";



	}
	
	
	
	function tques59()
{

	document.getElementById('tquestion').innerHTML="Isang senyora,nakaupo sa tasa.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="s";
	document.getElementById('tf').value="s";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="c";
	document.getElementById('tj').value="c";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kasoy";



	}
	
	
	function tques60()
{

	document.getElementById('tquestion').innerHTML="Anong halaman ang sagana sa ugat, dahon, at sanga,ngunit wala sa bunga.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="f";
	document.getElementById('td').value="f";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="w";
	document.getElementById('tj').value="w";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kawayan";



	}
	
	
	
	
	function tques61()
{

	document.getElementById('tquestion').innerHTML="Ma-tag-init, ma-tag-ulan,dala-dala’y balutan.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kuba";



	}
	
	
	
	function tques62()
{

	document.getElementById('tquestion').innerHTML="Naabot na ng kamay,iginawa pa ng tulay.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="r";
	document.getElementById('te').value="r";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="e";
	document.getElementById('th').value="e";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kubyertos";



	}
	
	
	function tques63()
{

	document.getElementById('tquestion').innerHTML="Limang mag kakapatid,tig-tig-isa ng silid.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="y";
	document.getElementById('td').value="y";
	document.getElementById('te').innerHTML="k";
	document.getElementById('te').value="k";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kuko";



	}
	
	
	
	
	function tques64()
{

	document.getElementById('tquestion').innerHTML="May hita ay walang binti,may ngipin ay walang labi.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="d";
	document.getElementById('tc').value="d";
	document.getElementById('td').innerHTML="r";
	document.getElementById('td').value="r";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="u";
	document.getElementById('tj').value="u";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kudkuran";



	}
	
	
	
	
	function tques65()
{

	document.getElementById('tquestion').innerHTML="Maliit pa si kumara,marunong ng humuni.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="i";
	document.getElementById('tg').value="i";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kuliglig";



	}
	
	
	
	function tques66()
{

	document.getElementById('tquestion').innerHTML="Baka ko sa Maynila abot dito ang unga.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="i";
	document.getElementById('tg').value="i";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kulog";



	}
	
	
		function tques67()
{

	document.getElementById('tquestion').innerHTML="Aling paa ang nasa ulo?";
	document.getElementById('ta').innerHTML="t";
	document.getElementById('ta').value="t";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="d";
	document.getElementById('ti').value="d";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kuto";



	}
	
	
		function tques68()
{

	document.getElementById('tquestion').innerHTML="Kadena’y isinabit,sa batok nakakawit.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="k";
	document.getElementById('td').value="k";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kwintas";



	}
	
	
	function tques69()
{

	document.getElementById('tquestion').innerHTML="Kung saan masikip doon nagpipilit.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="b";
	document.getElementById('tg').value="b";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="v";
	document.getElementById('tj').value="v";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "labong";



	}
	
	
	
	function tques70()
{

	document.getElementById('tquestion').innerHTML="Itulak at hilahin,sigurado ang kain.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="b";
	document.getElementById('tg').value="b";
	document.getElementById('th').innerHTML="r";
	document.getElementById('th').value="r";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "lagari";



	}
	
	
	
	function tques71()
{

	document.getElementById('tquestion').innerHTML="Butas na tinagpian ng kapuwa butas.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="m";
	document.getElementById('td').value="m";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="b";
	document.getElementById('tg').value="b";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="p";
	document.getElementById('tj').value="p";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "lambat";



	}
	
	
	
	function tques72()
{

	document.getElementById('tquestion').innerHTML="Kung kailan tahimik saka nambubuwisit.";
	document.getElementById('ta').innerHTML="h";
	document.getElementById('ta').value="h";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="m";
	document.getElementById('td').value="m";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="r";
	document.getElementById('ti').value="r";
	document.getElementById('tj').innerHTML="o";
	document.getElementById('tj').value="o";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "lamok";



	}
	
	
	function tques73()
{

	document.getElementById('tquestion').innerHTML="Naghain si Lolo,unang dumulog ang tukso.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="m";
	document.getElementById('td').value="m";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="w";
	document.getElementById('tj').value="w";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "langaw";



	}
	
	
	function tques74()
{

	document.getElementById('tquestion').innerHTML="Baboy ko sa Marungko,balahibo'y pako.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="z";
	document.getElementById('tf').value="z";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "langka";



	}
	
	
	
	function tques75()
{

	document.getElementById('tquestion').innerHTML="Munting-munti lang na hayop uliran sa pag-impok.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="z";
	document.getElementById('tf').value="z";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "langgam";



	}
	
	
	function tques76()
{

	document.getElementById('tquestion').innerHTML="Aso kong si puti,inutusan ko'y hindi na umuwi.";
	document.getElementById('ta').innerHTML="n";
	document.getElementById('ta').value="n";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="y";
	document.getElementById('td').value="y";
	document.getElementById('te').innerHTML="y";
	document.getElementById('te').value="y";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="o";
	document.getElementById('tj').value="o";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "laway";



	}
	
	
	function tques77()
{

	document.getElementById('tquestion').innerHTML="Mayroon akong gatang,hindi ko matingnan.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="j";
	document.getElementById('th').value="j";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="e";
	document.getElementById('tj').value="e";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "leeg";



	}
	
	
	
	
	function tques78()
{

	document.getElementById('tquestion').innerHTML="Nahihiya, walang kinahihiyaan.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="h";
	document.getElementById('tc').value="h";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "makahiya";



	}
	
	
	
	
	function tques79()
{

	document.getElementById('tquestion').innerHTML="May sunong, may kilik, may salakab sa puwit.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="j";
	document.getElementById('tg').value="j";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="f";
	document.getElementById('ti').value="f";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mais";



	}
	
	
	
	
	function tques80()
{

	document.getElementById('tquestion').innerHTML="Pusong bibitin-bitin,mabangong parang hasmin,masarap kanin.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="g";
	document.getElementById('tf').value="g";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mangga";



	}
	
	
	
	function tques81()
{

	document.getElementById('tquestion').innerHTML="Pusong bibitin-bitin,mabangong parang hasmin,masarap kanin.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="g";
	document.getElementById('tf').value="g";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mangga";



	}
	
	
	
		
	function tques82()
{

	document.getElementById('tquestion').innerHTML="Tag-ulan at tag-arawhanggang tuhod ng salawal.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="a";
	document.getElementById('tc').value="a";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="g";
	document.getElementById('tf').value="g";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="n";
	document.getElementById('tj').value="n";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "manok";



	}
	
	
	
	function tques83()
{

	document.getElementById('tquestion').innerHTML="Dalawang bolang sinulid,abot hanggang langit.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="j";
	document.getElementById('tc').value="j";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="s";
	document.getElementById('ti').value="s";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mata";



	}
	
	
	function tques84()
{

	document.getElementById('tquestion').innerHTML="Ang mukha'y parang tao,magaling lumukso.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="j";
	document.getElementById('tc').value="j";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="s";
	document.getElementById('ti').value="s";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "matsing";



	}
	
	
	
	function tques85()
{

	document.getElementById('tquestion').innerHTML="Kastila kung natutulog kapag gising ay tagalog.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mantika";



	}
	
	
	function tques86()
{

	document.getElementById('tquestion').innerHTML="Maliit pa si Tsikito,marunong nang manusok.";
	document.getElementById('ta').innerHTML="l";
	document.getElementById('ta').value="l";
	document.getElementById('tb').innerHTML="q";
	document.getElementById('tb').value="q";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="y";
	document.getElementById('tf').value="y";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="t";
	document.getElementById('ti').value="t";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "lamok";



	}
	
	
	function tques87()
{

	document.getElementById('tquestion').innerHTML="Noong bata ay nag saya,at naghubo nung dalaga.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="y";
	document.getElementById('tb').value="y";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="w";
	document.getElementById('te').value="w";
	document.getElementById('tf').innerHTML="y";
	document.getElementById('tf').value="y";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="n";
	document.getElementById('tj').value="n";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kawayan";



	}
	
	
	
		
	function tques88()
{

	document.getElementById('tquestion').innerHTML="Nang aking mapatay,lalong humaba ang buhay.";
	document.getElementById('ta').innerHTML="n";
	document.getElementById('ta').value="n";
	document.getElementById('tb').innerHTML="d";
	document.getElementById('tb').value="d";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="m";
	document.getElementById('th').value="m";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kandila";



	}
	
	
	function tques89()
{

	document.getElementById('tquestion').innerHTML="Bugtong-bugtong,Magkakarugtong.";
	document.getElementById('ta').innerHTML="t";
	document.getElementById('ta').value="t";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="m";
	document.getElementById('th').value="m";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "tanikala";



	}
	
	
	
		function tques90()
{

	document.getElementById('tquestion').innerHTML="Bahay ni Kiko, walang bintana, walang pinto.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="m";
	document.getElementById('ti').value="m";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "itlog";



	}
	
	
	
	
	
		function tques91()
{

	document.getElementById('tquestion').innerHTML="Dalawang magkaibigan, may talim ang tiyan; matagal ng nagkakagatan di pa nagkakasakitan.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="u";
	document.getElementById('tj').value="u";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gunting";



	}
	
	
	
		function tques92()
{

	document.getElementById('tquestion').innerHTML="Malaki kung bata, maliit kung matanda dahil sa kahahasa.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="r";
	document.getElementById('tg').value="r";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "itak";



	}
	
	
	
	
		function tques93()
{

	document.getElementById('tquestion').innerHTML="nagbabahay si maitim, walang haliging itinanim.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gagamba";



	}
	
	
	
	
		function tques94()
{

	document.getElementById('tquestion').innerHTML="Kung di pa sa liig pinigilan, Di pa ako bibigyan.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bote";



	}
	
	
	
	
		function tques95()
{

	document.getElementById('tquestion').innerHTML="Itinanim sa kagabihan, Inani sa kaumagahan.";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bituin";



	}
	
	
	
	
		function tques96()
{

	document.getElementById('tquestion').innerHTML="Alin sa buong katawan, Nasa likod ang tiyan.";
	document.getElementById('ta').innerHTML="j";
	document.getElementById('ta').value="j";
	document.getElementById('tb').innerHTML="r";
	document.getElementById('tb').value="r";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "binti";



	}
	
	
	
	
		function tques97()
{

	document.getElementById('tquestion').innerHTML="Nagsasaing si pusong, Sa ibabaw ang tutong.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="q";
	document.getElementById('tc').value="q";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="b";
	document.getElementById('te').value="b";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bibingka";



	}
	
	
	
	
	function tques98()
{

	document.getElementById('tquestion').innerHTML="Buhay na hindi kumikibo, Patay na hindi bumabaho.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="y";
	document.getElementById('te').value="y";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bato";



	}
	
	
		function tques99()
{

	document.getElementById('tquestion').innerHTML="Nakalantay kung gabi, Kung araw ay nakatabi.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="y";
	document.getElementById('tg').value="y";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "banig";



	}

	
	

	
	function tques100()
{

	document.getElementById('tquestion').innerHTML="Tubig na nagiging bato, Bato na nagiging tubig.";
	document.getElementById('ta').innerHTML="n";
	document.getElementById('ta').value="n";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="s";
	document.getElementById('tg').value="s";
	document.getElementById('th').innerHTML="h";
	document.getElementById('th').value="h";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="o";
	document.getElementById('tj').value="o";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "asin";



	}
	
	
		
	
	
		function tques101()
{

	document.getElementById('tquestion').innerHTML="Bastong hindi mahawak-hawakan, sinturong walang mapaggamit-gamitan. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="h";
	document.getElementById('tj').value="h";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "ahas";



	}
	
	
	
		function tques102()
{

	document.getElementById('tquestion').innerHTML="Bahay ni ka huli, haligi'y balibali, ang bubong ay kawali. ";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="r";
	document.getElementById('tg').value="r";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alimango";



	}
	
	
	
	
		function tques103()
{

	document.getElementById('tquestion').innerHTML="Kahit hindi tayo magkaano-ano, ang gatas ng anak ko, ay gatas din ng anak mo.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "baka";



	}
	
	
	
	
		function tques104()
{

	document.getElementById('tquestion').innerHTML="Ibon kong saan man makarating, makababalik kung saan nanggaling. ";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kalapati";



	}
	
	
	
	
		function tques105()
{

	document.getElementById('tquestion').innerHTML="Bagama't maliit, marunong nang umawit. ";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kuliglig";



	}
	
	
	
	
		function tques106()
{

	document.getElementById('tquestion').innerHTML="Dala mo't sunong, ikaw rin ang baon. ";
	document.getElementById('ta').innerHTML="j";
	document.getElementById('ta').value="j";
	document.getElementById('tb').innerHTML="r";
	document.getElementById('tb').value="r";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kuto";



	}
	
	
	
	
		function tques107()
{

	document.getElementById('tquestion').innerHTML="Ang abot ng paa ko'y abot rin ng ilong ko? Hulaan mo, anong hayop ako.";
	document.getElementById('ta').innerHTML="e";
	document.getElementById('ta').value="e";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="p";
	document.getElementById('tc').value="p";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="e";
	document.getElementById('tj').value="e";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "elepante";



	}
	
	
	
	
	function tques108()
{

	document.getElementById('tquestion').innerHTML="Kung manahi'y nagbabaging at sa gitna'y tumitigil. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gagamba";



	}
	
	
		function tques109()
{

	document.getElementById('tquestion').innerHTML="Kulisap na lilipad-lipad, sa ningas ng liwanag ay isang pangahas. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="m";
	document.getElementById('te').value="m";
	document.getElementById('tf').innerHTML="o";
	document.getElementById('tf').value="o";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="m";
	document.getElementById('th').value="m";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gamogamo";



	}

	
	

	
	function tques110()
{

	document.getElementById('tquestion').innerHTML="Isang uod na puro balahibo, kapag nadikit sa iyo ang ulo, tiyak mangangati ang balat mo.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="d";
	document.getElementById('tb').value="d";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="s";
	document.getElementById('tg').value="s";
	document.getElementById('th').innerHTML="h";
	document.getElementById('th').value="h";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="o";
	document.getElementById('tj').value="o";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "higad";



	}
	
	
	
	
	
	
	
		
	
		function tques111()
{

	document.getElementById('tquestion').innerHTML="Isda ko sa tabang, pag nasa lupa ay gumagapang.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="h";
	document.getElementById('tj').value="h";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "manok";



	}
	
	
	
		function tques112()
{

	document.getElementById('tquestion').innerHTML="Ibon kong kay daldal-daldal, ginagaya lang ang inuusal.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="r";
	document.getElementById('tg').value="r";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="o";
	document.getElementById('tj').value="o";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "loro";



	}
	
	
	
	
		function tques113()
{

	document.getElementById('tquestion').innerHTML="Hakot dito hakot doon, kahit maliit ay ipon ng ipon. ";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "langgam";



	}
	
	
	
	
		function tques114()
{

	document.getElementById('tquestion').innerHTML="Pag munti'y may buntot, paglaki ay punggok. ";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "palaka";



	}
	
	
	
	
		function tques115()
{

	document.getElementById('tquestion').innerHTML="Tumatanda na ang nuno, hindi pa rin naliligo. ";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="s";
	document.getElementById('tf').value="s";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pusa";



	}
	
	
	
	
		function tques116()
{

	document.getElementById('tquestion').innerHTML="Narito na si pilo, sunong-sunong munting pulo. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pagong";



	}
	
	
	
	
		function tques117()
{

	document.getElementById('tquestion').innerHTML="Kawangis niya'y tao, magaling manguto, mataas kung lumukso. ";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "unggoy";



	}
	
	
	
	
	function tques118()
{

	document.getElementById('tquestion').innerHTML="Naghain na si Lolo, unang dumulog ay tukso.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="n";
	document.getElementById('tc').value="n";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "langaw";



	}
	
	
		function tques119()
{

	document.getElementById('tquestion').innerHTML="Heto na si Ingkong, bubulong-bulong. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="y";
	document.getElementById('te').value="y";
	document.getElementById('tf').innerHTML="o";
	document.getElementById('tf').value="o";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bubuyog";



	}

	
	

	
	function tques120()
{

	document.getElementById('tquestion').innerHTML="Iisa na, kinuha pa. Ang natira ay dalawa.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="r";
	document.getElementById('tb').value="r";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="s";
	document.getElementById('tg').value="s";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="u";
	document.getElementById('ti').value="u";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "tulya";



	}
	
	
	
	
		
	
		
	
		function tques121()
{

	document.getElementById('tquestion').innerHTML="Hindi naman bulag, di makakita sa liwanag. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="h";
	document.getElementById('tj').value="h";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "paniki";



	}
	
	
	
		function tques122()
{

	document.getElementById('tquestion').innerHTML="Maliit pa ang linsiyok, marunong nang manusok.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="k";
	document.getElementById('tf').value="k";
	document.getElementById('tg').innerHTML="r";
	document.getElementById('tg').value="r";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="o";
	document.getElementById('tj').value="o";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "lamok";



	}
	
	
	
	
		function tques123()
{

	document.getElementById('tquestion').innerHTML="Munting anghel na lilipad-lipad, dala-dala'y liwanag sa likod ng pakpak.  ";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="p";
	document.getElementById('tc').value="p";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="t";
	document.getElementById('tg').value="t";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alitaptap";



	}
	
	
	
	
		function tques124()
{

	document.getElementById('tquestion').innerHTML="Nakakalakad ako sa lupa, nakakalangoy din ako sa sapa, nakakalipad din ako ng kusa. ";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gansa";



	}
	
	
	
	
		function tques125()
{

	document.getElementById('tquestion').innerHTML="Umuusad-usad sapagkat sa paa ay salat, pinahihirapan pa ng pasan-pasang bahay na ubod ng bigat. ";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kuhol";



	}
	
	
	
	
		function tques126()
{

	document.getElementById('tquestion').innerHTML="Isang ting ting na kay tigas nang ikiskis ay nagdingas. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "palito";



	}
	
	
	
	
		function tques127()
{

	document.getElementById('tquestion').innerHTML="Patpat ay biglang bumukadkad may hangin ang magandang dilag ";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pamaypay";



	}
	
	
	
	
	function tques128()
{

	document.getElementById('tquestion').innerHTML="Pukpok dito, pukpok diyan, bakal na pinapantay matitigas na bisig na panghanapbuhay";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="n";
	document.getElementById('tc').value="n";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="d";
	document.getElementById('te').value="d";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "panday";



	}
	
	
		function tques129()
{

	document.getElementById('tquestion').innerHTML="Sariling- sarili mona, ginagamit pa ng iba";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pangalan";



	}

	
	

	
	function tques130()
{

	document.getElementById('tquestion').innerHTML="Sa araw ay nahihimbing sa gabi ay gising ";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "paniki";



	}
	
	
	
	
	
			
	
		
	
		function tques131()
{

	document.getElementById('tquestion').innerHTML="Bahay ko sa pandakan malapad ang harapan ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pantalan";



	}
	
	
	
		function tques132()
{

	document.getElementById('tquestion').innerHTML="Maputing parang busilak, kalihim ko sa pagliyag";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="e";
	document.getElementById('td').value="e";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="p";
	document.getElementById('tf').value="p";
	document.getElementById('tg').innerHTML="r";
	document.getElementById('tg').value="r";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="p";
	document.getElementById('tj').value="p";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "papel";



	}
	
	
	
	
		function tques133()
{

	document.getElementById('tquestion').innerHTML="Hugis ay bituin papel na nagningning  ";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="p";
	document.getElementById('tc').value="p";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="r";
	document.getElementById('tg').value="r";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "parol";



	}
	
	
	
	
		function tques134()
{

	document.getElementById('tquestion').innerHTML="Bahay ng halaman nabubuhat kahit saan ";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "paso";



	}
	
	
	
	
		function tques135()
{

	document.getElementById('tquestion').innerHTML="Kaisa-isang plato, kita sa buong Mundo. ";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="n";
	document.getElementById('tc').value="n";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="b";
	document.getElementById('te').value="b";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "buwan";



	}
	
	
	
	
		function tques136()
{

	document.getElementById('tquestion').innerHTML="Nagtago si Pedro, labas ang ulo. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pako";



	}
	
	
	
	
		function tques137()
{

	document.getElementById('tquestion').innerHTML="Ate mo, ate ko, ate ng lahat ng tao";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="s";
	document.getElementById('ti').value="s";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "atis";



	}
	
	
	
	
	function tques138()
{

	document.getElementById('tquestion').innerHTML="Hindi prinsesa, hindi reyna. Bakit may korona";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="d";
	document.getElementById('te').value="d";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bayabas";



	}
	
	
		function tques139()
{

	document.getElementById('tquestion').innerHTML="Nanganak ang birhen, itinapon ang lampin.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "saging";



	}

	
	

	
	function tques140()
{

	document.getElementById('tquestion').innerHTML="Isang prinsesa, nakaupo sa tasa.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kasoy";



	}
	
	
	
	
				
	
		
	
		function tques141()
{

	document.getElementById('tquestion').innerHTML="May langit, may lupa, May tubig, walang isda.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "niyog";



	}
	
	
	
		function tques142()
{

	document.getElementById('tquestion').innerHTML="Ang alaga kong hugis bilog, barya-barya ang laman-loob.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alkansiya";



	}
	
	
	
	
		function tques143()
{

	document.getElementById('tquestion').innerHTML="Ako ay may kaibigan, kasama ko kahit saan.";
	document.getElementById('ta').innerHTML="n";
	document.getElementById('ta').value="n";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="p";
	document.getElementById('tc').value="p";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "anino";



	}
	
	
	
	
		function tques144()
{

	document.getElementById('tquestion').innerHTML="Palda ni Santa Maria. Ang kulay ay iba-iba.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="h";
	document.getElementById('te').value="h";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bahaghari";



	}
	
	
	
	
		function tques145()
{

	document.getElementById('tquestion').innerHTML="Sa araw ay bungbong, sa gabi ay dahon.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="n";
	document.getElementById('tc').value="n";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="b";
	document.getElementById('te').value="b";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "banig";



	}
	
	
	
	
		function tques146()
{

	document.getElementById('tquestion').innerHTML="Sa liwanag ay hindi mo makita. Sa dilim ay maliwanag sila.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bituin";



	}
	
	
	
	
		function tques147()
{

	document.getElementById('tquestion').innerHTML="Hindi hari, hindi pari ang damit ay sari-sari";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="s";
	document.getElementById('ti').value="s";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sampayan";



	}
	
	
	
	
	function tques148()
{

	document.getElementById('tquestion').innerHTML="May binti, walang hita, May tuktok, walang mukha.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="e";
	document.getElementById('ti').value="e";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kabute";



	}
	
	
		function tques149()
{

	document.getElementById('tquestion').innerHTML="Bata pa si Nene, Marunong nang manahi";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gagamba";



	}

	
	

	
	function tques150()
{

	document.getElementById('tquestion').innerHTML="Kung kailan pinatay, saka pa humaba ang buhay";
	document.getElementById('ta').innerHTML="l";
	document.getElementById('ta').value="l";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="d";
	document.getElementById('te').value="d";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="k";
	document.getElementById('tg').value="k";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kandila";



	}
	
	
	
	
				
	
		
	
		function tques151()
{

	document.getElementById('tquestion').innerHTML="Bugtong-pala-bugtong, kadenang umuugong.";
	document.getElementById('ta').innerHTML="e";
	document.getElementById('ta').value="e";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="r";
	document.getElementById('tj').value="r";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "tren";



	}
	
	
	
		function tques152()
{

	document.getElementById('tquestion').innerHTML="Buhok ni Adan, hindi mabilang.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "ulan";



	}
	
	
	
	
		function tques153()
{

	document.getElementById('tquestion').innerHTML="Bibingka ng hari, hindi mo mahati. ";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="u";
	document.getElementById('tj').value="u";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "tubig";



	}
	
	
	
	
		function tques154()
{

	document.getElementById('tquestion').innerHTML="Iisa ang pasukan, tatlo ang labasan.";
	document.getElementById('ta').innerHTML="m";
	document.getElementById('ta').value="m";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="h";
	document.getElementById('te').value="h";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="d";
	document.getElementById('tg').value="d";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "damit";



	}
	
	
	
	
		function tques155()
{

	document.getElementById('tquestion').innerHTML="Malaking supot ni Mang Jacob, kung sisidlan ay pataob.";
	document.getElementById('ta').innerHTML="u";
	document.getElementById('ta').value="u";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="b";
	document.getElementById('te').value="b";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kulambo";



	}
	
	
	
	
		function tques156()
{

	document.getElementById('tquestion').innerHTML="Dalawang pipit nag titimbangan sa isang siit.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="w";
	document.getElementById('td').value="w";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="b";
	document.getElementById('tf').value="b";
	document.getElementById('tg').innerHTML="h";
	document.getElementById('tg').value="h";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "hikaw";



	}
	
	
	
	
		function tques157()
{

	document.getElementById('tquestion').innerHTML="Nagdaan si Kabo Negro, namatay na lahat ang tao.";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="s";
	document.getElementById('ti').value="s";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gabi";



	}
	
	
	
	
	function tques158()
{

	document.getElementById('tquestion').innerHTML="Ang alaga kong hugis bilog, barya-barya ang laman-loob.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="y";
	document.getElementById('ti').value="y";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alkansya";



	}
	
	
		function tques159()
{

	document.getElementById('tquestion').innerHTML="Sa liwanag ay hindi mo makita. Sa dilim ay maliwanag sila.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bituin";



	}

	
	

	
	function tques160()
{

	document.getElementById('tquestion').innerHTML="Nagsaing si Hudas, kinuha ang tubig itinapon ang bigas.";
	document.getElementById('ta').innerHTML="t";
	document.getElementById('ta').value="t";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="d";
	document.getElementById('te').value="d";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gata";



	}
	
	
	
	
	
		
				
	
		
	
		function tques161()
{

	document.getElementById('tquestion').innerHTML="Bahay ni Tinyente nag-iisa ang poste.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="r";
	document.getElementById('tj').value="r";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "payong";



	}
	
	
	
		function tques162()
{

	document.getElementById('tquestion').innerHTML="Hiyas na puso, kulay ginto, mabango kung amuyin, masarap kung kainin.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="m";
	document.getElementById('tb').value="m";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mangga";



	}
	
	
	
	
		function tques163()
{

	document.getElementById('tquestion').innerHTML="Butong binalot ng bakal, bakal na binalot ng kristal.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="e";
	document.getElementById('tb').value="e";
	document.getElementById('tc').innerHTML="l";
	document.getElementById('tc').value="l";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "lansones";



	}
	
	
	
	
		function tques164()
{

	document.getElementById('tquestion').innerHTML="Nag tapis nang nag tapis nakalitaw ang bulbolis.";
	document.getElementById('ta').innerHTML="m";
	document.getElementById('ta').value="m";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="h";
	document.getElementById('te').value="h";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="s";
	document.getElementById('tg').value="s";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mais";



	}
	
	
	
	
		function tques165()
{

	document.getElementById('tquestion').innerHTML="Aling pagkain sa mundo, ang nakalabas ang buto?";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="b";
	document.getElementById('te').value="b";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kasoy";



	}
	
	
	
	
		function tques166()
{

	document.getElementById('tquestion').innerHTML="Heto na si Ingkong, nakaupo sa lusong.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="w";
	document.getElementById('td').value="w";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="o";
	document.getElementById('tf').value="o";
	document.getElementById('tg').innerHTML="h";
	document.getElementById('tg').value="h";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kasoy";



	}
	
	
	
	
		function tques167()
{

	document.getElementById('tquestion').innerHTML="Nakatalikod na ang prinsesa, mukha niya'y nakaharap pa.";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "balimbing";



	}
	
	
	
	
	function tques168()
{

	document.getElementById('tquestion').innerHTML="Balat niya'y berde, buto niya'y itim,laman niya'y pula, sino siya?";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="y";
	document.getElementById('ti').value="y";
	document.getElementById('tj').innerHTML="w";
	document.getElementById('tj').value="w";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pakwan";



	}
	
	
		function tques169()
{

	document.getElementById('tquestion').innerHTML="Kung tawagin nila'y santo, hindi naman milagroso.";
	document.getElementById('ta').innerHTML="l";
	document.getElementById('ta').value="l";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="g";
	document.getElementById('td').value="g";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "santol";



	}

	
	

	
	function tques170()
{

	document.getElementById('tquestion').innerHTML="Bahay ni Mang Pedro, punung-puno ng bato.";
	document.getElementById('ta').innerHTML="t";
	document.getElementById('ta').value="t";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="d";
	document.getElementById('te').value="d";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="p";
	document.getElementById('ti').value="p";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "papaya";



	}
	
	
	
	
	
		
		
	
		function tques171()
{

	document.getElementById('tquestion').innerHTML="Nakayuko ang reyna di nalalaglag ang korona.";
	document.getElementById('ta').innerHTML="b";
	document.getElementById('ta').value="b";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bayabas";



	}
	
	
	
		function tques172()
{

	document.getElementById('tquestion').innerHTML="Kumpul-kumpol na uling, hayon at bibitin-bitin.";
	document.getElementById('ta').innerHTML="h";
	document.getElementById('ta').value="h";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="d";
	document.getElementById('tj').value="d";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "duhat";



	}
	
	
	
	
		function tques173()
{

	document.getElementById('tquestion').innerHTML="Bunga na ay namumunga pa.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="e";
	document.getElementById('tb').value="e";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="u";
	document.getElementById('ti').value="u";
	document.getElementById('tj').innerHTML="g";
	document.getElementById('tj').value="g";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bunga";



	}
	
	
	
	
		function tques174()
{

	document.getElementById('tquestion').innerHTML="Tiningnan nang tiningnan. Bago ito nginitian.";
	document.getElementById('ta').innerHTML="m";
	document.getElementById('ta').value="m";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="h";
	document.getElementById('te').value="h";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="s";
	document.getElementById('tg').value="s";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mais";



	}
	
	
	
	
		function tques175()
{

	document.getElementById('tquestion').innerHTML="Isang magandang dalaga.‘Di mabilang ang mata.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pinya";



	}
	
	
	
	
		function tques176()
{

	document.getElementById('tquestion').innerHTML="Dumaan ang hari, nagkagatan ang mga pari.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="p";
	document.getElementById('td').value="p";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="e";
	document.getElementById('tf').value="e";
	document.getElementById('tg').innerHTML="h";
	document.getElementById('tg').value="h";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="r";
	document.getElementById('ti').value="r";
	document.getElementById('tj').innerHTML="z";
	document.getElementById('tj').value="z";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "ziper";



	}
	
	
	
	
		function tques177()
{

	document.getElementById('tquestion').innerHTML="Dalawang batong itim, malayo ang nararating.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mata";



	}
	
	
	
	
	function tques178()
{

	document.getElementById('tquestion').innerHTML="Sa isang kalabit, may buhay na kapalit.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="b";
	document.getElementById('td').value="b";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "baril";



	}
	
	
		function tques179()
{

	document.getElementById('tquestion').innerHTML="Buto't balat na malapad, kay galing kung lumipad.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sarangola";



	}

	
	

	
	function tques180()
{

	document.getElementById('tquestion').innerHTML="Hinila ko ang baging, sumigaw ang matsing.";
	document.getElementById('ta').innerHTML="m";
	document.getElementById('ta').value="m";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kampana";



	}
	
	
	
	
	
		
	
		
		
	
		function tques181()
{

	document.getElementById('tquestion').innerHTML="Puno ay buku-buko, Dahon ay abaniko, Bunga ay parasko Perdegones ang mga buto.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="p";
	document.getElementById('tf').value="p";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "papaya";



	}
	
	
	
		function tques182()
{

	document.getElementById('tquestion').innerHTML="Hindi tao, hindi hayop, May tainga't may buhok.";
	document.getElementById('ta').innerHTML="m";
	document.getElementById('ta').value="m";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mais";



	}
	
	
	
	
		function tques183()
{

	document.getElementById('tquestion').innerHTML="Ang dalawa'y tatlo na, ang maitim ay puti na, ang bakod ay lagas na.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="e";
	document.getElementById('tb').value="e";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="d";
	document.getElementById('ti').value="d";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "matanda";



	}
	
	
	
	
		function tques184()
{

	document.getElementById('tquestion').innerHTML="Pantas ka man at maalam, Angkan ka ng mga paham Turan mo kung ano.";
	document.getElementById('ta').innerHTML="m";
	document.getElementById('ta').value="m";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="s";
	document.getElementById('tg').value="s";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "plantsa";



	}
	
	
	
	
		function tques185()
{

	document.getElementById('tquestion').innerHTML="Bahay ni Ligaya nalilibot ng mata.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pinya";



	}
	
	
	
	
		function tques186()
{

	document.getElementById('tquestion').innerHTML="Maitim na parang uwak Maputing parang busilak, Walang paa'y nakalalakad At sa hari'y nakikipag-usap.";
	document.getElementById('ta').innerHTML="h";
	document.getElementById('ta').value="h";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="m";
	document.getElementById('tc').value="m";
	document.getElementById('td').innerHTML="p";
	document.getElementById('td').value="p";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="e";
	document.getElementById('tf').value="e";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="u";
	document.getElementById('th').value="u";
	document.getElementById('ti').innerHTML="r";
	document.getElementById('ti').value="r";
	document.getElementById('tj').innerHTML="z";
	document.getElementById('tj').value="z";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "liham";



	}
	
	
	
	
		function tques187()
{

	document.getElementById('tquestion').innerHTML="Bumuka'y walang bibig Ngumingiti nang tahimik.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="l";
	document.getElementById('tb').value="l";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="k";
	document.getElementById('te').value="k";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bulaklak";



	}
	
	
	
	
	function tques188()
{

	document.getElementById('tquestion').innerHTML="Isda ko sa Mariveles Nasa loob ang kaliskis.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="m";
	document.getElementById('ti').value="m";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alimango";



	}
	
	
		function tques189()
{

	document.getElementById('tquestion').innerHTML="Oo nga't alimango Nasa loob ang ulo.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="p";
	document.getElementById('td').value="p";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pagong";



	}

	
	

	
	function tques190()
{

	document.getElementById('tquestion').innerHTML="Oo nga't pagong Tubig ay iniinom.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "niyog";



	}
	
	
	
	
	
		
	
		
		
	
		function tques191()
{

	document.getElementById('tquestion').innerHTML="Oo nga't niyog Nasa loob ang bunot.";
	document.getElementById('ta').innerHTML="m";
	document.getElementById('ta').value="m";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="g";
	document.getElementById('tf').value="g";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="b";
	document.getElementById('tj').value="b";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mangga";



	}
	
	
	
		function tques192()
{

	document.getElementById('tquestion').innerHTML="Oo nga't mangga Kay daming mga mata.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pinya";



	}
	
	
	
	
		function tques193()
{

	document.getElementById('tquestion').innerHTML="Puno'y layu-layo Dulo'y tagpu-tagpo.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="e";
	document.getElementById('tb').value="e";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="t";
	document.getElementById('te').value="t";
	document.getElementById('tf').innerHTML="y";
	document.getElementById('tf').value="y";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="d";
	document.getElementById('ti').value="d";
	document.getElementById('tj').innerHTML="h";
	document.getElementById('tj').value="h";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "bahay";



	}
	
	
	
	
		function tques194()
{

	document.getElementById('tquestion').innerHTML="Nakaluluto'y walang init, Umaaso kahi't malamig.";
	document.getElementById('ta').innerHTML="e";
	document.getElementById('ta').value="e";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="s";
	document.getElementById('tg').value="s";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="y";
	document.getElementById('ti').value="y";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "yelo";



	}
	
	
	
	
		function tques195()
{

	document.getElementById('tquestion').innerHTML="Hindi tao, hindi ibon Bumabalik kung itapon.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="o";
	document.getElementById('te').value="o";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="k";
	document.getElementById('ti').value="k";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "yoyo";



	}
	
	
	
	
		function tques196()
{

	document.getElementById('tquestion').innerHTML="Eto na si bayaw Dala-dala'y ilaw.";
	document.getElementById('ta').innerHTML="t";
	document.getElementById('ta').value="t";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="m";
	document.getElementById('tc').value="m";
	document.getElementById('td').innerHTML="p";
	document.getElementById('td').value="p";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "alitaptap";



	}
	
	
	
	
		function tques197()
{

	document.getElementById('tquestion').innerHTML="Eto na si Kaka May sunong na dampa.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="p";
	document.getElementById('tj').value="p";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pagong";



	}
	
	
	
	
	function tques198()
{

	document.getElementById('tquestion').innerHTML="Bahay ni Goring-goring Butas-butas ang dingding.";
	document.getElementById('ta').innerHTML="k";
	document.getElementById('ta').value="k";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="m";
	document.getElementById('ti').value="m";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kulambo";



	}
	
	
		function tques199()
{

	document.getElementById('tquestion').innerHTML="Alin sa mga ibon ang di makadapo sa kahoy?";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="g";
	document.getElementById('tb').value="g";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="p";
	document.getElementById('td').value="p";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pugo";



	}

	
	

	
	function tques200()
{

	document.getElementById('tquestion').innerHTML="Gintong binalot sa pilak Pilak na binalot sa balat.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="n";
	document.getElementById('te').value="n";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "itlog";



	}
	
	
	
	
	
	
		
	
		function tques201()
{

	document.getElementById('tquestion').innerHTML="Mga kaloobang pinaghalu-halo na niluto sa init ng pagkakasundo.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="u";
	document.getElementById('tg').value="u";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="d";
	document.getElementById('tj').value="d";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "dinuguan";



	}
	
	
	
		function tques202()
{

	document.getElementById('tquestion').innerHTML="Di naman isda, di naman itik Nakahuhuni kung ibig maging sa kati, maging sa tubig ang huni'y nakabubuwisit.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="l";
	document.getElementById('td').value="l";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "palaka";



	}
	
	
	
	
		function tques203()
{

	document.getElementById('tquestion').innerHTML="May puno walang sanga May dahon, walang bunga.";
	document.getElementById('ta').innerHTML="o";
	document.getElementById('ta').value="o";
	document.getElementById('tb').innerHTML="k";
	document.getElementById('tb').value="k";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="y";
	document.getElementById('tf').value="y";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="d";
	document.getElementById('ti').value="d";
	document.getElementById('tj').innerHTML="h";
	document.getElementById('tj').value="h";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sandok";



	}
	
	
	
	
		function tques204()
{

	document.getElementById('tquestion').innerHTML="Walang itak, walang kampit Gumagawa ng bahay na ipit.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="b";
	document.getElementById('ti').value="b";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "gagamba";



	}
	
	
	
	
		function tques205()
{

	document.getElementById('tquestion').innerHTML="Lumalakad walang paa Lumuluha walang mata.";
	document.getElementById('ta').innerHTML="u";
	document.getElementById('ta').value="u";
	document.getElementById('tb').innerHTML="w";
	document.getElementById('tb').value="w";
	document.getElementById('tc').innerHTML="m";
	document.getElementById('tc').value="m";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="o";
	document.getElementById('te').value="o";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="p";
	document.getElementById('ti').value="p";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pluma";



	}
	
	
	
	
		function tques206()
{

	document.getElementById('tquestion').innerHTML="Dahong pinagbungahan, Bungang pinagdahunan.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="p";
	document.getElementById('td').value="p";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="p";
	document.getElementById('th').value="p";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pinya";



	}
	
	
	
	
		function tques207()
{

	document.getElementById('tquestion').innerHTML="Heto na si kurdapya may sunong na baga.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "manok";



	}
	
	
	
	
	function tques208()
{

	document.getElementById('tquestion').innerHTML="Isdang parang ahas, sa karagatan pumapagaspas.";
	document.getElementById('ta').innerHTML="t";
	document.getElementById('ta').value="t";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="u";
	document.getElementById('tf').value="u";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "igat";



	}
	
	
		function tques209()
{

	document.getElementById('tquestion').innerHTML="May alaga akong hayop, malaki ang mata kaysa tuhod.";
	document.getElementById('ta').innerHTML="u";
	document.getElementById('ta').value="u";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="p";
	document.getElementById('td').value="p";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "tutubi";



	}

	
	

	
	function tques210()
{

	document.getElementById('tquestion').innerHTML="Anong insekto sa mundo na naglalakad na walang buto.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "uod";



	}
	
	
	
	
		
		
	
		function tques211()
{

	document.getElementById('tquestion').innerHTML="Pinisa ko at pinirot bago sininghot.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="s";
	document.getElementById('tf').value="s";
	document.getElementById('tg').innerHTML="u";
	document.getElementById('tg').value="u";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="t";
	document.getElementById('ti').value="t";
	document.getElementById('tj').innerHTML="o";
	document.getElementById('tj').value="o";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "surot";



	}
	
	
	
		function tques212()
{

	document.getElementById('tquestion').innerHTML="Koronang mapula ay katulad nito lagi nang nakakabit sa ulo.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="l";
	document.getElementById('td').value="l";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="o";
	document.getElementById('ti').value="o";
	document.getElementById('tj').innerHTML="y";
	document.getElementById('tj').value="y";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "palong";



	}
	
	
	
	
		function tques213()
{

	document.getElementById('tquestion').innerHTML="May puno walang sanga May dahon, walang bunga.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "pamingwit";



	}
	
	
	
	
		function tques214()
{

	document.getElementById('tquestion').innerHTML="Dumating si Canuto, nangabuhay ang mga tao.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="u";
	document.getElementById('ti').value="u";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "umaga";



	}
	
	
	
	
		function tques215()
{

	document.getElementById('tquestion').innerHTML="Kung araw ay patung-patong, kung gabi'y dugtong-dugtong.";
	document.getElementById('ta').innerHTML="u";
	document.getElementById('ta').value="u";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="m";
	document.getElementById('tc').value="m";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="o";
	document.getElementById('te').value="o";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "unan";



	}
	
	
	
	
		function tques216()
{

	document.getElementById('tquestion').innerHTML="Isang hukbong sundalo, dikit-dikit ang mga ulo,";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="w";
	document.getElementById('td').value="w";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "walis";



	}
	
	
	
	
		function tques217()
{

	document.getElementById('tquestion').innerHTML="Dumaing paa'y walang kamay, may pamigkis sa baywang, ang ulo'y parang tagayan, alagad ng kalinisan.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "walis";



	}
	
	
	
	
	function tques218()
{

	document.getElementById('tquestion').innerHTML="Kung tingna'y mainit, hipui'y malamig, umuusok ang paligid.";
	document.getElementById('ta').innerHTML="e";
	document.getElementById('ta').value="e";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="y";
	document.getElementById('tf').value="y";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="g";
	document.getElementById('ti').value="g";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "yelo";



	}
	
	
		function tques219()
{

	document.getElementById('tquestion').innerHTML="Mayroon akong dalawang balon, hindi ko malingon.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="p";
	document.getElementById('td').value="p";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="t";
	document.getElementById('th').value="t";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="t";
	document.getElementById('tj').value="t";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "tainga";



	}

	
	

	
	function tques220()
{

	document.getElementById('tquestion').innerHTML="Nang tangan ko'y patay, nang itapon ko'y nabuhay.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="r";
	document.getElementById('ti').value="r";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "trumpo";



	}
	
	
	
	
	
	
			
		
	
		function tques221()
{

	document.getElementById('tquestion').innerHTML="Binalangkas ko nang binalangkas, bago ko inihampas.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="u";
	document.getElementById('tg').value="u";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="t";
	document.getElementById('ti').value="t";
	document.getElementById('tj').innerHTML="o";
	document.getElementById('tj').value="o";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "trumpo";



	}
	
	
	
		function tques222()
{

	document.getElementById('tquestion').innerHTML="Munting tumataginting, kung saan nanggagaling.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="l";
	document.getElementById('td').value="l";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="e";
	document.getElementById('tg').value="e";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="o";
	document.getElementById('ti').value="o";
	document.getElementById('tj').innerHTML="e";
	document.getElementById('tj').value="e";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "telepono";



	}
	
	
	
	
		function tques223()
{

	document.getElementById('tquestion').innerHTML="Puno na naging tubig, tubig na naging bato, bato na kinain ng tao.";
	document.getElementById('ta').innerHTML="u";
	document.getElementById('ta').value="u";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="b";
	document.getElementById('tc').value="b";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="t";
	document.getElementById('tf').value="t";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="m";
	document.getElementById('tj').value="m";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "tubo";



	}
	
	
	
	
		function tques224()
{

	document.getElementById('tquestion').innerHTML="Ang ibabaw ay tawiran, ang ilalim ay lusutan.";
	document.getElementById('ta').innerHTML="y";
	document.getElementById('ta').value="y";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="l";
	document.getElementById('th').value="l";
	document.getElementById('ti').innerHTML="u";
	document.getElementById('ti').value="u";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "tulay";



	}
	
	
	
	
		function tques225()
{

	document.getElementById('tquestion').innerHTML="Bulaklak muna ang dapat gawin, bago mo ito kanin. ";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="m";
	document.getElementById('tc').value="m";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "saging";



	}
	
	
	
	
		function tques226()
{

	document.getElementById('tquestion').innerHTML="Sapagkat lahat na ay nakahihipo, walang kasindumi't walang kasimbaho, bakit mahal nati't ipinakatatago.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="w";
	document.getElementById('td').value="w";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "salapi";



	}
	
	
	
	
		function tques227()
{

	document.getElementById('tquestion').innerHTML="Aling mabuting retrato ang kuhang-kuha sa mukha mo? ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "salamin";



	}
	
	
	
	
	function tques228()
{

	document.getElementById('tquestion').innerHTML="Sinampal ko muna bago inalok.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="k";
	document.getElementById('tf').value="k";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="m";
	document.getElementById('ti').value="m";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sampalok";



	}
	
	
		function tques229()
{

	document.getElementById('tquestion').innerHTML="Ang ulo'y nalalaga ang katawa'y pagala-gala.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="o";
	document.getElementById('ti').value="o";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sandok";



	}

	
	

	
	function tques230()
{

	document.getElementById('tquestion').innerHTML="Alipin ng hari, hindi makalakad, kung hindi itali.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="p";
	document.getElementById('tb').value="p";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="a";
	document.getElementById('ti').value="a";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sapatos";



	}
	
	
	
	
	
				
		
	
		function tques231()
{

	document.getElementById('tquestion').innerHTML="Baboy ko sa parang, namumula sa tapang.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="u";
	document.getElementById('tg').value="u";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="l";
	document.getElementById('tj').value="l";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sili";



	}
	
	
	
		function tques232()
{

	document.getElementById('tquestion').innerHTML="Munting tampipi puno ng salapi.";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="l";
	document.getElementById('td').value="l";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="i";
	document.getElementById('tg').value="i";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="o";
	document.getElementById('ti').value="o";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sili";



	}
	
	
	
	
		function tques233()
{

	document.getElementById('tquestion').innerHTML="Isang lupa-lupaan sa dulo ng kawayan.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="y";
	document.getElementById('tf').value="y";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sigarilyo";



	}
	
	
	
	
		function tques234()
{

	document.getElementById('tquestion').innerHTML="Hiyas akong mabilog, sa daliri isinusuot.";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="g";
	document.getElementById('th').value="g";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "singsing";



	}
	
	
	
	
		function tques235()
{

	document.getElementById('tquestion').innerHTML="Buklod na tinampukan, saksi ng pag-iibigan.";
	document.getElementById('ta').innerHTML="g";
	document.getElementById('ta').value="g";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="m";
	document.getElementById('tc').value="m";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "singsing";



	}
	
	
	
	
		function tques236()
{

	document.getElementById('tquestion').innerHTML="Ipinalilok ko at ipinalubid, nang higpitan ang kapit.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="n";
	document.getElementById('tg').value="n";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="t";
	document.getElementById('ti').value="t";
	document.getElementById('tj').innerHTML="u";
	document.getElementById('tj').value="u";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sinturon";



	}
	
	
	
	
		function tques237()
{

	document.getElementById('tquestion').innerHTML="Nang munti pa ay paruparo, nang lumaki ay latigo.";
	document.getElementById('ta').innerHTML="t";
	document.getElementById('ta').value="t";
	document.getElementById('tb').innerHTML="s";
	document.getElementById('tb').value="s";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="m";
	document.getElementById('tg').value="m";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="i";
	document.getElementById('tj').value="i";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sitaw";



	}
	
	
	
	
	function tques238()
{

	document.getElementById('tquestion').innerHTML="Bumili ako ng alipin, mataas pa sa akin.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="s";
	document.getElementById('tc').value="s";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="r";
	document.getElementById('tf').value="r";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="b";
	document.getElementById('th').value="b";
	document.getElementById('ti').innerHTML="m";
	document.getElementById('ti').value="m";
	document.getElementById('tj').innerHTML="e";
	document.getElementById('tj').value="e";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sumbrero";



	}
	
	
		function tques239()
{

	document.getElementById('tquestion').innerHTML="Isang tabo, laman ay pako.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="s";
	document.getElementById('td').value="s";
	document.getElementById('te').innerHTML="u";
	document.getElementById('te').value="u";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="h";
	document.getElementById('ti').value="h";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "suha";



	}

	
	

	
	function tques240()
{

	document.getElementById('tquestion').innerHTML="Isang panyong parisukat, kung buksa'y nakakausap.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "sulat";



	}
	
	
	
	
	
					
		
	
		function tques241()
{

	document.getElementById('tquestion').innerHTML="Dalawang magkaibigan, habulan nang habulan. ";
	document.getElementById('ta').innerHTML="s";
	document.getElementById('ta').value="s";
	document.getElementById('tb').innerHTML="i";
	document.getElementById('tb').value="i";
	document.getElementById('tc').innerHTML="u";
	document.getElementById('tc').value="u";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="p";
	document.getElementById('te').value="p";
	document.getElementById('tf').innerHTML="m";
	document.getElementById('tf').value="m";
	document.getElementById('tg').innerHTML="u";
	document.getElementById('tg').value="u";
	document.getElementById('th').innerHTML="y";
	document.getElementById('th').value="y";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="a";
	document.getElementById('tj').value="a";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "paa";



	}
	
	
	
		function tques242()
{

	document.getElementById('tquestion').innerHTML="May ulo'y walang mukha, may katawa'y walang sikmura. Namamahay ng sadya. ";
	document.getElementById('ta').innerHTML="i";
	document.getElementById('ta').value="i";
	document.getElementById('tb').innerHTML="t";
	document.getElementById('tb').value="t";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="l";
	document.getElementById('td').value="l";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="i";
	document.getElementById('tg').value="i";
	document.getElementById('th').innerHTML="k";
	document.getElementById('th').value="k";
	document.getElementById('ti').innerHTML="o";
	document.getElementById('ti').value="o";
	document.getElementById('tj').innerHTML="p";
	document.getElementById('tj').value="p";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "palito";



	}
	
	
	
	
		function tques243()
{

	document.getElementById('tquestion').innerHTML="Binatak ko ang isa, pawis ang kasama.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="n";
	document.getElementById('tb').value="n";
	document.getElementById('tc').innerHTML="r";
	document.getElementById('tc').value="r";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="y";
	document.getElementById('tf').value="y";
	document.getElementById('tg').innerHTML="o";
	document.getElementById('tg').value="o";
	document.getElementById('th').innerHTML="i";
	document.getElementById('th').value="i";
	document.getElementById('ti').innerHTML="w";
	document.getElementById('ti').value="w";
	document.getElementById('tj').innerHTML="s";
	document.getElementById('tj').value="s";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "panyo";



	}
	
	
	
	
		function tques244()
{

	document.getElementById('tquestion').innerHTML="Ang puno'y buku-buko,ang sanga'y baril, ang bunga'y bote, ang laman ay diyamante.";
	document.getElementById('ta').innerHTML="p";
	document.getElementById('ta').value="p";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="g";
	document.getElementById('tc').value="g";
	document.getElementById('td').innerHTML="n";
	document.getElementById('td').value="n";
	document.getElementById('te').innerHTML="a";
	document.getElementById('te').value="a";
	document.getElementById('tf').innerHTML="h";
	document.getElementById('tf').value="h";
	document.getElementById('tg').innerHTML="y";
	document.getElementById('tg').value="y";
	document.getElementById('th').innerHTML="a";
	document.getElementById('th').value="a";
	document.getElementById('ti').innerHTML="i";
	document.getElementById('ti').value="i";
	document.getElementById('tj').innerHTML="p";
	document.getElementById('tj').value="p";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "papaya";



	}
	
	
	
	
		function tques245()
{

	document.getElementById('tquestion').innerHTML="Ang labas ay tabla-tabla ang loob ay sala-sala.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="t";
	document.getElementById('tc').value="t";
	document.getElementById('td').innerHTML="i";
	document.getElementById('td').value="i";
	document.getElementById('te').innerHTML="g";
	document.getElementById('te').value="g";
	document.getElementById('tf').innerHTML="i";
	document.getElementById('tf').value="i";
	document.getElementById('tg').innerHTML="l";
	document.getElementById('tg').value="l";
	document.getElementById('th').innerHTML="o";
	document.getElementById('th').value="o";
	document.getElementById('ti').innerHTML="n";
	document.getElementById('ti').value="n";
	document.getElementById('tj').innerHTML="p";
	document.getElementById('tj').value="p";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "patola";



	}
	
	
	
	
		function tques246()
{

	document.getElementById('tquestion').innerHTML="Dalawang bolang sinulid, abot hanggang langit. ";
	document.getElementById('ta').innerHTML="m";
	document.getElementById('ta').value="m";
	document.getElementById('tb').innerHTML="o";
	document.getElementById('tb').value="o";
	document.getElementById('tc').innerHTML="y";
	document.getElementById('tc').value="y";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="i";
	document.getElementById('te').value="i";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="s";
	document.getElementById('th').value="s";
	document.getElementById('ti').innerHTML="t";
	document.getElementById('ti').value="t";
	document.getElementById('tj').innerHTML="u";
	document.getElementById('tj').value="u";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "mata";



	}
	
	
	
	
		function tques247()
{

	document.getElementById('tquestion').innerHTML="Araw araw bagong buhay, Taun-taon namamatay. ";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="y";
	document.getElementById('tb').value="y";
	document.getElementById('tc').innerHTML="o";
	document.getElementById('tc').value="o";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="r";
	document.getElementById('te').value="r";
	document.getElementById('tf').innerHTML="l";
	document.getElementById('tf').value="l";
	document.getElementById('tg').innerHTML="e";
	document.getElementById('tg').value="e";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="d";
	document.getElementById('ti').value="d";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kalendaryo";



	}
	
	
	
	
	function tques248()
{

	document.getElementById('tquestion').innerHTML="Ako'y aklat ng panahon, Binabago taun taon.";
	document.getElementById('ta').innerHTML="r";
	document.getElementById('ta').value="r";
	document.getElementById('tb').innerHTML="a";
	document.getElementById('tb').value="a";
	document.getElementById('tc').innerHTML="k";
	document.getElementById('tc').value="k";
	document.getElementById('td').innerHTML="o";
	document.getElementById('td').value="o";
	document.getElementById('te').innerHTML="y";
	document.getElementById('te').value="y";
	document.getElementById('tf').innerHTML="d";
	document.getElementById('tf').value="d";
	document.getElementById('tg').innerHTML="a";
	document.getElementById('tg').value="a";
	document.getElementById('th').innerHTML="n";
	document.getElementById('th').value="n";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="e";
	document.getElementById('tj').value="e";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kalendaryo";



	}
	
	
		function tques249()
{

	document.getElementById('tquestion').innerHTML="May katawan walang mukha, walang mata'y lumuluha.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="b";
	document.getElementById('tb').value="b";
	document.getElementById('tc').innerHTML="i";
	document.getElementById('tc').value="i";
	document.getElementById('td').innerHTML="a";
	document.getElementById('td').value="a";
	document.getElementById('te').innerHTML="l";
	document.getElementById('te').value="l";
	document.getElementById('tf').innerHTML="n";
	document.getElementById('tf').value="n";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="h";
	document.getElementById('ti').value="h";
	document.getElementById('tj').innerHTML="k";
	document.getElementById('tj').value="k";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "kandila";



	}

	
	

	
	function tques250()
{

	document.getElementById('tquestion').innerHTML="Dalawang katawan, tagusan ang tadyang.";
	document.getElementById('ta').innerHTML="a";
	document.getElementById('ta').value="a";
	document.getElementById('tb').innerHTML="u";
	document.getElementById('tb').value="u";
	document.getElementById('tc').innerHTML="n";
	document.getElementById('tc').value="n";
	document.getElementById('td').innerHTML="t";
	document.getElementById('td').value="t";
	document.getElementById('te').innerHTML="s";
	document.getElementById('te').value="s";
	document.getElementById('tf').innerHTML="a";
	document.getElementById('tf').value="a";
	document.getElementById('tg').innerHTML="g";
	document.getElementById('tg').value="g";
	document.getElementById('th').innerHTML="d";
	document.getElementById('th').value="d";
	document.getElementById('ti').innerHTML="l";
	document.getElementById('ti').value="l";
	document.getElementById('tj').innerHTML="h";
	document.getElementById('tj').value="h";	
	document.getElementById("tnumero").innerHTML = "riddle no: " + tnumb;

tright_ans = "hagdan";



	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function tsubmit()
{


 
document.getElementById("tdito").innerHTML = "";
 

if(tsagot==tright_ans)
{
tscore++;
tnumb++;

document.getElementById("tscore").innerHTML = "score: " + tscore;
document.getElementById("tans").innerHTML = "";
alert("You are Correct!!!");



if(tnumb == 6 || tnumb == 11 || tnumb == 16 || tnumb == 21 || tnumb == 26 || tnumb == 31 || tnumb == 36 || tnumb == 41 || tnumb == 46 || tnumb == 51 || tnumb == 56 || tnumb == 61 || tnumb == 66 || tnumb == 71 || tnumb == 76 || tnumb == 81 || tnumb == 86 || tnumb == 91 || tnumb == 96 || tnumb == 101 || tnumb == 106 || tnumb == 111 || tnumb == 116 || tnumb == 121 || tnumb == 126 || tnumb == 131 || tnumb == 136 || tnumb == 141 || tnumb == 146 || tnumb == 151 || tnumb == 156 || tnumb == 161 || tnumb == 166 || tnumb == 171 || tnumb == 176 || tnumb == 181 || tnumb == 186 || tnumb == 191 || tnumb == 196 || tnumb == 201 || tnumb == 206 || tnumb == 211 || tnumb == 216 || tnumb == 221 || tnumb == 226 || tnumb == 231 || tnumb == 236 || tnumb == 241 || tnumb == 246)
{

$("#thint").show(1500);
$("#thint2").show(1500);
$("#thint3").show(1500);

$("#f_thint").hide();
$("#f_thint2").hide();
$("#f_thint3").hide();


}




tp++;
tsagot = "";

if(tnumb>250)
{
document.getElementById("tsubmit").href = "#winner_t_u";

document.getElementById("fscore_t_u").innerHTML = "score: " + tscore;
}

else{
start_t_u();}
}
else
{
tlife--;


if (tlife == 0){$("#tlif3").hide();}

document.getElementById("tscore").innerHTML = "score: " + tscore;
document.getElementById("tans").innerHTML = "";
alert("You are Wrong!!!");



if (tlife == 2){$("#tlif1").hide(1500);}
else if (tlife == 1){$("#tlif2").hide(1500);}









if(tlife == 0)
{

document.getElementById("tsubmit").href = "#exit_t_u";

document.getElementById("gfscore_t_u").innerHTML = "score: " + tscore;

}


else{
tnumb++;

tp++;

tsagot = "";


if(tnumb == 6 || tnumb == 11 || tnumb == 16 || tnumb == 21 || tnumb == 26 || tnumb == 31 || tnumb == 36 || tnumb == 41 || tnumb == 46 || tnumb == 51 || tnumb == 56 || tnumb == 61 || tnumb == 66 || tnumb == 71 || tnumb == 76 || tnumb == 81 || tnumb == 86 || tnumb == 91 || tnumb == 96 || tnumb == 101 || tnumb == 106 || tnumb == 111 || tnumb == 116 || tnumb == 121 || tnumb == 126 || tnumb == 131 || tnumb == 136 || tnumb == 141 || tnumb == 146 || tnumb == 151 || tnumb == 156 || tnumb == 161 || tnumb == 166 || tnumb == 171 || tnumb == 176 || tnumb == 181 || tnumb == 186 || tnumb == 191 || tnumb == 196 || tnumb == 201 || tnumb == 206 || tnumb == 211 || tnumb == 216 || tnumb == 221 || tnumb == 226 || tnumb == 231 || tnumb == 236 || tnumb == 241 || tnumb == 246)
{


$("#thint").show(1500);
$("#thint2").show(1500);
$("#thint3").show(1500);

$("#f_thint").hide();
$("#f_thint2").hide();
$("#f_thint3").hide();


}

if(tnumb>250)
{
document.getElementById("tsubmit").href = "#winner_t_u";

document.getElementById("fscore_t_u").innerHTML = "score: " + tscore;
}

start_t_u();
}

}

changeColor2();
}


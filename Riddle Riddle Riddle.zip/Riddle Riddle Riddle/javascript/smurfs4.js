var pt = 1 ;
var anst = "" ;
var sagott = "";
var right_anst = "" ;
var scoret = 0;
var numbt = 1;
var s = 59;
var m = 9;
var q;
var let_num4 = "";















function bura4()
{
var dine = sagott.length - 1;

sagott = sagott.substring(0,dine);
document.getElementById("anst").innerHTML = sagott;

var dindin = let_num4.length - 1;
var pj = let_num4.charAt(dindin);
if(pj == "a")
{$("#at").show(200);
let_num4 = let_num4.substring(0,dindin);
}
else if(pj == "b")
{$("#bt").show(200);
let_num4 = let_num4.substring(0,dindin);}
else if(pj == "c")
{$("#ct").show(200);
let_num4 = let_num4.substring(0,dindin);}
else if(pj == "d")
{$("#dt").show(200);
let_num4 = let_num4.substring(0,dindin);}
else if(pj == "e")
{$("#et").show(200);
let_num4 = let_num4.substring(0,dindin);}
else if(pj == "f")
{$("#ft").show(200);
let_num4 = let_num4.substring(0,dindin);}
else if(pj == "g")
{$("#gt").show(200);
let_num4 = let_num4.substring(0,dindin);}
else if(pj == "h")
{$("#ht").show(200);
let_num4 = let_num4.substring(0,dindin);}
else if(pj == "i")
{$("#it").show(200);
let_num4 = let_num4.substring(0,dindin);}
else if(pj == "j")
{$("#jt").show(200);
let_num4 = let_num4.substring(0,dindin);}




}






















function homing4()
{
  var x;
    if (confirm("You want to quit?") == true) {
 document.getElementById("4home_b").href =  "#page1";
  } else {
 document.getElementById("4home_b").href =  "";
    }
}









$(document).ready(function(){
$("#at").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#bt").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#ct").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#dt").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#et").click(function(){
$(this).hide(200);
});
});








$(document).ready(function(){
$("#ft").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#gt").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#ht").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#it").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#jt").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#resett").click(function(){
$("#at,#ct,#bt,#dt,#et,#gt,#ft,#ht,#it,#jt").show(200);
});
});


$(document).ready(function(){
$("#submitt").click(function(){
$("#at,#ct,#bt,#dt,#et,#gt,#ft,#ht,#it,#jt").show(200);
});
});



function tgokay_e_u()
{
var pt = 1 ;
var anst = "" ;
var sagott = "";
var right_anst = "" ;
var scoret = 0;
var numbt = 1;
var s = 59;
var m = 1;
var q;


}




function tcokay_e_u()
{
var pt = 1 ;
var anst = "" ;
var sagott = "";
var right_anst = "" ;
var scoret = 0;
var numbt = 1;
var s = 59;
var m = 1;
var q;


}

function tstart_e_u()
{

var random = Math.floor(Math.random()*2);
if(random==0){random++;}

$("#gameover").hide();



if(pt==1)
	{
		
	teques1();
times();
	}
	else if(pt==2)
	{
		
	teques2();

	}
	else if(pt==3)
		
	{
	teques3();

	}

	else if(pt==4)
		
	{
	teques4();

	}
	else if(pt==5)
		
	{
	teques5();

	}

	else if(pt==6)
		
	{
	teques6();

	}
	else if(pt==7)
		
	{
	teques7();

	}
	else if(pt==8)
		
	{
	teques8();

	}
	else if(pt==9)
		
	{
	teques9();

	}
	else if(pt==10)
		
	{
	teques10();

	}


	else if(pt==11)
	{
		
	teques11();

	}
	else if(pt==12)
	{
		
	teques12();

	}
	else if(pt==13)
		
	{
	teques13();

	}

	else if(pt==14)
		
	{
	teques14();

	}
	else if(pt==15)
		
	{
	teques15();

	}

	else if(pt==16)
		
	{
	teques16();

	}
	else if(pt==17)
		
	{
	teques17();

	}
	else if(pt==18)
		
	{
	teques18();

	}
	else if(pt==19)
		
	{
	teques19();

	}
	else if(pt==20)
		
	{
	teques20();

	}

	
	
	else if(pt==21)
	{
		
	teques21();

	}
	else if(pt==22)
	{
		
	teques22();

	}
	else if(pt==23)
		
	{
	teques23();

	}

	else if(pt==24)
		
	{
	teques24();

	}
	else if(pt==25)
		
	{
	teques25();

	}

	else if(pt==26)
		
	{
	teques26();

	}
	else if(pt==27)
		
	{
	teques27();

	}
	else if(pt==28)
		
	{
	teques28();

	}
	else if(pt==29)
		
	{
	teques29();

	}
	else if(pt==30)
		
	{
	teques30();

	}

	
	
	else if(pt==31)
	{
		
	teques31();

	}
	else if(pt==32)
	{
		
	teques32();

	}
	else if(pt==33)
		
	{
	teques33();

	}

	else if(pt==34)
		
	{
	teques34();

	}
	else if(pt==35)
		
	{
	teques35();

	}

	else if(pt==36)
		
	{
	teques36();

	}
	else if(pt==37)
		
	{
	teques37();

	}
	else if(pt==38)
		
	{
	teques38();

	}
	else if(pt==39)
		
	{
	teques39();

	}
	else if(pt==40)
		
	{
	teques40();

	}


	
	else if(pt==41)
	{
		
	teques41();

	}
	else if(pt==42)
	{
		
	teques42();

	}
	else if(pt==43)
		
	{
	teques43();

	}

	else if(pt==44)
		
	{
	teques44();

	}
	else if(pt==45)
		
	{
	teques45();

	}

	else if(pt==46)
		
	{
	teques46();

	}
	else if(pt==47)
		
	{
	teques47();

	}
	else if(pt==48)
		
	{
	teques48();

	}
	else if(pt==49)
		
	{
	teques49();

	}
	else if(pt==50)
		
	{
	teques50();

	}


		
	else if(pt==51)
	{
		
	teques51();

	}
	else if(pt==52)
	{
		
	teques52();

	}
	else if(pt==53)
		
	{
	teques53();

	}

	else if(pt==54)
		
	{
	teques54();

	}
	else if(pt==55)
		
	{
	teques55();

	}

	else if(pt==56)
		
	{
	teques56();

	}
	else if(pt==57)
		
	{
	teques57();

	}
	else if(pt==58)
		
	{
	teques58();

	}
	else if(pt==59)
		
	{
	teques59();

	}
	else if(pt==60)
		
	{
	teques60();

	}
	
	
	else if(pt==61)
	{
		
	teques61();

	}
	else if(pt==62)
	{
		
	teques62();

	}
	else if(pt==63)
		
	{
	teques63();

	}

	else if(pt==64)
		
	{
	teques64();

	}
	else if(pt==65)
		
	{
	teques65();

	}

	else if(pt==66)
		
	{
	teques66();

	}
	else if(pt==67)
		
	{
	teques67();

	}
	else if(pt==68)
		
	{
	teques68();

	}
	else if(pt==69)
		
	{
	teques69();

	}
	else if(pt==70)
		
	{
	teques70();

	}
	
	
	else if(pt==71)
	{
		
	teques71();

	}
	else if(pt==72)
	{
		
	teques72();

	}
	else if(pt==73)
		
	{
	teques73();

	}

	else if(pt==74)
		
	{
	teques74();

	}
	else if(pt==75)
		
	{
	teques75();

	}

	else if(pt==76)
		
	{
	teques76();

	}
	else if(pt==77)
		
	{
	teques77();

	}
	else if(pt==78)
		
	{
	teques78();

	}
	else if(pt==79)
		
	{
	teques79();

	}
	else if(pt==80)
		
	{
	teques80();

	}
	
	
	else if(pt==81)
	{
		
	teques81();

	}
	else if(pt==82)
	{
		
	teques82();

	}
	else if(pt==83)
		
	{
	teques83();

	}

	else if(pt==84)
		
	{
	teques84();

	}
	else if(pt==85)
		
	{
	teques85();

	}

	else if(pt==86)
		
	{
	teques86();

	}
	else if(pt==87)
		
	{
	teques87();

	}
	else if(pt==88)
		
	{
	teques88();

	}
	else if(pt==89)
		
	{
	teques89();

	}
	else if(pt==90)
		
	{
	teques90();

	}
	
	
	
	
	else if(pt==91)
	{
		
	teques91();

	}
	else if(pt==92)
	{
		
	teques92();

	}
	else if(pt==93)
		
	{
	teques93();

	}

	else if(pt==94)
		
	{
	teques94();

	}
	else if(pt==95)
		
	{
	teques95();

	}

	else if(pt==96)
		
	{
	teques96();

	}
	else if(pt==97)
		
	{
	teques97();

	}
	else if(pt==98)
		
	{
	teques98();

	}
	else if(pt==99)
		
	{
	teques99();

	}
	else if(pt==100)
		
	{
	teques100();

	}
	
	
	

	else if(pt==101)
	{
		
	teques101();

	}
	else if(pt==102)
	{
		
	teques102();

	}
	else if(pt==103)
		
	{
	teques103();

	}

	else if(pt==104)
		
	{
	teques104();

	}
	else if(pt==105)
		
	{
	teques105();

	}

	else if(pt==106)
		
	{
	teques106();

	}
	else if(pt==107)
		
	{
	teques107();

	}
	else if(pt==108)
		
	{
	teques108();

	}
	else if(pt==109)
		
	{
	teques109();

	}
	else if(pt==110)
		
	{
	teques110();

	}

	

	else if(pt==111)
	{
		
	teques111();

	}
	else if(pt==112)
	{
		
	teques112();

	}
	else if(pt==113)
		
	{
	teques113();

	}

	else if(pt==114)
		
	{
	teques114();

	}
	else if(pt==115)
		
	{
	teques115();

	}

	else if(pt==116)
		
	{
	teques116();

	}
	else if(pt==117)
		
	{
	teques117();

	}
	else if(pt==118)
		
	{
	teques118();

	}
	else if(pt==119)
		
	{
	teques119();

	}
	else if(pt==120)
		
	{
	teques120();

	}

	else if(pt==121)
	{
		
	teques121();

	}
	else if(pt==122)
	{
		
	teques122();

	}
	else if(pt==123)
		
	{
	teques123();

	}

	else if(pt==124)
		
	{
	teques124();

	}
	else if(pt==125)
		
	{
	teques125();

	}

	else if(pt==126)
		
	{
	teques126();

	}
	else if(pt==127)
		
	{
	teques127();

	}
	else if(pt==128)
		
	{
	teques128();

	}
	else if(pt==129)
		
	{
	teques129();

	}
	else if(pt==130)
		
	{
	teques130();

	}
	
	
	else if(pt==131)
	{
		
	teques131();

	}
	else if(pt==132)
	{
		
	teques132();

	}
	else if(pt==133)
		
	{
	teques133();

	}

	else if(pt==134)
		
	{
	teques134();

	}
	else if(pt==135)
		
	{
	teques135();

	}

	else if(pt==136)
		
	{
	teques136();

	}
	else if(pt==137)
		
	{
	teques137();

	}
	else if(pt==138)
		
	{
	teques138();

	}
	else if(pt==139)
		
	{
	teques139();

	}
	else if(pt==140)
		
	{
	teques140();

	}
	
	
	
	else if(pt==141)
	{
		
	teques141();

	}
	else if(pt==142)
	{
		
	teques142();

	}
	else if(pt==143)
		
	{
	teques143();

	}

	else if(pt==144)
		
	{
	teques144();

	}
	else if(pt==145)
		
	{
	teques145();

	}

	else if(pt==146)
		
	{
	teques146();

	}
	else if(pt==147)
		
	{
	teques147();

	}
	else if(pt==148)
		
	{
	teques148();

	}
	else if(pt==149)
		
	{
	teques149();

	}
	else if(pt==150)
		
	{
	teques150();

	}
	
	
	
	else if(pt==151)
	{
		
	teques151();

	}
	else if(pt==152)
	{
		
	teques152();

	}
	else if(pt==153)
		
	{
	teques153();

	}

	else if(pt==154)
		
	{
	teques154();

	}
	else if(pt==155)
		
	{
	teques155();

	}

	else if(pt==156)
		
	{
	teques156();

	}
	else if(pt==157)
		
	{
	teques157();

	}
	else if(pt==158)
		
	{
	teques158();

	}
	else if(pt==159)
		
	{
	teques159();

	}
	else if(pt==160)
		
	{
	teques160();

	}
	
	
	else if(pt==161)
	{
		
	teques161();

	}
	else if(pt==162)
	{
		
	teques162();

	}
	else if(pt==163)
		
	{
	teques163();

	}

	else if(pt==164)
		
	{
	teques164();

	}
	else if(pt==165)
		
	{
	teques165();

	}

	else if(pt==166)
		
	{
	teques166();

	}
	else if(pt==167)
		
	{
	teques167();

	}
	else if(pt==168)
		
	{
	teques168();

	}
	else if(pt==169)
		
	{
	teques169();

	}
	else if(pt==170)
		
	{
	teques170();

	}
	
	
	else if(pt==171)
	{
		
	teques171();

	}
	else if(pt==172)
	{
		
	teques172();

	}
	else if(pt==173)
		
	{
	teques173();

	}

	else if(pt==174)
		
	{
	teques174();

	}
	else if(pt==175)
		
	{
	teques175();

	}

	else if(pt==176)
		
	{
	teques176();

	}
	else if(pt==177)
		
	{
	teques177();

	}
	else if(pt==178)
		
	{
	teques178();

	}
	else if(pt==179)
		
	{
	teques179();

	}
	else if(pt==180)
		
	{
	teques180();

	}
	
	
	else if(pt==181)
	{
		
	teques181();

	}
	else if(pt==182)
	{
		
	teques182();

	}
	else if(pt==183)
		
	{
	teques183();

	}

	else if(pt==184)
		
	{
	teques184();

	}
	else if(pt==185)
		
	{
	teques185();

	}

	else if(pt==186)
		
	{
	teques186();

	}
	else if(pt==187)
		
	{
	teques187();

	}
	else if(pt==188)
		
	{
	teques188();

	}
	else if(pt==189)
		
	{
	teques189();

	}
	else if(pt==190)
		
	{
	teques190();

	}
	
	
	
	
	else if(pt==191)
	{
		
	teques191();

	}
	else if(pt==192)
	{
		
	teques192();

	}
	else if(pt==193)
		
	{
	teques193();

	}

	else if(pt==194)
		
	{
	teques194();

	}
	else if(pt==195)
		
	{
	teques195();

	}

	else if(pt==196)
		
	{
	teques196();

	}
	else if(pt==197)
		
	{
	teques197();

	}
	else if(pt==198)
		
	{
	teques198();

	}
	else if(pt==199)
		
	{
	teques199();

	}
	else if(pt==200)
		
	{
	teques200();

	}
	
	
	
	
	else if(pt==201)
	{
		
	teques201();

	}
	
	else if(pt==202)
	{
		
	teques202();

	}
	else if(pt==203)
		
	{
	teques203();

	}

	else if(pt==204)
		
	{
	teques204();

	}
	else if(pt==205)
		
	{
	teques205();

	}

	else if(pt==206)
		
	{
	teques206();

	}
	else if(pt==207)
		
	{
	teques207();

	}
	else if(pt==208)
		
	{
	teques208();

	}
	else if(pt==209)
		
	{
	teques209();

	}
	else if(pt==210)
		
	{
	teques210();

	}


	else if(pt==211)
	{
		
	teques211();

	}
	else if(pt==212)
	{
		
	teques212();

	}
	else if(pt==213)
		
	{
	teques213();

	}

	else if(pt==214)
		
	{
	teques214();

	}
	else if(pt==215)
		
	{
	teques215();

	}

	else if(pt==216)
		
	{
	teques216();

	}
	else if(pt==217)
		
	{
	teques217();

	}
	else if(pt==218)
		
	{
	teques218();

	}
	else if(pt==219)
		
	{
	teques219();

	}
	else if(pt==220)
		
	{
	teques220();

	}

	
	else if(pt==221)
	{
		
	teques221();

	}
	else if(pt==222)
	{
		
	teques222();

	}
	else if(pt==223)
		
	{
	teques223();

	}

	else if(pt==224)
		
	{
	teques224();

	}
	else if(pt==225)
		
	{
	teques225();

	}

	else if(pt==226)
		
	{
	teques226();

	}
	else if(pt==227)
		
	{
	teques227();

	}
	else if(pt==228)
		
	{
	teques228();

	}
	else if(pt==229)
		
	{
	teques229();

	}
	else if(pt==230)
		
	{
	teques230();

	}

	
	else if(pt==231)
	{
		
	teques231();

	}
	else if(pt==232)
	{
		
	teques232();

	}
	else if(pt==233)
		
	{
	teques233();

	}

	else if(pt==234)
		
	{
	teques234();

	}
	else if(pt==235)
		
	{
	teques235();

	}

	else if(pt==236)
		
	{
	teques236();

	}
	else if(pt==237)
		
	{
	teques237();

	}
	else if(pt==238)
		
	{
	teques238();

	}
	else if(pt==239)
		
	{
	teques239();

	}
	else if(pt==240)
		
	{
	teques240();

	}


	else if(pt==241)
	{
		
	teques241();

	}
	else if(pt==242)
	{
		
	teques242();

	}
	else if(pt==243)
		
	{
	teques243();

	}

	else if(pt==244)
		
	{
	teques244();

	}
	else if(pt==245)
		
	{
	teques245();

	}

	else if(pt==246)
		
	{
	teques246();

	}
	else if(pt==247)
		
	{
	teques247();

	}
	else if(pt==248)
		
	{
	teques248();

	}
	else if(pt==249)
		
	{
	teques249();

	}
	else if(pt==250)
		
	{
	teques250();

	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


}







	
	
function at()
{


var a = document.getElementById("at").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "a";
}


	
function bt()
{


var a = document.getElementById("bt").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "b";
}



function ct()
{


var a = document.getElementById("ct").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "c";
}





function dt()
{


var a = document.getElementById("dt").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "d";
}



function et()
{

var a = document.getElementById("et").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "e";
}



function ft()
{

var a = document.getElementById("ft").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "f";
}

function gt()
{

var a = document.getElementById("gt").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "g";
}

function ht()
{

var a = document.getElementById("ht").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "h";
}

function it()
{

var a = document.getElementById("it").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "i";
}

function jt()
{

var a = document.getElementById("jt").value;

sagott = sagott + a;

document.getElementById("anst").innerHTML = sagott;
let_num4 = let_num4 + "j";
}




function resett()
{


sagott = "";

document.getElementById("anst").innerHTML = sagott;
}





function teques50()
{

	document.getElementById('questiont').innerHTML="What's black when you get it, red when you use it, and white when you're all through with it?";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="c";
	document.getElementById('bt').value="c";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="y";
	document.getElementById('gt').value="y";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="h";
	document.getElementById('it').value="h";
	document.getElementById('jt').innerHTML="l";
	document.getElementById('jt').value="l";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "charcoal";




	}

	
	
	
function teques42()
{

	document.getElementById('questiont').innerHTML="Feed me and I live, give me drink and I die. What am I?";
	document.getElementById('at').innerHTML="g";
	document.getElementById('at').value="g";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="f";
	document.getElementById('dt').value="f";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="d";
	document.getElementById('ft').value="d";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "fire";




	}

	
	
	
	
	
	
function teques43()
{

	document.getElementById('questiont').innerHTML="It walks on four legs in the morning, two legs at noon and three legs in the evening. What is it?";
	document.getElementById('at').innerHTML="x";
	document.getElementById('at').value="x";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="d";
	document.getElementById('ft').value="d";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="m";
	document.getElementById('ht').value="m";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "man";




	}

	
	
	
	
	
function teques44()
{

	document.getElementById('questiont').innerHTML="At night it comes without being fetched. By day it is lost without being stolen. What is it?";
	document.getElementById('at').innerHTML="g";
	document.getElementById('at').value="g";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "star";




	}

	
			
		function teques45()
{

	document.getElementById('questiont').innerHTML="You throw away the outside and cook the inside. Then you eat the outside and throw away the inside. What did you eat?";
	document.getElementById('at').innerHTML="g";
	document.getElementById('at').value="g";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="p";
	document.getElementById('ht').value="p";
	document.getElementById('it').innerHTML="d";
	document.getElementById('it').value="d";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "corn";




	}

	
	
	
	
	
	
	
	
		function teques46()
{

	document.getElementById('questiont').innerHTML= "Until I am measured I am not known, Yet how you miss me when I have flown.";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="t";
	document.getElementById('gt').value="t";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "time";





	}

	
	
		
		function teques47()
{

	document.getElementById('questiont').innerHTML= "Lighter than what I am made of, More of me is hidden Than is seen.";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="b";
	document.getElementById('ct').value="b";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="t";
	document.getElementById('gt').value="t";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "iceberg";





	}

	
	
		
		function teques48()
{

	document.getElementById('questiont').innerHTML="You heard me before, yet you hear me again, Then I die, 'till you call me again.";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="h";
	document.getElementById('dt').value="h";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "echo";




	}

	
	
			
		function teques49()
{

	document.getElementById('questiont').innerHTML="A box without hinges, lock or key, yet golden treasure lies within. What is it?";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="y";
	document.getElementById('jt').value="y";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "egg";




	}

	
	
	
				
		function teques41()
{

	document.getElementById('questiont').innerHTML="Light as a feather, there is nothing in it.";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="k";
	document.getElementById('dt').value="k";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="x";
	document.getElementById('gt').value="x";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "breath";



	}

	
	
					
		function teques11()
{

	document.getElementById('questiont').innerHTML="I know a word of letters three. Add two, and fewer there will be!";
	document.getElementById('at').innerHTML="x";
	document.getElementById('at').value="x";
	document.getElementById('bt').innerHTML="f";
	document.getElementById('bt').value="f";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="k";
	document.getElementById('dt').value="k";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="x";
	document.getElementById('gt').value="x";
	document.getElementById('ht').innerHTML="w";
	document.getElementById('ht').value="w";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "few";



	}
	
	
	
		
					
		function teques12()
{

	document.getElementById('questiont').innerHTML="I have four legs but no tail. Usually I am heard only at night. What am I?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="f";
	document.getElementById('bt').value="f";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="f";
	document.getElementById('dt').value="f";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="x";
	document.getElementById('gt').value="x";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="x";
	document.getElementById('it').value="x";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "frog";



	}
	
	
	
	
	
	
		
					
		function teques13()
{

	document.getElementById('questiont').innerHTML="When young, I am sweet in the sun. When middle-aged, I make you gay. When old, I am valued more than ever.";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="f";
	document.getElementById('bt').value="f";
	document.getElementById('ct').innerHTML="w";
	document.getElementById('ct').value="w";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="v";
	document.getElementById('et').value="v";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="x";
	document.getElementById('gt').value="x";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "wine";



	}
	
	
	
	
		
					
		function teques14()
{

	document.getElementById('questiont').innerHTML="All about, but cannot be seen, Can be captured, cannot be held, No throat, but can be heard.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="w";
	document.getElementById('ct').value="w";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="x";
	document.getElementById('gt').value="x";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "wind";



	}
	
	
	
	
		
					
		function teques15()
{

	document.getElementById('questiont').innerHTML="Each morning I appear to lie at your feet, All day I will follow no matter how fast you run, Yet I nearly perish in the midday sun.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="w";
	document.getElementById('bt').value="w";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="x";
	document.getElementById('gt').value="x";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="o";
	document.getElementById('it').value="o";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "shadow";



	}
	
	
	
		
					
		function teques16()
{

	document.getElementById('questiont').innerHTML="My life can be measured in hours, I serve by being devoured. Thin, I am quick Fat, I am slow Wind is my foe.";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "candle";



	}
	
	
	
	
		
					
		function teques17()
{

	document.getElementById('questiont').innerHTML="I am seen in the water if seen in the sky, I am in the rainbow, a jay’s feather,and lapis lazuli.";
	document.getElementById('at').innerHTML="u";
	document.getElementById('at').value="u";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "blue";



	}
	
	

	
						
		function teques18()
{

	document.getElementById('questiont').innerHTML="Glittering points that downward thrust, Sparkling spears that never rust.";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="c";
	document.getElementById('ct').value="c";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="c";
	document.getElementById('et').value="c";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "icicle";



	}
	
	

	
						
		function teques19()
{

	document.getElementById('questiont').innerHTML="At the sound of me, men may dream or stamp their feet, At the sound of me, women may laugh or sometimes weep.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="c";
	document.getElementById('ct').value="c";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="c";
	document.getElementById('et').value="c";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="u";
	document.getElementById('gt').value="u";
	document.getElementById('ht').innerHTML="m";
	document.getElementById('ht').value="m";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "music";



	}
	
	
	
						
		function teques20()
{

	document.getElementById('questiont').innerHTML="I build up castles. I tear down mountains. I make some men blind, I help others to see. What am I?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="n";
	document.getElementById('bt').value="n";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="f";
	document.getElementById('ht').value="f";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "sand";



	}
	
	
	
					
		function teques21()
{

	document.getElementById('questiont').innerHTML="It cannot be seen, it weighs nothing, but when put into a barrel, it makes it lighter. What is it?";
	document.getElementById('at').innerHTML="v";
	document.getElementById('at').value="v";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="x";
	document.getElementById('ht').value="x";
	document.getElementById('it').innerHTML="d";
	document.getElementById('it').value="d";
	document.getElementById('jt').innerHTML="k";
	document.getElementById('jt').value="k";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "hole";



	}
	
	
	
					
		function teques22()
{

	document.getElementById('questiont').innerHTML="What starts with a T, ends with a T, and has T in it?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="p";
	document.getElementById('ft').value="p";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="x";
	document.getElementById('ht').value="x";
	document.getElementById('it').innerHTML="d";
	document.getElementById('it').value="d";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "teapot";



	}
	
	
					
		function teques23()
{

	document.getElementById('questiont').innerHTML="You saw me where I never was and where I could not be. And yet within that very place, my face you often see. What am I?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="x";
	document.getElementById('ht').value="x";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "reflection";



	}
	
	
	
					
		function teques24()
{

	document.getElementById('questiont').innerHTML="Say my name and I disappear. What am I?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "silence";



	}
	
	
			function teques25()
{

	document.getElementById('questiont').innerHTML="Soft and fragile is my skin, I get my growth in mud I'm dangerous as much as pretty, for if not careful, I draw blood.";
	document.getElementById('at').innerHTML="h";
	document.getElementById('at').value="h";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="o";
	document.getElementById('it').value="o";
	document.getElementById('jt').innerHTML="h";
	document.getElementById('jt').value="h";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "thorn";



	}
	
	
	


		
			function teques26()
{

	document.getElementById('questiont').innerHTML="It is greater than God and more evil than the devil. The poor have it, the rich need it and if you eat it you'll die. What is it?";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="g";
	document.getElementById('bt').value="g";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "nothing";



	}
	
	


		
			function teques27()
{

	document.getElementById('questiont').innerHTML="What always runs but never walks, often murmurs, never talks, has a bed but never sleeps, has a mouth but never eats?";
	document.getElementById('at').innerHTML="v";
	document.getElementById('at').value="v";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="v";
	document.getElementById('dt').value="v";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "river";



	}
	
	

		
			function teques28()
{

	document.getElementById('questiont').innerHTML="I never was, am always to be. No one ever saw me, nor ever will. And yet I am the confidence of all, To live and breath on this terrestrial ball. What am I?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="u";
	document.getElementById('bt').value="u";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="f";
	document.getElementById('it').value="f";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "future";



	}
	
	

	
			function teques29()
{

	document.getElementById('questiont').innerHTML="I drive men mad For love of me, Easily beaten, Never free.";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="d";
	document.getElementById('ft').value="d";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "gold";



	}
	
	

	
			function teques30()
{

	document.getElementById('questiont').innerHTML="I am a box that holds keys without locks, yet they can unlock your soul. What am I?";
	document.getElementById('at').innerHTML="d";
	document.getElementById('at').value="d";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="d";
	document.getElementById('ft').value="d";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "piano";



	}
	
	
	
			function teques31()
{

	document.getElementById('questiont').innerHTML="What gets wetter as it dries?";
	document.getElementById('at').innerHTML="g";
	document.getElementById('at').value="g";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="f";
	document.getElementById('dt').value="f";
	document.getElementById('et').innerHTML="j";
	document.getElementById('et').value="j";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "towel";



	}
	
	
	
			function teques32()
{

	document.getElementById('questiont').innerHTML="I'm full of holes, yet I'm full of water. What am I?";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="p";
	document.getElementById('it').value="p";
	document.getElementById('jt').innerHTML="s";
	document.getElementById('jt').value="s";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "sponge";



	}
	
	


			function teques33()
{

	document.getElementById('questiont').innerHTML="It's red, blue, purple and green, no one can reach it, not even the queen. What is it?";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="b";
	document.getElementById('dt').value="b";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="d";
	document.getElementById('it').value="d";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "rainbow";



	}
	
	

			function teques34()
{

	document.getElementById('questiont').innerHTML="What has a neck and no head, two arms but no hands?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="y";
	document.getElementById('dt').value="y";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="m";
	document.getElementById('ft').value="m";
	document.getElementById('gt').innerHTML="t";
	document.getElementById('gt').value="t";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="h";
	document.getElementById('it').value="h";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "shirt";



	}
	
	

		function teques35()
{

	document.getElementById('questiont').innerHTML="I live in water If you cut my head I'm at your door, If you cut my tail I'm fruit, If you cut both I'm with you";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="h";
	document.getElementById('dt').value="h";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="p";
	document.getElementById('it').value="p";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "pearl";



	}
	
	

		function teques36()
{

	document.getElementById('questiont').innerHTML="What makes a loud noise when changing its jacket, becomes larger but weighs less?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="c";
	document.getElementById('bt').value="c";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="p";
	document.getElementById('it').value="p";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "popcorn";



	}
	
	
	
		function teques37()
{

	document.getElementById('questiont').innerHTML="I never was, am always to be, No one ever saw me, nor ever will And yet I am the confidence of all To live and breathe on this terrestrial ball.";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="p";
	document.getElementById('it').value="p";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "tomorrow";



	}
	
	
	
	
		function teques38()
{

	document.getElementById('questiont').innerHTML="Die without me, Never thank me. Walk right through me, never feel me. Always watching, never speaking. Always lurking, never seen.";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="g";
	document.getElementById('et').value="g";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="k";
	document.getElementById('ht').value="k";
	document.getElementById('it').innerHTML="x";
	document.getElementById('it').value="x";
	document.getElementById('jt').innerHTML="z";
	document.getElementById('jt').value="z";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "air";



	}
	
	
	
		function teques39()
{

	document.getElementById('questiont').innerHTML="Pregnant every time you see her, yet she will never give birth.";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "fullmoon";



	}
	
	
	
		function teques40()
{

	document.getElementById('questiont').innerHTML="I go around in circles, But always straight ahead Never complain, No matter where I am led.";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="w";
	document.getElementById('bt').value="w";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "wheel";



	}
	
	
		
		function teques10()
{

	document.getElementById('questiont').innerHTML="If dead, has a longer life. If alive, has a short life.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="w";
	document.getElementById('bt').value="w";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="c";
	document.getElementById('et').value="c";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="d";
	document.getElementById('it').value="d";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "candle";



	}
	
	
			
		function teques2()
{

	document.getElementById('questiont').innerHTML="I bought a servant whose rank is higher than mine.";
	document.getElementById('at').innerHTML="x";
	document.getElementById('at').value="x";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="m";
	document.getElementById('et').value="m";
	document.getElementById('ft').innerHTML="d";
	document.getElementById('ft').value="d";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "hat";



	}
	
	
				
		function teques3()
{

	document.getElementById('questiont').innerHTML="Has head, no hair, has stomach, no navel.";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="m";
	document.getElementById('gt').value="m";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="z";
	document.getElementById('jt').value="z";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "frog";



	}
	
	
					
		function teques4()
{

	document.getElementById('questiont').innerHTML="What goes up and down stairs without moving?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="c";
	document.getElementById('bt').value="c";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="u";
	document.getElementById('dt').value="u";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="p";
	document.getElementById('gt').value="p";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="r";
	document.getElementById('jt').value="r";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "carpet";



	}
	
	
						
		function teques5()
{

	document.getElementById('questiont').innerHTML="	What goes around the world and stays in a corner?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="p";
	document.getElementById('et').value="p";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="d";
	document.getElementById('gt').value="d";
	document.getElementById('ht').innerHTML="k";
	document.getElementById('ht').value="k";
	document.getElementById('it').innerHTML="h";
	document.getElementById('it').value="h";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "stamp";



	}
	
	
							
		function teques6()
{

	document.getElementById('questiont').innerHTML="The more there is, the less you see.";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="k";
	document.getElementById('ht').value="k";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "darkness";



	}
	
	
							
		function teques7()
{

	document.getElementById('questiont').innerHTML="I look at you, you look at me, I raise my right, you raise your left. What is this object?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="k";
	document.getElementById('bt').value="k";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "mirror";



	}
	
	
							
		function teques8()
{

	document.getElementById('questiont').innerHTML="What kind of room has no windows or doors?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "mushroom";



	}
	
	
								
		function teques9()
{

	document.getElementById('questiont').innerHTML="It has no top or bottom but it can hold flesh, bones, and blood all at the same time. What is this object?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="f";
	document.getElementById('et').value="f";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "ring";



	}
	
	
		
								
		function teques1()
{

	document.getElementById('questiont').innerHTML="Take off my skin, I won't cry, but you will. What am I?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="v";
	document.getElementById('it').value="v";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "onion";




	}
	
	
	
		
								
		function teques51()
{

	document.getElementById('questiont').innerHTML="I'm the son of water but when I return to water, I die Who am I?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="c";
	document.getElementById('bt').value="c";
	document.getElementById('ct').innerHTML="i";
	document.getElementById('ct').value="i";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="y";
	document.getElementById('et').value="y";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="x";
	document.getElementById('jt').value="x";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "ice";



	}
	
	
	
			
								
		function teques52()
{

	document.getElementById('questiont').innerHTML="I travel the world and I am drunk constantly. Who am I?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="i";
	document.getElementById('ct').value="i";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="g";
	document.getElementById('gt').value="g";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="x";
	document.getElementById('jt').value="x";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "water";



	}
	
	
	
		
	
			
								
		function teques53()
{

	document.getElementById('questiont').innerHTML="You answer me, although I never ask you questions. What am I?";
	document.getElementById('at').innerHTML="h";
	document.getElementById('at').value="h";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "telephone";



	}
	
	
	
				
								
		function teques54()
{

	document.getElementById('questiont').innerHTML="What has to be broken before it can be used?";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="i";
	document.getElementById('ct').value="i";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "egg";



	}
	
	
	
				
								
		function teques55()
{

	document.getElementById('questiont').innerHTML="If you have it, you want to share it. If you share it, you don't have it. What is it?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="k";
	document.getElementById('ct').value="k";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="x";
	document.getElementById('it').value="x";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "secret";



	}
	
	
	
		
				
								
		function teques56()
{

	document.getElementById('questiont').innerHTML="He has married many women but has never married. Who is he?";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="p";
	document.getElementById('ct').value="p";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "priest";



	}
	
	
	
	
				
								
		function teques57()
{

	document.getElementById('questiont').innerHTML="	The more you take the more you leave behind.";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "footstep";



	}
	
	
	
	
								
		function teques58()
{

	document.getElementById('questiont').innerHTML="What can run but never walks, has a mouth but never talks, has a head but never weeps, has a bed but never sleeps?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="v";
	document.getElementById('bt').value="v";
	document.getElementById('ct').innerHTML="j";
	document.getElementById('ct').value="j";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "river";



	}
	
	
	
	
								
		function teques59()
{

	document.getElementById('questiont').innerHTML="As I walked along the path I saw something with four fingers and one thumb, but it was not flesh, fish, bone, or fowl.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="v";
	document.getElementById('bt').value="v";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="d";
	document.getElementById('gt').value="d";
	document.getElementById('ht').innerHTML="k";
	document.getElementById('ht').value="k";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "gloves";



	}
	
	
	
	
								
		function teques60()
{

	document.getElementById('questiont').innerHTML="What can fill a room but takes up no space?";
	document.getElementById('at').innerHTML="m";
	document.getElementById('at').value="m";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "light";



	}
	
	
								
		function teques61()
{

	document.getElementById('questiont').innerHTML="What kind of dog keeps the best time?";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "watchdog";



	}
	
	
	
	
	
								
		function teques62()
{

	document.getElementById('questiont').innerHTML="What time of day, when written in capital letters, is the same forwards, backwards and upside down?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="z";
	document.getElementById('ct').value="z";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="x";
	document.getElementById('ft').value="x";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "noon";



	}
	
	
	
								
		function teques63()
{

	document.getElementById('questiont').innerHTML="A tasty reward given to well behaved dogs and kids.";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="x";
	document.getElementById('ft').value="x";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "treat";



	}
	
	
								
		function teques64()
{

	document.getElementById('questiont').innerHTML="A Caribbean shape that makes ships disappear.";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="i";
	document.getElementById('ct').value="i";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "triangle";



	}
	
	
	
	
								
		function teques65()
{

	document.getElementById('questiont').innerHTML="What has a face and two hands but no arms or legs?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="k";
	document.getElementById('bt').value="k";
	document.getElementById('ct').innerHTML="c";
	document.getElementById('ct').value="c";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="c";
	document.getElementById('jt').value="c";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "clock";



	}
	
	
	
		
				
								
		function teques66()
{

	document.getElementById('questiont').innerHTML="What five-letter word becomes shorter when you add two letters to it?";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "short";



	}
	
	
	
	
				
								
		function teques67()
{

	document.getElementById('questiont').innerHTML="What word begins and ends with an 'e' but only has one letter";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="v";
	document.getElementById('ft').value="v";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "envelope";



	}
	
	
	
	
								
		function teques68()
{

	document.getElementById('questiont').innerHTML=" What has a neck but no head?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="b";
	document.getElementById('bt').value="b";
	document.getElementById('ct').innerHTML="l";
	document.getElementById('ct').value="l";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "bottle";



	}
	
	
	
	
								
		function teques69()
{

	document.getElementById('questiont').innerHTML="What type of cheese is made backwards?";
	document.getElementById('at').innerHTML="m";
	document.getElementById('at').value="m";
	document.getElementById('bt').innerHTML="v";
	document.getElementById('bt').value="v";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="d";
	document.getElementById('gt').value="d";
	document.getElementById('ht').innerHTML="k";
	document.getElementById('ht').value="k";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "edam";



	}
	
	
	
	
								
		function teques70()
{

	document.getElementById('questiont').innerHTML="What gets wetter as it dries?";
	document.getElementById('at').innerHTML="w";
	document.getElementById('at').value="w";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "towel";



	}
	
	
	
	
								
		function teques71()
{

	document.getElementById('questiont').innerHTML="starts with a 'p', ends with an 'e' and has thousands of letters?";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="p";
	document.getElementById('dt').value="p";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="f";
	document.getElementById('ht').value="f";
	document.getElementById('it').innerHTML="f";
	document.getElementById('it').value="f";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "postoffice";



	}
	
	
	
	
	
								
		function teques72()
{

	document.getElementById('questiont').innerHTML="What has to be broken before you can eat it?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "egg";



	}
	
	
	
								
		function teques73()
{

	document.getElementById('questiont').innerHTML="What begins with T, ends with T and has T in it?";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="x";
	document.getElementById('ft').value="x";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "teapot";



	}
	
	
								
		function teques74()
{

	document.getElementById('questiont').innerHTML="What belongs to you but others use it more than you do?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="m";
	document.getElementById('ct').value="m";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "name";



	}
	
	
	
	
								
		function teques75()
{

	document.getElementById('questiont').innerHTML="The more you take away, the larger it becomes. What is it?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="k";
	document.getElementById('bt').value="k";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="h";
	document.getElementById('jt').value="h";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "hole";



	}
	
	
	
		
				
								
		function teques76()
{

	document.getElementById('questiont').innerHTML="Where do fish keep their money";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="k";
	document.getElementById('bt').value="k";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="v";
	document.getElementById('jt').value="v";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "riverbank";



	}
	
	
	
	
				
								
		function teques77()
{

	document.getElementById('questiont').innerHTML="What is it that you will break every time you name it?";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "silence";



	}
	
	
	
	
								
		function teques78()
{

	document.getElementById('questiont').innerHTML="What flies without wings?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="b";
	document.getElementById('bt').value="b";
	document.getElementById('ct').innerHTML="m";
	document.getElementById('ct').value="m";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "time";



	}
	
	
	
	
								
		function teques79()
{

	document.getElementById('questiont').innerHTML="What Kind of Fish chases a mouse?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="d";
	document.getElementById('gt').value="d";
	document.getElementById('ht').innerHTML="k";
	document.getElementById('ht').value="k";
	document.getElementById('it').innerHTML="h";
	document.getElementById('it').value="h";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "catfish";



	}
	
	
	
	
								
		function teques80()
{

	document.getElementById('questiont').innerHTML="What goes up and down without moving?";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "stairs";



	}
	
	
	
		
	
	
	
	
								
		function teques81()
{

	document.getElementById('questiont').innerHTML="I have a face, two arms, and two hands, yet I cannot move. I count to twelve, yet I cannot speak. I can still tell you something?";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="f";
	document.getElementById('ht').value="f";
	document.getElementById('it').innerHTML="f";
	document.getElementById('it').value="f";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "clock";



	}
	
	
	
	
	
								
		function teques82()
{

	document.getElementById('questiont').innerHTML="What is round on both ends and hi in the middle?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "ohio";



	}
	
	
	
								
		function teques83()
{

	document.getElementById('questiont').innerHTML="What do you call a dog that sweats so much?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="x";
	document.getElementById('ft').value="x";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "hotdog";



	}
	
	
								
		function teques84()
{

	document.getElementById('questiont').innerHTML="What rains at the north pole?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "reindeer";



	}
	
	
	
	
								
		function teques85()
{

	document.getElementById('questiont').innerHTML="What calls for help, when written in capital letters, is the same forwards, backwards and upside down?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="k";
	document.getElementById('bt').value="k";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="g";
	document.getElementById('it').value="g";
	document.getElementById('jt').innerHTML="h";
	document.getElementById('jt').value="h";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "sos";



	}
	
	
	
		
				
								
		function teques86()
{

	document.getElementById('questiont').innerHTML="Commits friendly home invasions one night a year";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="u";
	document.getElementById('gt').value="u";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="c";
	document.getElementById('jt').value="c";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "santaclaus";



	}
	
	
	
	
				
								
		function teques87()
{

	document.getElementById('questiont').innerHTML="Everyone claims to know a way to stop these involuntary contractions but none of them work";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="u";
	document.getElementById('bt').value="u";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="h";
	document.getElementById('it').value="h";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "hiccup";



	}
	
	
	
	
								
		function teques88()
{

	document.getElementById('questiont').innerHTML="One of the best things you can hope for after whacking a ball with a stick?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="u";
	document.getElementById('bt').value="u";
	document.getElementById('ct').innerHTML="m";
	document.getElementById('ct').value="m";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="h";
	document.getElementById('it').value="h";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "homerun";



	}
	
	
	
	
								
		function teques89()
{

	document.getElementById('questiont').innerHTML="They put the heat in pop tarts";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="d";
	document.getElementById('gt').value="d";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "toaster";



	}
	
	
	
	
								
		function teques90()
{

	document.getElementById('questiont').innerHTML="What has a ring, but no finger?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="p";
	document.getElementById('ct').value="p";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "telephone";



	}
	
	
	
	
	
	
		
	
	
	
	
								
		function teques91()
{

	document.getElementById('questiont').innerHTML="What has four legs, but can't walk?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="f";
	document.getElementById('ht').value="f";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "table";



	}
	
	
	
	
	
								
		function teques92()
{

	document.getElementById('questiont').innerHTML="What is higher without the head, than with it?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="w";
	document.getElementById('gt').value="w";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="p";
	document.getElementById('it').value="p";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "pillow";



	}
	
	
	
								
		function teques93()
{

	document.getElementById('questiont').innerHTML="What's harder to catch the faster you run?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "breath";



	}
	
	
								
		function teques94()
{

	document.getElementById('questiont').innerHTML="What invention lets you look right through a wall?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="w";
	document.getElementById('bt').value="w";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="w";
	document.getElementById('ft').value="w";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "window";



	}
	
	
	
	
								
		function teques95()
{

	document.getElementById('questiont').innerHTML="What is made of wood, but can't be sawed";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="d";
	document.getElementById('it').value="d";
	document.getElementById('jt').innerHTML="h";
	document.getElementById('jt').value="h";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "sawdust";



	}
	
	
	
		
				
								
		function teques96()
{

	document.getElementById('questiont').innerHTML="What is a witch's favorite school subject?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="u";
	document.getElementById('gt').value="u";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "spelling";



	}
	
	
	
	
				
								
		function teques97()
{

	document.getElementById('questiont').innerHTML="What is black and white and read all over?";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="p";
	document.getElementById('dt').value="p";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "newspaper";



	}
	
	
	
	
								
		function teques98()
{

	document.getElementById('questiont').innerHTML="Easy to get into, but hard to get out ";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="u";
	document.getElementById('bt').value="u";
	document.getElementById('ct').innerHTML="m";
	document.getElementById('ct').value="m";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="f";
	document.getElementById('ft').value="f";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "trouble";



	}
	
	
	
	
								
		function teques99()
{

	document.getElementById('questiont').innerHTML="What is as big as you are and yet does not weigh anything?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="a";
	document.getElementById('et').value="a";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="d";
	document.getElementById('gt').value="d";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "shadow";



	}
	
	
	
	
								
		function teques100()
{

	document.getElementById('questiont').innerHTML="When you have me, you feel like sharing me, but, if you do share me, you don't have me. ";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="p";
	document.getElementById('ct').value="p";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "secret";



	}
	
	
	
	
	
		
	
	
		
	
	
	
	
								
		function teques101()
{

	document.getElementById('questiont').innerHTML="It is an insect and the first part of it's name is the name of another insect. What is it?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "beetle";



	}
	
	
	
	
	
								
		function teques102()
{

	document.getElementById('questiont').innerHTML="What becomes white when it is dirty?";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="c";
	document.getElementById('ct').value="c";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "blackboard";



	}
	
	
	
								
		function teques103()
{

	document.getElementById('questiont').innerHTML="What word of five letters has only left when two letters are removed?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "stone";



	}
	
	
								
		function teques104()
{

	document.getElementById('questiont').innerHTML="Which vehicle is spelled the same forwards and backwards?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="n";
	document.getElementById('gt').value="n";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "racecar";



	}
	
	
	
	
								
		function teques105()
{

	document.getElementById('questiont').innerHTML="I am lighter than air but a million men cannot lift me up. What am I?";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="h";
	document.getElementById('jt').value="h";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "bubble";



	}
	
	
	
		
				
								
		function teques106()
{

	document.getElementById('questiont').innerHTML="It is everything to someone, and nothing to everyone else. What is it?";
	document.getElementById('at').innerHTML="d";
	document.getElementById('at').value="d";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="u";
	document.getElementById('gt').value="u";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "mind";



	}
	
	
	
	
				
								
		function teques107()
{

	document.getElementById('questiont').innerHTML="Forward I am heavy, backwards I am not. What am I?";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "not";



	}
	
	
	
	
								
		function teques108()
{

	document.getElementById('questiont').innerHTML="What object has keys that open no locks, space but no room, and you can enter but not go in?";
	document.getElementById('at').innerHTML="d";
	document.getElementById('at').value="d";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="y";
	document.getElementById('ft').value="y";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="k";
	document.getElementById('it').value="k";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "keyboard";



	}
	
	
	
	
								
		function teques109()
{

	document.getElementById('questiont').innerHTML="What bone has a sense of humor?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="u";
	document.getElementById('et').value="u";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="d";
	document.getElementById('gt').value="d";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="u";
	document.getElementById('it').value="u";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "humorous";



	}
	
	
	
	
								
		function teques110()
{

	document.getElementById('questiont').innerHTML="What turns everything around, but does not move?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "mirror";



	}
	
	
	
	
		
	
	
	
	
								
		function teques111()
{

	document.getElementById('questiont').innerHTML="What is half of two plus two?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "three";



	}
	
	
	
	
	
								
		function teques112()
{

	document.getElementById('questiont').innerHTML="What word looks the same upside down and backwards?";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="c";
	document.getElementById('ct').value="c";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="m";
	document.getElementById('gt').value="m";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "swims";



	}
	
	
	
								
		function teques113()
{

	document.getElementById('questiont').innerHTML="What’s the difference between here and there?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "t";



	}
	
	
								
		function teques114()
{

	document.getElementById('questiont').innerHTML="What sits in a corner while traveling all around the world?";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="m";
	document.getElementById('bt').value="m";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="t";
	document.getElementById('gt').value="t";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "stamp";



	}
	
	
	
	
								
		function teques115()
{

	document.getElementById('questiont').innerHTML=" What body part is pronounced as one letter but written three, only two different letters are used?";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="u";
	document.getElementById('dt').value="u";
	document.getElementById('et').innerHTML="y";
	document.getElementById('et').value="y";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "eye";



	}
	
	
	
		
				
								
		function teques116()
{

	document.getElementById('questiont').innerHTML="What keeps things green and keeps kids occupied in the summertime";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="k";
	document.getElementById('dt').value="k";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "sprinkler";



	}
	
	
	
	
				
								
		function teques117()
{

	document.getElementById('questiont').innerHTML="A shower that lights up the sky";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "meteor";



	}
	
	
	
	
								
		function teques118()
{

	document.getElementById('questiont').innerHTML="Longer than a decade and shorter than a millennium";
	document.getElementById('at').innerHTML="y";
	document.getElementById('at').value="y";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="u";
	document.getElementById('ct').value="u";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="c";
	document.getElementById('it').value="c";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "century";



	}
	
	
	
	
								
		function teques119()
{

	document.getElementById('questiont').innerHTML="I never was, am always to be. No one ever saw me, nor ever will. And yet I am the confidence of all, To live and breath on this terrestrial ball. What am I?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="u";
	document.getElementById('et').value="u";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="u";
	document.getElementById('it').value="u";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "future";



	}
	
	
	
	
								
		function teques120()
{

	document.getElementById('questiont').innerHTML="What has a head, a tail, and has no legs?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "coin";



	}
	
	
		
		
	
	
								
		function teques121()
{

	document.getElementById('questiont').innerHTML="Each morning I appear to lie at your feet, All day I will follow no matter how fast you run, Yet I nearly perish in the midday sun.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "shadow";



	}
	
	
	
	
	
								
		function teques122()
{

	document.getElementById('questiont').innerHTML="My life can be measured in hours, I serve by being devoured. Thin, I am quick Fat, I am slow Wind is my foe.";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="c";
	document.getElementById('ct').value="c";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="d";
	document.getElementById('gt').value="d";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "candle";



	}
	
	
	
								
		function teques123()
{

	document.getElementById('questiont').innerHTML="I am seen in the water if seen in the sky, I am in the rainbow.";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="b";
	document.getElementById('bt').value="b";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "blue";



	}
	
	
								
		function teques124()
{

	document.getElementById('questiont').innerHTML="Three lives have I. Gentle enough to soothe the skin, Light enough to caress the sky, Hard enough to crack rocks.";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="c";
	document.getElementById('ft').value="c";
	document.getElementById('gt').innerHTML="t";
	document.getElementById('gt').value="t";
	document.getElementById('ht').innerHTML="w";
	document.getElementById('ht').value="w";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="r";
	document.getElementById('jt').value="r";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "water";



	}
	
	
	
	
								
		function teques125()
{

	document.getElementById('questiont').innerHTML="Two in a corner, 1 in a room, 0 in a house, but 1 in a shelter. What am I?";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="u";
	document.getElementById('dt').value="u";
	document.getElementById('et').innerHTML="y";
	document.getElementById('et').value="y";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "r";



	}
	
	
	
		
				
								
		function teques126()
{

	document.getElementById('questiont').innerHTML="It cannot be seen, it weighs nothing, but when put into a barrel, it makes it lighter. What is it?";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="k";
	document.getElementById('dt').value="k";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "hole";



	}
	
	
	
	
				
								
		function teques127()
{

	document.getElementById('questiont').innerHTML="I can be long, or I can be short. I can be grown, and I can be bought. I can be painted, or left bare. I can be round, or square. What am I?";
	document.getElementById('at').innerHTML="t";
	document.getElementById('at').value="t";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="l";
	document.getElementById('jt').value="l";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "nail";



	}
	
	
	
	
								
		function teques128()
{

	document.getElementById('questiont').innerHTML="Soft and fragile is my skin, I get my growth in mud I'm dangerous as much as pretty, for if not careful, I draw blood.";
	document.getElementById('at').innerHTML="y";
	document.getElementById('at').value="y";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="u";
	document.getElementById('ct').value="u";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "thorn";



	}
	
	
	
	
								
		function teques129()
{

	document.getElementById('questiont').innerHTML="My first is twice in apple but not once in tart. My second is in liver but not in heart. My third is in giant and also in ghost. Whole I'm best when I am roast. What am I?";
	document.getElementById('at').innerHTML="g";
	document.getElementById('at').value="g";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="p";
	document.getElementById('et').value="p";
	document.getElementById('ft').innerHTML="s";
	document.getElementById('ft').value="s";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="u";
	document.getElementById('it').value="u";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "pig";



	}
	
	
	
	
								
		function teques130()
{

	document.getElementById('questiont').innerHTML="A mile from end to end, yet as close to as a friend. A precious commodity, freely given. What is it?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "smile";



	}
	
	
		
			
	
	
								
		function teques131()
{

	document.getElementById('questiont').innerHTML="Alive without breath, As cold as death, Never thirsty, Ever drinking, Drowns on dry land.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="f";
	document.getElementById('ct').value="f";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "fish";



	}
	
	
	
	
	
								
		function teques132()
{

	document.getElementById('questiont').innerHTML="Die without me, Never thank me. Walk right through me, never feel me. Always watching, never speaking. Always lurking, never seen.";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="c";
	document.getElementById('ct').value="c";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "air";



	}
	
	
	
								
		function teques133()
{

	document.getElementById('questiont').innerHTML="Take one out and scratch my head, I am now black but once was red.";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="m";
	document.getElementById('et').value="m";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "match";



	}
	
	
								
		function teques134()
{

	document.getElementById('questiont').innerHTML="Only two backbones and thousands of ribs.";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="w";
	document.getElementById('ht').value="w";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="l";
	document.getElementById('jt').value="l";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "railroad";



	}
	
	
	
	
								
		function teques135()
{

	document.getElementById('questiont').innerHTML="Big as a biscuit, deep as a cup, Even a river can't fill it up. What is it?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "strainer";



	}
	
	
	
		
				
								
		function teques136()
{

	document.getElementById('questiont').innerHTML="It is greater than God and more evil than the devil. The poor have it, the rich need it and if you eat it you'll die. What is it?";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="n";
	document.getElementById('bt').value="n";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="o";
	document.getElementById('it').value="o";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "nothing";



	}
	
	
	
	
				
								
		function teques137()
{

	document.getElementById('questiont').innerHTML="I am always hungry, I must always be fed,The finger I touch, Will soon turn red.";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="f";
	document.getElementById('jt').value="f";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "fire";



	}
	
	
	
	
								
		function teques138()
{

	document.getElementById('questiont').innerHTML="All about, but cannot be seen, Can be captured, cannot be held, No throat, but can be heard.";
	document.getElementById('at').innerHTML="d";
	document.getElementById('at').value="d";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="u";
	document.getElementById('ct').value="u";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "wind";



	}
	
	
	
	
								
		function teques139()
{

	document.getElementById('questiont').innerHTML="How far will a blind dog walk into a forest?";
	document.getElementById('at').innerHTML="y";
	document.getElementById('at').value="y";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="w";
	document.getElementById('ct').value="w";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="p";
	document.getElementById('et').value="p";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "halfway";



	}
	
	
	
	
								
		function teques140()
{

	document.getElementById('questiont').innerHTML="I am, in truth, a yellow fork from tables in the sky, The apparatus of the dark to ignorance revealed.";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="g";
	document.getElementById('gt').value="g";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "lightning";



	}
	
	
		
	
								
		function teques141()
{

	document.getElementById('questiont').innerHTML="Pedro hides but you can still see his head.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="f";
	document.getElementById('ct').value="f";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="b";
	document.getElementById('it').value="b";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "nail";



	}
	
	
	
	
	
								
		function teques142()
{

	document.getElementById('questiont').innerHTML="Riddle me, riddle me, here comes a roaring chain";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "train";



	}
	
	
	
								
		function teques143()
{

	document.getElementById('questiont').innerHTML="Here comes Kaka, walking with an open leg.";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="s";
	document.getElementById('jt').value="s";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "scissor";



	}
	
	
								
		function teques144()
{

	document.getElementById('questiont').innerHTML="Adam's hair, you can't count.";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="w";
	document.getElementById('ht').value="w";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "rain";



	}
	
	
	
	
								
		function teques145()
{

	document.getElementById('questiont').innerHTML="Rice cake of the king, that you cannot divide.";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="w";
	document.getElementById('et').value="w";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "water";



	}
	
	
	
		
				
								
		function teques146()
{

	document.getElementById('questiont').innerHTML="Cute hares that hop and deliver eggs at Easter are called by this nickname.";
	document.getElementById('at').innerHTML="y";
	document.getElementById('at').value="y";
	document.getElementById('bt').innerHTML="n";
	document.getElementById('bt').value="n";
	document.getElementById('ct').innerHTML="n";
	document.getElementById('ct').value="n";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="o";
	document.getElementById('it').value="o";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "bunny";



	}
	
	
	
	
				
								
		function teques147()
{

	document.getElementById('questiont').innerHTML="This monkey food makes people slip and fall in cartoons.";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="b";
	document.getElementById('dt').value="b";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "banana";



	}
	
	
	
	
								
		function teques148()
{

	document.getElementById('questiont').innerHTML="Owned by Old McDonald.";
	document.getElementById('at').innerHTML="d";
	document.getElementById('at').value="d";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="f";
	document.getElementById('ct').value="f";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="w";
	document.getElementById('jt').value="w";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "farm";



	}
	
	
	
	
								
		function teques149()
{

	document.getElementById('questiont').innerHTML="Poorly behaved children often find themselves sitting in these.";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="r";
	document.getElementById('jt').value="r";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "corners";



	}
	
	
	
	
								
		function teques150()
{

	document.getElementById('questiont').innerHTML="It keeps things green and keeps the kids occupied in the summertime.";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="p";
	document.getElementById('ct').value="p";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "sprinkler";



	}
	
	
		
	
	
	
	
	
								
		function teques151()
{

	document.getElementById('questiont').innerHTML="If a dog were filling out a resume, he might list his mastery of this game under “skills.";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="f";
	document.getElementById('ct').value="f";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "fetch";



	}
	
	
	
	
	
								
		function teques152()
{

	document.getElementById('questiont').innerHTML="Sleep-inducing melody";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="u";
	document.getElementById('it').value="u";
	document.getElementById('jt').innerHTML="y";
	document.getElementById('jt').value="y";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "lullaby";



	}
	
	
	
								
		function teques153()
{

	document.getElementById('questiont').innerHTML="He crushed on Wendy Darling.";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "peterpan";



	}
	
	
								
		function teques154()
{

	document.getElementById('questiont').innerHTML="This guy crossed a road and everyone wants an explanation";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="w";
	document.getElementById('ht').value="w";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "chicken";



	}
	
	
	
	
								
		function teques155()
{

	document.getElementById('questiont').innerHTML="A twiggy home";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="w";
	document.getElementById('et').value="w";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "nest";



	}
	
	
	
		
				
								
		function teques156()
{

	document.getElementById('questiont').innerHTML="Very helpful if you intend to go gently down a stream";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="w";
	document.getElementById('bt').value="w";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="b";
	document.getElementById('ft').value="b";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="o";
	document.getElementById('it').value="o";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "rowboat";



	}
	
	
	
	
				
								
		function teques157()
{

	document.getElementById('questiont').innerHTML="A storage facility for criminals and fire-breathing reptiles.";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="u";
	document.getElementById('ct').value="u";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "dungeon";



	}
	
	
	
	
								
		function teques158()
{

	document.getElementById('questiont').innerHTML="Casper was a friendly one and Demi Moore made a clay pot with one.";
	document.getElementById('at').innerHTML="h";
	document.getElementById('at').value="h";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="f";
	document.getElementById('ct').value="f";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="g";
	document.getElementById('gt').value="g";
	document.getElementById('ht').innerHTML="i";
	document.getElementById('ht').value="i";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "ghost";



	}
	
	
	
	
								
		function teques159()
{

	document.getElementById('questiont').innerHTML="Where everyone wants to run home and stealing is encouraged.";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="b";
	document.getElementById('gt').value="b";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "baseball";



	}
	
	
	
	
								
		function teques160()
{

	document.getElementById('questiont').innerHTML="Special abilities and brightly colored underwear are all you need to be one of these.";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="p";
	document.getElementById('ct').value="p";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "superhero";



	}
	
	
	
		
								
		function teques161()
{

	document.getElementById('questiont').innerHTML="Consuming food would be pretty tough without these chompers.";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "teeth";



	}
	
	
	
	
	
								
		function teques162()
{

	document.getElementById('questiont').innerHTML="A shower that lights up the sky";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "meteor";



	}
	
	
	
								
		function teques163()
{

	document.getElementById('questiont').innerHTML="If you blow past your destination, you’ll have to throw your car into this.";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="v";
	document.getElementById('it').value="v";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "reverse";



	}
	
	
								
		function teques164()
{

	document.getElementById('questiont').innerHTML="The state of holding a person in your person";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="g";
	document.getElementById('et').value="g";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "pregnant";



	}
	
	
	
	
								
		function teques165()
{

	document.getElementById('questiont').innerHTML="Between daylight and darkness when sparkling blood suckers like to come out";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="w";
	document.getElementById('et').value="w";
	document.getElementById('ft').innerHTML="h";
	document.getElementById('ft').value="h";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "twilight";



	}
	
	
	
		
				
								
		function teques166()
{

	document.getElementById('questiont').innerHTML="Longer than a decade and shorter than a millennium";
	document.getElementById('at').innerHTML="y";
	document.getElementById('at').value="y";
	document.getElementById('bt').innerHTML="c";
	document.getElementById('bt').value="c";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="u";
	document.getElementById('ft').value="u";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "century";



	}
	
	
	
	
				
								
		function teques167()
{

	document.getElementById('questiont').innerHTML="Fuels backyard get-togethers.";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="c";
	document.getElementById('bt').value="c";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "charcoal";



	}
	
	
	
	
								
		function teques168()
{

	document.getElementById('questiont').innerHTML="Only you can prevent forest fires.";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="f";
	document.getElementById('ct').value="f";
	document.getElementById('dt').innerHTML="k";
	document.getElementById('dt').value="k";
	document.getElementById('et').innerHTML="y";
	document.getElementById('et').value="y";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="g";
	document.getElementById('gt').value="g";
	document.getElementById('ht').innerHTML="m";
	document.getElementById('ht').value="m";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "smokey";



	}
	
	
	
	
								
		function teques169()
{

	document.getElementById('questiont').innerHTML="A defendant will go free if a reasonable amount of this exists.";
	document.getElementById('at').innerHTML="u";
	document.getElementById('at').value="u";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="d";
	document.getElementById('dt').value="d";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="b";
	document.getElementById('gt').value="b";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "doubt";



	}
	
	
	
	
								
		function teques170()
{

	document.getElementById('questiont').innerHTML="Godzilla calls this place home";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="p";
	document.getElementById('ct').value="p";
	document.getElementById('dt').innerHTML="j";
	document.getElementById('dt').value="j";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "japan";



	}
	
	
	
		
	
	
	
	
	
		
								
		function teques171()
{

	document.getElementById('questiont').innerHTML="This would be a good place to find Can-Can girls and drunk Cowboys.";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "saloon";



	}
	
	
	
	
	
								
		function teques172()
{

	document.getElementById('questiont').innerHTML="Santa’s reindeer make this noise.";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="i";
	document.getElementById('ct').value="i";
	document.getElementById('dt').innerHTML="l";
	document.getElementById('dt').value="l";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="j";
	document.getElementById('ft').value="j";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="l";
	document.getElementById('jt').value="l";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "jingle";



	}
	
	
	
								
		function teques173()
{

	document.getElementById('questiont').innerHTML="He prefers to travel on vines and pal around with gorillas.";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="z";
	document.getElementById('ct').value="z";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="v";
	document.getElementById('it').value="v";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "tarzan";



	}
	
	
								
		function teques174()
{

	document.getElementById('questiont').innerHTML="Angels and pilots earn these.";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="w";
	document.getElementById('ct').value="w";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="g";
	document.getElementById('et').value="g";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "wing";



	}
	
	
	
	
								
		function teques175()
{

	document.getElementById('questiont').innerHTML="What becomes wetter the more it dries?";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="w";
	document.getElementById('et').value="w";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "towel";



	}
	
	
	
		
				
								
		function teques176()
{

	document.getElementById('questiont').innerHTML="What is so fragile, even saying its name can break it?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="c";
	document.getElementById('bt').value="c";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="u";
	document.getElementById('ft').value="u";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="c";
	document.getElementById('jt').value="c";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "silence";



	}
	
	
	
	
				
								
		function teques177()
{

	document.getElementById('questiont').innerHTML="What can run but never walks, often murmurs, never talks, has a mouth but never eats, has a bed but never sleeps?";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="v";
	document.getElementById('ht').value="v";
	document.getElementById('it').innerHTML="l";
	document.getElementById('it').value="l";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "river";



	}
	
	
	
	
								
		function teques178()
{

	document.getElementById('questiont').innerHTML="Anyone can hold me, even without their hands, yet no one can do it for long. What am I?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="f";
	document.getElementById('ct').value="f";
	document.getElementById('dt').innerHTML="h";
	document.getElementById('dt').value="h";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="g";
	document.getElementById('gt').value="g";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="b";
	document.getElementById('jt').value="b";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "breath";



	}
	
	
	
	
								
		function teques179()
{

	document.getElementById('questiont').innerHTML="I have a hundred eyes, yet cannot see. What am I?";
	document.getElementById('at').innerHTML="u";
	document.getElementById('at').value="u";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="d";
	document.getElementById('dt').value="d";
	document.getElementById('et').innerHTML="b";
	document.getElementById('et').value="b";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="t";
	document.getElementById('gt').value="t";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "potato";



	}
	
	
	
	
								
		function teques180()
{

	document.getElementById('questiont').innerHTML="I am invisible, weigh nothing, and if you put me in a barrel, it will become lighter. What am I?";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="l";
	document.getElementById('ct').value="l";
	document.getElementById('dt').innerHTML="j";
	document.getElementById('dt').value="j";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "hole";



	}
	
	
	
	
	
	
	
	
	
	
		
								
		function teques181()
{

	document.getElementById('questiont').innerHTML="I am always there, some distance away, somewhere between land and sky I lay, you may move toward me, yet distant I'll stay. What am I?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="i";
	document.getElementById('gt').value="i";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="z";
	document.getElementById('it').value="z";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "horizon";



	}
	
	
	
	
	
								
		function teques182()
{

	document.getElementById('questiont').innerHTML="What has four fingers and a thumb, but is not made of flesh, fish, bone, or fowl?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="i";
	document.getElementById('ct').value="i";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="j";
	document.getElementById('ft').value="j";
	document.getElementById('gt').innerHTML="v";
	document.getElementById('gt').value="v";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="l";
	document.getElementById('jt').value="l";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "glove";



	}
	
	
	
								
		function teques183()
{

	document.getElementById('questiont').innerHTML="The man who made it doesn't want it. The man who bought it doesn't need it. The man who needs it doesn't know it. What is it?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="z";
	document.getElementById('ct').value="z";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "coffin";



	}
	
	
								
		function teques184()
{

	document.getElementById('questiont').innerHTML="What can go around the world, yet stays in a corner?";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="w";
	document.getElementById('ct').value="w";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="g";
	document.getElementById('et').value="g";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="m";
	document.getElementById('ht').value="m";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "stamp";



	}
	
	
	
	
								
		function teques185()
{

	document.getElementById('questiont').innerHTML="I am not alive, yet I grow; I have no lungs, yet I need air; I have no mouth, yet I can drown. What am I?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="w";
	document.getElementById('et').value="w";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "fire";



	}
	
	
	
		
				
								
		function teques186()
{

	document.getElementById('questiont').innerHTML="Throw me off the highest building, and I shall not break, but toss me in the smallest pool, and my life's at stake. What am I?";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="u";
	document.getElementById('bt').value="u";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="u";
	document.getElementById('ft').value="u";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="c";
	document.getElementById('jt').value="c";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "tissue";



	}
	
	
	
	
				
								
		function teques187()
{

	document.getElementById('questiont').innerHTML="For what crime can an offender be arrested for attempting, but not committing?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="v";
	document.getElementById('ht').value="v";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "suicide";



	}
	
	
	
	
								
		function teques188()
{

	document.getElementById('questiont').innerHTML="What can you always count on when trying to solve math problems?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="n";
	document.getElementById('bt').value="n";
	document.getElementById('ct').innerHTML="f";
	document.getElementById('ct').value="f";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="g";
	document.getElementById('gt').value="g";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="b";
	document.getElementById('jt').value="b";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "fingers";



	}
	
	
	
	
								
		function teques189()
{

	document.getElementById('questiont').innerHTML="The rich want it, and the poor have it; it is greater than God, but worse than Satan; and if you eat it you will die. What is it?";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="h";
	document.getElementById('et').value="h";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="t";
	document.getElementById('gt').value="t";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "nothing";



	}
	
	
	
	
								
		function teques190()
{

	document.getElementById('questiont').innerHTML="If you have me, you want to share me. If you share me, I no longer exist. What am I?";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="s";
	document.getElementById('bt').value="s";
	document.getElementById('ct').innerHTML="l";
	document.getElementById('ct').value="l";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="t";
	document.getElementById('gt').value="t";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "secret";



	}
	
	
	
	
	
	
		
								
		function teques191()
{

	document.getElementById('questiont').innerHTML="Before Mount Everest was discovered, what was the tallest mountain in the world?";
	document.getElementById('at').innerHTML="v";
	document.getElementById('at').value="v";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="z";
	document.getElementById('it').value="z";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "everest";



	}
	
	
	
	
	
								
		function teques192()
{

	document.getElementById('questiont').innerHTML="If a plane crashed on the border between the US and Mexico, where would the survivors be buried?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="j";
	document.getElementById('ft').value="j";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "nowhere";



	}
	
	
	
								
		function teques193()
{

	document.getElementById('questiont').innerHTML="A man living in the UK cannot be buried in America because he is?";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="z";
	document.getElementById('ct').value="z";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="t";
	document.getElementById('et').value="t";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="v";
	document.getElementById('gt').value="v";
	document.getElementById('ht').innerHTML="n";
	document.getElementById('ht').value="n";
	document.getElementById('it').innerHTML="i";
	document.getElementById('it').value="i";
	document.getElementById('jt').innerHTML="g";
	document.getElementById('jt').value="g";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "living";



	}
	
	
								
		function teques194()
{

	document.getElementById('questiont').innerHTML="What has been around for millions of years, but is never more than a month old?";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="g";
	document.getElementById('et').value="g";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="m";
	document.getElementById('ht').value="m";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "moon";



	}
	
	
	
	
								
		function teques195()
{

	document.getElementById('questiont').innerHTML="What belongs to you, but is used mostly by others?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="w";
	document.getElementById('et').value="w";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="m";
	document.getElementById('ht').value="m";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "name";



	}
	
	
	
		
				
								
		function teques196()
{

	document.getElementById('questiont').innerHTML="Here there is no north or west or east, and the weather, it is fitting for no man or bird or beast.";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="p";
	document.getElementById('gt').value="p";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "north pole";



	}
	
	
	
	
				
								
		function teques197()
{

	document.getElementById('questiont').innerHTML="What goes up but never comes down?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="a";
	document.getElementById('gt').value="a";
	document.getElementById('ht').innerHTML="v";
	document.getElementById('ht').value="v";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "age";



	}
	
	
	
	
								
		function teques198()
{

	document.getElementById('questiont').innerHTML="The more there is, the less you see. What is it?";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "darkness";



	}
	
	
	
	
								
		function teques199()
{

	document.getElementById('questiont').innerHTML="What can go up and come down without moving?";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="v";
	document.getElementById('bt').value="v";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="u";
	document.getElementById('et').value="u";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "volume";



	}
	
	
	
	
								
		function teques200()
{

	document.getElementById('questiont').innerHTML="What turns everything around without moving?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="l";
	document.getElementById('ct').value="l";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="o";
	document.getElementById('ht').value="o";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "mirror";



	}
	
	
	
	
	
	
	
	
	
		
								
		function teques201()
{

	document.getElementById('questiont').innerHTML="What two things can always see what the other sees, but can never see each other?";
	document.getElementById('at').innerHTML="v";
	document.getElementById('at').value="v";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="z";
	document.getElementById('it').value="z";
	document.getElementById('jt').innerHTML="y";
	document.getElementById('jt').value="y";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "eyes";



	}
	
	
	
	
	
								
		function teques202()
{

	document.getElementById('questiont').innerHTML="What type of building has the most stories?";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="y";
	document.getElementById('it').value="y";
	document.getElementById('jt').innerHTML="l";
	document.getElementById('jt').value="l";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "library";



	}
	
	
	
								
		function teques203()
{

	document.getElementById('questiont').innerHTML="Always coming but never arrives";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="w";
	document.getElementById('ht').value="w";
	document.getElementById('it').innerHTML="o";
	document.getElementById('it').value="o";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "tomorrow";



	}
	
	
								
		function teques204()
{

	document.getElementById('questiont').innerHTML="Look at me one way and I weigh a whole lot. Turn me around and you’ll see that I am not. ";
	document.getElementById('at').innerHTML="o";
	document.getElementById('at').value="o";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="g";
	document.getElementById('et').value="g";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="m";
	document.getElementById('ht').value="m";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "ton";



	}
	
	
	
	
								
		function teques205()
{

	document.getElementById('questiont').innerHTML="Pedro hides but you can still see his head.";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="w";
	document.getElementById('et').value="w";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="f";
	document.getElementById('gt').value="f";
	document.getElementById('ht').innerHTML="m";
	document.getElementById('ht').value="m";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "nail";



	}
	
	
	
		
				
								
		function teques206()
{

	document.getElementById('questiont').innerHTML="Riddle me, riddle me, here comes a roaring chain";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="p";
	document.getElementById('gt').value="p";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "train";



	}
	
	
	
	
				
								
		function teques207()
{

	document.getElementById('questiont').innerHTML="Here comes Kaka, walking with an open leg.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "scissors";



	}
	
	
	
	
								
		function teques208()
{

	document.getElementById('questiont').innerHTML="Adam's hair, you can't count.";
	document.getElementById('at').innerHTML="k";
	document.getElementById('at').value="k";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "rain";



	}
	
	
	
	
								
		function teques209()
{

	document.getElementById('questiont').innerHTML="Rice cake of the king, that you cannot divide.";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="v";
	document.getElementById('bt').value="v";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="u";
	document.getElementById('et').value="u";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "water";



	}
	
	
	
	
								
		function teques210()
{

	document.getElementById('questiont').innerHTML="Roll in the morning, leaf in the afternoon.";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="l";
	document.getElementById('ct').value="l";
	document.getElementById('dt').innerHTML="m";
	document.getElementById('dt').value="m";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="r";
	document.getElementById('it').value="r";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "mat";



	}
	
	
	
	
	
	
		
								
		function teques211()
{

	document.getElementById('questiont').innerHTML="It has one entrance, but has three exit.";
	document.getElementById('at').innerHTML="v";
	document.getElementById('at').value="v";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="z";
	document.getElementById('it').value="z";
	document.getElementById('jt').innerHTML="d";
	document.getElementById('jt').value="d";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "dress";



	}
	
	
	
	
	
								
		function teques212()
{

	document.getElementById('questiont').innerHTML="Big Square Bag of Mr Jacob, to use it you have to turn it upside down.";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="a";
	document.getElementById('dt').value="a";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="g";
	document.getElementById('ht').value="g";
	document.getElementById('it').innerHTML="y";
	document.getElementById('it').value="y";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "net";



	}
	
	
	
								
		function teques213()
{

	document.getElementById('questiont').innerHTML="Two birds, trying to balance in one twig.";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="n";
	document.getElementById('bt').value="n";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="t";
	document.getElementById('dt').value="t";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "earrings";



	}
	
	
								
		function teques214()
{

	document.getElementById('questiont').innerHTML="It's here it's here, but you cannot see";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="g";
	document.getElementById('et').value="g";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "wind";



	}
	
	
	
	
								
		function teques215()
{

	document.getElementById('questiont').innerHTML="My cow in Manila, you can hear his moo.";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="r";
	document.getElementById('ct').value="r";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="w";
	document.getElementById('et').value="w";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="u";
	document.getElementById('ht').value="u";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "thunder";



	}
	
	
	
		
				
								
		function teques216()
{

	document.getElementById('questiont').innerHTML="General Negro pass by and eveybody die.";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="t";
	document.getElementById('ct').value="t";
	document.getElementById('dt').innerHTML="g";
	document.getElementById('dt').value="g";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="p";
	document.getElementById('gt').value="p";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="i";
	document.getElementById('jt').value="i";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "night";



	}
	
	
	
	
				
								
		function teques217()
{

	document.getElementById('questiont').innerHTML="I have a friend and he is with me everywhere I go.";
	document.getElementById('at').innerHTML="w";
	document.getElementById('at').value="w";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="i";
	document.getElementById('et').value="i";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "shadow";



	}
	
	
	
	
								
		function teques218()
{

	document.getElementById('questiont').innerHTML="I have a pet, his body is full of coins.";
	document.getElementById('at').innerHTML="y";
	document.getElementById('at').value="y";
	document.getElementById('bt').innerHTML="r";
	document.getElementById('bt').value="r";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="x";
	document.getElementById('dt').value="x";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="b";
	document.getElementById('ht').value="b";
	document.getElementById('it').innerHTML="o";
	document.getElementById('it').value="o";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "moneybox";



	}
	
	
	
	
								
		function teques219()
{

	document.getElementById('questiont').innerHTML="I can't see it in the light but I can see it in the dark.";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="v";
	document.getElementById('bt').value="v";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="u";
	document.getElementById('et').value="u";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="t";
	document.getElementById('jt').value="t";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "star";



	}
	
	
	
	
								
		function teques220()
{

	document.getElementById('questiont').innerHTML="Maria's skirt, in different colors.";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="l";
	document.getElementById('ct').value="l";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="o";
	document.getElementById('jt').value="o";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "rainbow";



	}
	
	
	
	
	
	
	
	
	
		
								
		function teques221()
{

	document.getElementById('questiont').innerHTML="One plate, can be seen around the world.";
	document.getElementById('at').innerHTML="v";
	document.getElementById('at').value="v";
	document.getElementById('bt').innerHTML="o";
	document.getElementById('bt').value="o";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="m";
	document.getElementById('jt').value="m";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "moon";



	}
	
	
	
	
	
								
		function teques222()
{

	document.getElementById('questiont').innerHTML="House of the Lieutenant ,with only one post.";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="e";
	document.getElementById('bt').value="e";
	document.getElementById('ct').innerHTML="m";
	document.getElementById('ct').value="m";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="y";
	document.getElementById('it').value="y";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "umbrella";



	}
	
	
	
								
		function teques223()
{

	document.getElementById('questiont').innerHTML="A princess sitting in a cup.";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="s";
	document.getElementById('dt').value="s";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "cashew";



	}
	
	
								
		function teques224()
{

	document.getElementById('questiont').innerHTML="Shape like a heart, gold in color, sweet to smell and good to eat.";
	document.getElementById('at').innerHTML="m";
	document.getElementById('at').value="m";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="g";
	document.getElementById('et').value="g";
	document.getElementById('ft').innerHTML="n";
	document.getElementById('ft').value="n";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "mango";



	}
	
	
	
	
								
		function teques225()
{

	document.getElementById('questiont').innerHTML="Seed that is wrap in steel, steel that is wrap in crystal.";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="z";
	document.getElementById('dt').value="z";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="h";
	document.getElementById('gt').value="h";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="n";
	document.getElementById('it').value="n";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "lanzones";



	}
	
	
	
		
				
								
		function teques226()
{

	document.getElementById('questiont').innerHTML="What fruit in the world that the seed is out?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="h";
	document.getElementById('bt').value="h";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="p";
	document.getElementById('gt').value="p";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="c";
	document.getElementById('jt').value="c";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "cashew";



	}
	
	
	
	
				
								
		function teques227()
{

	document.getElementById('questiont').innerHTML="Here comes Ingkong, sitting in a fish catcher.";
	document.getElementById('at').innerHTML="w";
	document.getElementById('at').value="w";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="c";
	document.getElementById('jt').value="c";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "cashew";



	}
	
	
	
	
								
		function teques228()
{

	document.getElementById('questiont').innerHTML="The princess is on her back, but her head is still facing us.";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="p";
	document.getElementById('dt').value="p";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="r";
	document.getElementById('gt').value="r";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="s";
	document.getElementById('jt').value="s";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "starapple";



	}
	
	
	
	
								
		function teques229()
{

	document.getElementById('questiont').innerHTML="Her skin is green, her seed is black, her tissue is red, who is she?";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="m";
	document.getElementById('it').value="m";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "watermelon";



	}
	
	
	
	
								
		function teques230()
{

	document.getElementById('questiont').innerHTML="House of Pedro, full of stone.";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="p";
	document.getElementById('ct').value="p";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="y";
	document.getElementById('gt').value="y";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="p";
	document.getElementById('it').value="p";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "papaya";



	}
	
	
	
	
	
	
	
	
	
		
								
		function teques231()
{

	document.getElementById('questiont').innerHTML="An island of pig with a hair as hard as a nail.";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="u";
	document.getElementById('et').value="u";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="k";
	document.getElementById('gt').value="k";
	document.getElementById('ht').innerHTML="c";
	document.getElementById('ht').value="c";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="j";
	document.getElementById('jt').value="j";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "jackfruit";



	}
	
	
	
	
	
								
		function teques232()
{

	document.getElementById('questiont').innerHTML="The virgin gave birth, but throw the nappy.";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="n";
	document.getElementById('bt').value="n";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="y";
	document.getElementById('it').value="y";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "banana";



	}
	
	
	
								
		function teques233()
{

	document.getElementById('questiont').innerHTML="The queen tilt her head but the crown did not fall.";
	document.getElementById('at').innerHTML="g";
	document.getElementById('at').value="g";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="u";
	document.getElementById('dt').value="u";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="v";
	document.getElementById('jt').value="v";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "guava";



	}
	
	
								
		function teques234()
{

	document.getElementById('questiont').innerHTML="There is a sky, there is soil, there is water, but no fish.";
	document.getElementById('at').innerHTML="u";
	document.getElementById('at').value="u";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="c";
	document.getElementById('et').value="c";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="d";
	document.getElementById('ht').value="d";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "coconut";



	}
	
	
	
	
								
		function teques235()
{

	document.getElementById('questiont').innerHTML="Not a princess, not a queen, but wears a crown.";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="o";
	document.getElementById('ct').value="o";
	document.getElementById('dt').innerHTML="z";
	document.getElementById('dt').value="z";
	document.getElementById('et').innerHTML="s";
	document.getElementById('et').value="s";
	document.getElementById('ft').innerHTML="v";
	document.getElementById('ft').value="v";
	document.getElementById('gt').innerHTML="g";
	document.getElementById('gt').value="g";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "guava";



	}
	
	
	
		
				
								
		function teques236()
{

	document.getElementById('questiont').innerHTML="A beautiful girl, you can't count her eyes.";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="p";
	document.getElementById('gt').value="p";
	document.getElementById('ht').innerHTML="s";
	document.getElementById('ht').value="s";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "pineapple";



	}
	
	
	
	
				
								
		function teques237()
{

	document.getElementById('questiont').innerHTML="Flavors your food and divides the year up.";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="c";
	document.getElementById('jt').value="c";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "season";



	}
	
	
	
	
								
		function teques238()
{

	document.getElementById('questiont').innerHTML="This creature travels in a gaggle.";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="g";
	document.getElementById('bt').value="g";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="s";
	document.getElementById('jt').value="s";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "goose";



	}
	
	
	
	
								
		function teques239()
{

	document.getElementById('questiont').innerHTML="Nature’s way of applauding a lightning strike.";
	document.getElementById('at').innerHTML="e";
	document.getElementById('at').value="e";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="d";
	document.getElementById('et').value="d";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="u";
	document.getElementById('gt').value="u";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="h";
	document.getElementById('it').value="h";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "thunder";



	}
	
	
	
	
								
		function teques240()
{

	document.getElementById('questiont').innerHTML="These help engines spin and trousers stay up.";
	document.getElementById('at').innerHTML="b";
	document.getElementById('at').value="b";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="y";
	document.getElementById('gt').value="y";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="p";
	document.getElementById('it').value="p";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "belt";



	}
	
	
	
	
			
								
		function teques241()
{

	document.getElementById('questiont').innerHTML="Throw me off the highest building, and I shall not break, but toss me in the smallest pool, and my life's at stake.";
	document.getElementById('at').innerHTML="f";
	document.getElementById('at').value="f";
	document.getElementById('bt').innerHTML="i";
	document.getElementById('bt').value="i";
	document.getElementById('ct').innerHTML="s";
	document.getElementById('ct').value="s";
	document.getElementById('dt').innerHTML="r";
	document.getElementById('dt').value="r";
	document.getElementById('et').innerHTML="u";
	document.getElementById('et').value="u";
	document.getElementById('ft').innerHTML="t";
	document.getElementById('ft').value="t";
	document.getElementById('gt').innerHTML="k";
	document.getElementById('gt').value="k";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="j";
	document.getElementById('jt').value="j";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "tissue";



	}
	
	
	
	
	
								
		function teques242()
{

	document.getElementById('questiont').innerHTML="A word I know, six letters it contains, subtract one, and twelve remains.";
	document.getElementById('at').innerHTML="s";
	document.getElementById('at').value="s";
	document.getElementById('bt').innerHTML="n";
	document.getElementById('bt').value="n";
	document.getElementById('ct').innerHTML="d";
	document.getElementById('ct').value="d";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="n";
	document.getElementById('et').value="n";
	document.getElementById('ft').innerHTML="a";
	document.getElementById('ft').value="a";
	document.getElementById('gt').innerHTML="l";
	document.getElementById('gt').value="l";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="z";
	document.getElementById('it').value="z";
	document.getElementById('jt').innerHTML="u";
	document.getElementById('jt').value="u";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "dozens";



	}
	
	
	
								
		function teques243()
{

	document.getElementById('questiont').innerHTML="What cannot talk, but will always respond when spoken to?";
	document.getElementById('at').innerHTML="c";
	document.getElementById('at').value="c";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="h";
	document.getElementById('ct').value="h";
	document.getElementById('dt').innerHTML="u";
	document.getElementById('dt').value="u";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="g";
	document.getElementById('ft').value="g";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="w";
	document.getElementById('it').value="w";
	document.getElementById('jt').innerHTML="e";
	document.getElementById('jt').value="e";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "echo";



	}
	
	
								
		function teques244()
{

	document.getElementById('questiont').innerHTML="What is always too late?";
	document.getElementById('at').innerHTML="r";
	document.getElementById('at').value="r";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="g";
	document.getElementById('ct').value="g";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="c";
	document.getElementById('et').value="c";
	document.getElementById('ft').innerHTML="e";
	document.getElementById('ft').value="e";
	document.getElementById('gt').innerHTML="e";
	document.getElementById('gt').value="e";
	document.getElementById('ht').innerHTML="r";
	document.getElementById('ht').value="r";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "regret";



	}
	
	
	
	
								
		function teques245()
{

	document.getElementById('questiont').innerHTML="Ligaya's house, full of eyes";
	document.getElementById('at').innerHTML="a";
	document.getElementById('at').value="a";
	document.getElementById('bt').innerHTML="p";
	document.getElementById('bt').value="p";
	document.getElementById('ct').innerHTML="i";
	document.getElementById('ct').value="i";
	document.getElementById('dt').innerHTML="n";
	document.getElementById('dt').value="n";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="p";
	document.getElementById('ft').value="p";
	document.getElementById('gt').innerHTML="g";
	document.getElementById('gt').value="g";
	document.getElementById('ht').innerHTML="l";
	document.getElementById('ht').value="l";
	document.getElementById('it').innerHTML="e";
	document.getElementById('it').value="e";
	document.getElementById('jt').innerHTML="p";
	document.getElementById('jt').value="p";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "pineapple";



	}
	
	
	
		
				
								
		function teques246()
{

	document.getElementById('questiont').innerHTML="Opens without mouth, smiles silently.";
	document.getElementById('at').innerHTML="p";
	document.getElementById('at').value="p";
	document.getElementById('bt').innerHTML="l";
	document.getElementById('bt').value="l";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="e";
	document.getElementById('dt').value="e";
	document.getElementById('et').innerHTML="f";
	document.getElementById('et').value="f";
	document.getElementById('ft').innerHTML="i";
	document.getElementById('ft').value="i";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="w";
	document.getElementById('ht').value="w";
	document.getElementById('it').innerHTML="a";
	document.getElementById('it').value="a";
	document.getElementById('jt').innerHTML="r";
	document.getElementById('jt').value="r";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "flower";



	}
	
	
	
	
				
								
		function teques247()
{

	document.getElementById('questiont').innerHTML="Kill him to save him.";
	document.getElementById('at').innerHTML="n";
	document.getElementById('at').value="n";
	document.getElementById('bt').innerHTML="d";
	document.getElementById('bt').value="d";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="c";
	document.getElementById('dt').value="c";
	document.getElementById('et').innerHTML="e";
	document.getElementById('et').value="e";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="s";
	document.getElementById('gt').value="s";
	document.getElementById('ht').innerHTML="h";
	document.getElementById('ht').value="h";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="c";
	document.getElementById('jt').value="c";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "candle";



	}
	
	
	
	
								
		function teques248()
{

	document.getElementById('questiont').innerHTML="Can cook without heat, smoking without cold.";
	document.getElementById('at').innerHTML="i";
	document.getElementById('at').value="i";
	document.getElementById('bt').innerHTML="g";
	document.getElementById('bt').value="g";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="o";
	document.getElementById('dt').value="o";
	document.getElementById('et').innerHTML="l";
	document.getElementById('et').value="l";
	document.getElementById('ft').innerHTML="o";
	document.getElementById('ft').value="o";
	document.getElementById('gt').innerHTML="c";
	document.getElementById('gt').value="c";
	document.getElementById('ht').innerHTML="a";
	document.getElementById('ht').value="a";
	document.getElementById('it').innerHTML="t";
	document.getElementById('it').value="t";
	document.getElementById('jt').innerHTML="s";
	document.getElementById('jt').value="s";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "ice";



	}
	
	
	
	
								
		function teques249()
{

	document.getElementById('questiont').innerHTML="Throw me and I'll be back.";
	document.getElementById('at').innerHTML="y";
	document.getElementById('at').value="y";
	document.getElementById('bt').innerHTML="t";
	document.getElementById('bt').value="t";
	document.getElementById('ct').innerHTML="a";
	document.getElementById('ct').value="a";
	document.getElementById('dt').innerHTML="w";
	document.getElementById('dt').value="w";
	document.getElementById('et').innerHTML="o";
	document.getElementById('et').value="o";
	document.getElementById('ft').innerHTML="r";
	document.getElementById('ft').value="r";
	document.getElementById('gt').innerHTML="o";
	document.getElementById('gt').value="o";
	document.getElementById('ht').innerHTML="e";
	document.getElementById('ht').value="e";
	document.getElementById('it').innerHTML="y";
	document.getElementById('it').value="y";
	document.getElementById('jt').innerHTML="n";
	document.getElementById('jt').value="n";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "yoyo";



	}
	
	
	
	
								
		function teques250()
{

	document.getElementById('questiont').innerHTML="Water into stone, stone into water.";
	document.getElementById('at').innerHTML="l";
	document.getElementById('at').value="l";
	document.getElementById('bt').innerHTML="a";
	document.getElementById('bt').value="a";
	document.getElementById('ct').innerHTML="e";
	document.getElementById('ct').value="e";
	document.getElementById('dt').innerHTML="i";
	document.getElementById('dt').value="i";
	document.getElementById('et').innerHTML="r";
	document.getElementById('et').value="r";
	document.getElementById('ft').innerHTML="l";
	document.getElementById('ft').value="l";
	document.getElementById('gt').innerHTML="y";
	document.getElementById('gt').value="y";
	document.getElementById('ht').innerHTML="t";
	document.getElementById('ht').value="t";
	document.getElementById('it').innerHTML="s";
	document.getElementById('it').value="s";
	document.getElementById('jt').innerHTML="a";
	document.getElementById('jt').value="a";	
	document.getElementById("numerot").innerHTML = "riddle no: " + numbt;

right_anst = "salt";



	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function submitt()
{



if(sagott==right_anst)
{
scoret++;
numbt++;
	
alert("You are Correct!!!");

document.getElementById("scoret").innerHTML = "score: " + scoret;
document.getElementById("anst").innerHTML = "";



pt++;
sagott = "";

if(numbt>250)
{
document.getElementById("submitt").href = "#twinner_e_u";

document.getElementById("tfscore_e_u").innerHTML = "score: " + scoret;
}

else{
tstart_e_u();}
}
else
{


alert("You are Wrong!!!");

document.getElementById("scoret").innerHTML = "score: " + scoret;
document.getElementById("anst").innerHTML = "";

if(lifet == 0)
{

document.getElementById("submitt").href = "#texit_e_u";

document.getElementById("tgfscoret_e_u").innerHTML = "score: " + scoret;

}


else{
numbt++;

pt++;

sagott = "";



if(numbt>250)
{
document.getElementById("submitt").href = "#twinner_e_u";

document.getElementById("tfscore_e_u").innerHTML = "score: " + scoret;
}


tstart_e_u();
}

}

changeColor4();
}





function times()
{
document.getElementById('lifet').innerHTML=m+":"+s+" remaining";
s--;
q=setTimeout("times()", 1000);
if (s<0)
{ m=m-1; s=59;}

if (m<0)
{
timesstop();
}
}
function timesstop()
{
clearTimeout(q);
s=0;
m=0;
document.getElementById('lifet').innerHTML=" ";
right_anst = "" ;
sagott = "";

$("#try1,#questiont,#anst,#at,#bt,#ct,#dt,#et,#ft,#gt,#ht,#it,#jt").hide();
		$("#submitt,#resett").hide();

		document.getElementById('tgfscore_e_u').innerHTML="score: " + scoret;

	$("#gameover").show();
	
}


	
	function balik()
{
$("#try1,#questiont,#anst,#at,#bt,#ct,#dt,#et,#ft,#gt,#ht,#it,#jt").show();
		$("#submitt,#resett").show();

	$("#gameover").hide();
$("#try1").show();

	
document.getElementById('tgfscore_e_u').innerHTML="score: " + scoret;
	

}




function tgokay_e_u()
{

pt = 1 ;
anst = "" ;
sagott = "";
right_anst = "" ;
scoret = 0;
numbt = 1;
s = 59;
m = 9;	





}


var mp = 1 ;
var mans = "" ;
var msagot = "";
var mright_ans = "" ;
var mlife = 3;
var mscore = 0;
var mnumb = 1;
var let_num3 = "";





function bura3()
{
var dine = msagot.length - 1;

msagot = msagot.substring(0,dine);
document.getElementById("mans").innerHTML = msagot;

var dindin = let_num3.length - 1;
var pj = let_num3.charAt(dindin);
if(pj == "a")
{$("#ma").show(200);
let_num3 = let_num3.substring(0,dindin);
}
else if(pj == "b")
{$("#mb").show(200);
let_num3 = let_num3.substring(0,dindin);}
else if(pj == "c")
{$("#mc").show(200);
let_num3 = let_num3.substring(0,dindin);}
else if(pj == "d")
{$("#md").show(200);
let_num3 = let_num3.substring(0,dindin);}
else if(pj == "e")
{$("#me").show(200);
let_num3 = let_num3.substring(0,dindin);}
else if(pj == "f")
{$("#mf").show(200);
let_num3 = let_num3.substring(0,dindin);}
else if(pj == "g")
{$("#mg").show(200);
let_num3 = let_num3.substring(0,dindin);}
else if(pj == "h")
{$("#mh").show(200);
let_num3 = let_num3.substring(0,dindin);}
else if(pj == "i")
{$("#mi").show(200);
let_num3 = let_num3.substring(0,dindin);}
else if(pj == "j")
{$("#mj").show(200);
let_num3 = let_num3.substring(0,dindin);}




}























function homing3()
{
  var x;
    if (confirm("You want to quit?") == true) {
 document.getElementById("3home_b").href =  "#page1";
  } else {
 document.getElementById("3home_b").href =  "";
    }
}










$(document).ready(function(){
$("#ma").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#mb").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#mc").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#md").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#me").click(function(){
$(this).hide(200);
});
});








$(document).ready(function(){
$("#mf").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#mg").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#mh").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#mi").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#mj").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#mreset").click(function(){
$("#ma,#mc,#mb,#md,#me,#mg,#mf,#mh,#mi,#mj").show(200);
});
});


$(document).ready(function(){
$("#msubmit").click(function(){
$("#ma,#mc,#mb,#md,#me,#mg,#mf,#mh,#mi,#mj").show(200);
});
});







$(document).ready(function(){
$("#mhint").click(function(){
$(this).hide();
$("#f_mhint").show();
});
});


$(document).ready(function(){
$("#mhint2").click(function(){
$(this).hide();
$("#f_mhint2").show();
});
});


$(document).ready(function(){
$("#mhint3").click(function(){
$(this).hide();
$("#f_mhint3").show();
});
});


function mhint()
{

var hinto = mright_ans.length;

$("#mdito").show(500);

document.getElementById("mdito").innerHTML =  "consist of " + hinto + " Letters";

}




function mhint2()
{

var hinto = mright_ans.charAt(0);

$("#mdito").show(500);

document.getElementById("mdito").innerHTML =  "starts with letter: " + hinto;

}


function mhint3()
{
var x = mright_ans.length - 1;
var hinto = mright_ans.charAt(x);

$("#mdito").show(500);

document.getElementById("mdito").innerHTML =  "ends with letter: " + hinto;

}










function gokay_m_u()
{
var mp = 1 ;
var mans = "" ;
var msagot = "";
var mright_ans = "" ;
var mlife = 3;
var mscore = 0;
var mnumb = 1;


}




function cokay_m_u()
{
var mp = 1 ;
var mans = "" ;
var msagot = "";
var mright_ans = "" ;
var mlife = 3;
var mscore = 0;
var mnumb = 1;


}

function start_m_u()
{

var random = Math.floor(Math.random()*2);
if(random==0){random++;}




if(mp==1)
	{
		
	mques1();

	}
	else if(mp==2)
	{
		
	mques2();

	}
	else if(mp==3)
		
	{
	mques3();

	}

	else if(mp==4)
		
	{
	mques4();

	}
	else if(mp==5)
		
	{
	mques5();

	}

	else if(mp==6)
		
	{
	mques6();

	}
	else if(mp==7)
		
	{
	mques7();

	}
	else if(mp==8)
		
	{
	mques8();

	}
	else if(mp==9)
		
	{
	mques9();

	}
	else if(mp==10)
		
	{
	mques10();

	}




	else if(mp==11)
	{
		
	mques11();

	}
	else if(mp==12)
	{
		
	mques12();

	}
	else if(mp==13)
		
	{
	mques13();

	}

	else if(mp==14)
		
	{
	mques14();

	}
	else if(mp==15)
		
	{
	mques15();

	}

	else if(mp==16)
		
	{
	mques16();

	}
	else if(mp==17)
		
	{
	mques17();

	}
	else if(mp==18)
		
	{
	mques18();

	}
	else if(mp==19)
		
	{
	mques19();

	}
	else if(mp==20)
		
	{
	mques20();

	}

	

	else if(mp==21)
	{
		
	mques21();

	}
	else if(mp==22)
	{
		
	mques22();

	}
	else if(mp==23)
		
	{
	mques23();

	}

	else if(mp==24)
		
	{
	mques24();

	}
	else if(mp==25)
		
	{
	mques25();

	}

	else if(mp==26)
		
	{
	mques26();

	}
	else if(mp==27)
		
	{
	mques27();

	}
	else if(mp==28)
		
	{
	mques28();

	}
	else if(mp==29)
		
	{
	mques29();

	}
	else if(mp==30)
		
	{
	mques30();

	}



	else if(mp==31)
	{
		
	mques31();

	}
	else if(mp==32)
	{
		
	mques32();

	}
	else if(mp==33)
		
	{
	mques33();

	}

	else if(mp==34)
		
	{
	mques34();

	}
	else if(mp==35)
		
	{
	mques35();

	}

	else if(mp==36)
		
	{
	mques36();

	}
	else if(mp==37)
		
	{
	mques37();

	}
	else if(mp==38)
		
	{
	mques38();

	}
	else if(mp==39)
		
	{
	mques39();

	}
	else if(mp==40)
		
	{
	mques40();

	}




	else if(mp==41)
	{
		
	mques41();

	}
	else if(mp==42)
	{
		
	mques42();

	}
	else if(mp==43)
		
	{
	mques43();

	}

	else if(mp==44)
		
	{
	mques44();

	}
	else if(mp==45)
		
	{
	mques45();

	}

	else if(mp==46)
		
	{
	mques46();

	}
	else if(mp==47)
		
	{
	mques47();

	}
	else if(mp==48)
		
	{
	mques48();

	}
	else if(mp==49)
		
	{
	mques49();

	}
	else if(mp==50)
		
	{
	mques50();

	}

		
	else if(mp==51)
	{
		
	mques51();

	}
	else if(mp==52)
	{
		
	mques52();

	}
	else if(mp==53)
		
	{
	mques53();

	}

	else if(mp==54)
		
	{
	mques54();

	}
	else if(mp==55)
		
	{
	mques55();

	}

	else if(mp==56)
		
	{
	mques56();

	}
	else if(mp==57)
		
	{
	mques57();

	}
	else if(mp==58)
		
	{
	mques58();

	}
	else if(mp==59)
		
	{
	mques59();

	}
	else if(mp==60)
		
	{
	mques60();

	}
	
	
	else if(mp==61)
	{
		
	mques61();

	}
	else if(mp==62)
	{
		
	mques62();

	}
	else if(mp==63)
		
	{
	mques63();

	}

	else if(mp==64)
		
	{
	mques64();

	}
	else if(mp==65)
		
	{
	mques65();

	}

	else if(mp==66)
		
	{
	mques66();

	}
	else if(mp==67)
		
	{
	mques67();

	}
	else if(mp==68)
		
	{
	mques68();

	}
	else if(mp==69)
		
	{
	mques69();

	}
	else if(mp==70)
		
	{
	mques70();

	}
	
	
	else if(mp==71)
	{
		
	mques71();

	}
	else if(mp==72)
	{
		
	mques72();

	}
	else if(mp==73)
		
	{
	mques73();

	}

	else if(mp==74)
		
	{
	mques74();

	}
	else if(mp==75)
		
	{
	mques75();

	}

	else if(mp==76)
		
	{
	mques76();

	}
	else if(mp==77)
		
	{
	mques77();

	}
	else if(mp==78)
		
	{
	mques78();

	}
	else if(mp==79)
		
	{
	mques79();

	}
	else if(mp==80)
		
	{
	mques80();

	}
	
	
	else if(mp==81)
	{
		
	mques81();

	}
	else if(mp==82)
	{
		
	mques82();

	}
	else if(mp==83)
		
	{
	mques83();

	}

	else if(mp==84)
		
	{
	mques84();

	}
	else if(mp==85)
		
	{
	mques85();

	}

	else if(mp==86)
		
	{
	mques86();

	}
	else if(mp==87)
		
	{
	mques87();

	}
	else if(mp==88)
		
	{
	mques88();

	}
	else if(mp==89)
		
	{
	mques89();

	}
	else if(mp==90)
		
	{
	mques90();

	}
	
	
	
	
	else if(mp==91)
	{
		
	mques91();

	}
	else if(mp==92)
	{
		
	mques92();

	}
	else if(mp==93)
		
	{
	mques93();

	}

	else if(mp==94)
		
	{
	mques94();

	}
	else if(mp==95)
		
	{
	mques95();

	}

	else if(mp==96)
		
	{
	mques96();

	}
	else if(mp==97)
		
	{
	mques97();

	}
	else if(mp==98)
		
	{
	mques98();

	}
	else if(mp==99)
		
	{
	mques99();

	}
	else if(mp==100)
		
	{
	mques100();

	}
	
	
	

	else if(mp==101)
	{
		
	mques101();

	}
	else if(mp==102)
	{
		
	mques102();

	}
	else if(mp==103)
		
	{
	mques103();

	}

	else if(mp==104)
		
	{
	mques104();

	}
	else if(mp==105)
		
	{
	mques105();

	}

	else if(mp==106)
		
	{
	mques106();

	}
	else if(mp==107)
		
	{
	mques107();

	}
	else if(mp==108)
		
	{
	mques108();

	}
	else if(mp==109)
		
	{
	mques109();

	}
	else if(mp==110)
		
	{
	mques110();

	}

	

	else if(mp==111)
	{
		
	mques111();

	}
	else if(mp==112)
	{
		
	mques112();

	}
	else if(mp==113)
		
	{
	mques113();

	}

	else if(mp==114)
		
	{
	mques114();

	}
	else if(mp==115)
		
	{
	mques115();

	}

	else if(mp==116)
		
	{
	mques116();

	}
	else if(mp==117)
		
	{
	mques117();

	}
	else if(mp==118)
		
	{
	mques118();

	}
	else if(mp==119)
		
	{
	mques119();

	}
	else if(mp==120)
		
	{
	mques120();

	}

	else if(mp==121)
	{
		
	mques121();

	}
	else if(mp==122)
	{
		
	mques122();

	}
	else if(mp==123)
		
	{
	mques123();

	}

	else if(mp==124)
		
	{
	mques124();

	}
	else if(mp==125)
		
	{
	mques125();

	}

	else if(mp==126)
		
	{
	mques126();

	}
	else if(mp==127)
		
	{
	mques127();

	}
	else if(mp==128)
		
	{
	mques128();

	}
	else if(mp==129)
		
	{
	mques129();

	}
	else if(mp==130)
		
	{
	mques130();

	}
	
	
	else if(mp==131)
	{
		
	mques131();

	}
	else if(mp==132)
	{
		
	mques132();

	}
	else if(mp==133)
		
	{
	mques133();

	}

	else if(mp==134)
		
	{
	mques134();

	}
	else if(mp==135)
		
	{
	mques135();

	}

	else if(mp==136)
		
	{
	mques136();

	}
	else if(mp==137)
		
	{
	mques137();

	}
	else if(mp==138)
		
	{
	mques138();

	}
	else if(mp==139)
		
	{
	mques139();

	}
	else if(mp==140)
		
	{
	mques140();

	}
	
	
	
	else if(mp==141)
	{
		
	mques141();

	}
	else if(mp==142)
	{
		
	mques142();

	}
	else if(mp==143)
		
	{
	mques143();

	}

	else if(mp==144)
		
	{
	mques144();

	}
	else if(mp==145)
		
	{
	mques145();

	}

	else if(mp==146)
		
	{
	mques146();

	}
	else if(mp==147)
		
	{
	mques147();

	}
	else if(mp==148)
		
	{
	mques148();

	}
	else if(mp==149)
		
	{
	mques149();

	}
	else if(mp==150)
		
	{
	mques150();

	}
	
	
	
	
	
	else if(mp==151)
	{
		
	mques151();

	}
	else if(mp==152)
	{
		
	mques152();

	}
	else if(mp==153)
		
	{
	mques153();

	}

	else if(mp==154)
		
	{
	mques154();

	}
	else if(mp==155)
		
	{
	mques155();

	}

	else if(mp==156)
		
	{
	mques156();

	}
	else if(mp==157)
		
	{
	mques157();

	}
	else if(mp==158)
		
	{
	mques158();

	}
	else if(mp==159)
		
	{
	mques159();

	}
	else if(mp==160)
		
	{
	mques160();

	}
	
	
	else if(mp==161)
	{
		
	mques161();

	}
	else if(mp==162)
	{
		
	mques162();

	}
	else if(mp==163)
		
	{
	mques163();

	}

	else if(mp==164)
		
	{
	mques164();

	}
	else if(mp==165)
		
	{
	mques165();

	}

	else if(mp==166)
		
	{
	mques166();

	}
	else if(mp==167)
		
	{
	mques167();

	}
	else if(mp==168)
		
	{
	mques168();

	}
	else if(mp==169)
		
	{
	mques169();

	}
	else if(mp==170)
		
	{
	mques170();

	}
	
	
	else if(mp==171)
	{
		
	mques171();

	}
	else if(mp==172)
	{
		
	mques172();

	}
	else if(mp==173)
		
	{
	mques173();

	}

	else if(mp==174)
		
	{
	mques174();

	}
	else if(mp==175)
		
	{
	mques175();

	}

	else if(mp==176)
		
	{
	mques176();

	}
	else if(mp==177)
		
	{
	mques177();

	}
	else if(mp==178)
		
	{
	mques178();

	}
	else if(mp==179)
		
	{
	mques179();

	}
	else if(mp==180)
		
	{
	mques180();

	}
	
	
	else if(mp==181)
	{
		
	mques181();

	}
	else if(mp==182)
	{
		
	mques182();

	}
	else if(mp==183)
		
	{
	mques183();

	}

	else if(mp==184)
		
	{
	mques184();

	}
	else if(mp==185)
		
	{
	mques185();

	}

	else if(mp==186)
		
	{
	mques186();

	}
	else if(mp==187)
		
	{
	mques187();

	}
	else if(mp==188)
		
	{
	mques188();

	}
	else if(mp==189)
		
	{
	mques189();

	}
	else if(mp==190)
		
	{
	mques190();

	}
	
	
	
	
	else if(mp==191)
	{
		
	mques191();

	}
	else if(mp==192)
	{
		
	mques192();

	}
	else if(mp==193)
		
	{
	mques193();

	}

	else if(mp==194)
		
	{
	mques194();

	}
	else if(mp==195)
		
	{
	mques195();

	}

	else if(mp==196)
		
	{
	mques196();

	}
	else if(mp==197)
		
	{
	mques197();

	}
	else if(mp==198)
		
	{
	mques198();

	}
	else if(mp==199)
		
	{
	mques199();

	}
	else if(mp==200)
		
	{
	mques200();

	}
	
	
	
	
	else if(mp==201)
	{
		
	mques201();

	}
	
	else if(mp==202)
	{
		
	mques202();

	}
	else if(mp==203)
		
	{
	mques203();

	}

	else if(mp==204)
		
	{
	mques204();

	}
	else if(mp==205)
		
	{
	mques205();

	}

	else if(mp==206)
		
	{
	mques206();

	}
	else if(mp==207)
		
	{
	mques207();

	}
	else if(mp==208)
		
	{
	mques208();

	}
	else if(mp==209)
		
	{
	mques209();

	}
	else if(mp==210)
		
	{
	mques210();

	}


	else if(mp==211)
	{
		
	mques211();

	}
	else if(mp==212)
	{
		
	mques212();

	}
	else if(mp==213)
		
	{
	mques213();

	}

	else if(mp==214)
		
	{
	mques214();

	}
	else if(mp==215)
		
	{
	mques215();

	}

	else if(mp==216)
		
	{
	mques216();

	}
	else if(mp==217)
		
	{
	mques217();

	}
	else if(mp==218)
		
	{
	mques218();

	}
	else if(mp==219)
		
	{
	mques219();

	}
	else if(mp==220)
		
	{
	mques220();

	}

	
	else if(mp==221)
	{
		
	mques221();

	}
	else if(mp==222)
	{
		
	mques222();

	}
	else if(mp==223)
		
	{
	mques223();

	}

	else if(mp==224)
		
	{
	mques224();

	}
	else if(mp==225)
		
	{
	mques225();

	}

	else if(mp==226)
		
	{
	mques226();

	}
	else if(mp==227)
		
	{
	mques227();

	}
	else if(mp==228)
		
	{
	mques228();

	}
	else if(mp==229)
		
	{
	mques229();

	}
	else if(mp==230)
		
	{
	mques230();

	}

	
	else if(mp==231)
	{
		
	mques231();

	}
	else if(mp==232)
	{
		
	mques232();

	}
	else if(mp==233)
		
	{
	mques233();

	}

	else if(mp==234)
		
	{
	mques234();

	}
	else if(mp==235)
		
	{
	mques235();

	}

	else if(mp==236)
		
	{
	mques236();

	}
	else if(mp==237)
		
	{
	mques237();

	}
	else if(mp==238)
		
	{
	mques238();

	}
	else if(mp==239)
		
	{
	mques239();

	}
	else if(mp==240)
		
	{
	mques240();

	}


	else if(mp==241)
	{
		
	mques241();

	}
	else if(mp==242)
	{
		
	mques242();

	}
	else if(mp==243)
		
	{
	mques243();

	}

	else if(mp==244)
		
	{
	mques244();

	}
	else if(mp==245)
		
	{
	mques245();

	}

	else if(mp==246)
		
	{
	mques246();

	}
	else if(mp==247)
		
	{
	mques247();

	}
	else if(mp==248)
		
	{
	mques248();

	}
	else if(mp==249)
		
	{
	mques249();

	}
	else if(mp==250)
		
	{
	mques250();

	}

	
	
















	
	
}







	
	
function ma()
{


var a = document.getElementById("ma").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "a";
}


	
function mb()
{


var a = document.getElementById("mb").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "b";
}



function mc()
{


var a = document.getElementById("mc").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "c";
}





function md()
{


var a = document.getElementById("md").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "d";
}



function me()
{

var a = document.getElementById("me").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "e";
}



function mf()
{

var a = document.getElementById("mf").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "f";
}

function mg()
{

var a = document.getElementById("mg").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "g";
}

function mh()
{

var a = document.getElementById("mh").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "h";
}

function mi()
{

var a = document.getElementById("mi").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "i";
}

function mj()
{

var a = document.getElementById("mj").value;

msagot = msagot + a;

document.getElementById("mans").innerHTML = msagot;
let_num3 = let_num3 + "j";
}




function mreset()
{


msagot = "";

document.getElementById("mans").innerHTML = msagot;
}




function mques40()
{

	document.getElementById('mquestion').innerHTML="Heto na si kuya, May sunong sa baga.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="p";
	document.getElementById('mg').value="p";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "alitaptap";




	}

	
	
	
function mques6()
{

	document.getElementById('mquestion').innerHTML="Feed me and I live, give me drink and I die. What am I?";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="f";
	document.getElementById('md').value="f";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="d";
	document.getElementById('mf').value="d";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="g";
	document.getElementById('mh').value="g";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "fire";




	}

	
	
	
	
	
	
function mques44()
{

	document.getElementById('mquestion').innerHTML="Ako'y may kaibigan, Kasama ko kahit saan, Mapatubig ay di nalulunod, Mapaapoy ay di nasusunog.";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="m";
	document.getElementById('md').value="m";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="d";
	document.getElementById('mf').value="d";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="m";
	document.getElementById('mh').value="m";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "anino";




	}

	
	
	
	
	
function mques2()
{

	document.getElementById('mquestion').innerHTML="At night it comes without being fetched. By day it is lost without being stolen. What is it?";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="m";
	document.getElementById('md').value="m";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "star";




	}

	
			
		function mques48()
{

	document.getElementById('mquestion').innerHTML="Hindi hayop, hindi tao, Hindi natin kaano-ano, Ate nating pareho.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="m";
	document.getElementById('md').value="m";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="p";
	document.getElementById('mh').value="p";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "atis";




	}

	
	
	
	
	
	
	
	
		function mques4()
{

	document.getElementById('mquestion').innerHTML= "Until I am measured I am not known, Yet how you miss me when I have flown.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="m";
	document.getElementById('md').value="m";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="t";
	document.getElementById('mg').value="t";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "time";





	}

	
	
		
		function mques42()
{

	document.getElementById('mquestion').innerHTML= "Tubig na nagiging bato, Bato na nagiging tubig.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="b";
	document.getElementById('mc').value="b";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="t";
	document.getElementById('mg').value="t";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "asin";





	}

	
	
		
		function mques8()
{

	document.getElementById('mquestion').innerHTML="You heard me before, yet you hear me again, Then I die, 'till you call me again.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="h";
	document.getElementById('md').value="h";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="h";
	document.getElementById('mh').value="h";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "echo";




	}

	
	
			
		function mques46()
{

	document.getElementById('mquestion').innerHTML="Dinadala ko siya, Dinadala ako niya.";
	document.getElementById('ma').innerHTML="b";
	document.getElementById('ma').value="b";
	document.getElementById('mb').innerHTML="y";
	document.getElementById('mb').value="y";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bakya";




	}

	
	
	
				
		function mques10()
{

	document.getElementById('mquestion').innerHTML="Light as a feather, there is nothing in it.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="k";
	document.getElementById('md').value="k";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="b";
	document.getElementById('mf').value="b";
	document.getElementById('mg').innerHTML="x";
	document.getElementById('mg').value="x";
	document.getElementById('mh').innerHTML="h";
	document.getElementById('mh').value="h";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "breath";



	}

	
	
						
		function mques11()
{

	document.getElementById('mquestion').innerHTML="It cannot be seen, it weighs nothing, but when put into a barrel, it makes it lighter. What is it?";
	document.getElementById('ma').innerHTML="v";
	document.getElementById('ma').value="v";
	document.getElementById('mb').innerHTML="h";
	document.getElementById('mb').value="h";
	document.getElementById('mc').innerHTML="h";
	document.getElementById('mc').value="h";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="x";
	document.getElementById('mh').value="x";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="k";
	document.getElementById('mj').value="k";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "hole";



	}
	
	
	
					
		function mques13()
{

	document.getElementById('mquestion').innerHTML="What starts with a T, ends with a T, and has T in it?";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="h";
	document.getElementById('mb').value="h";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="p";
	document.getElementById('mf').value="p";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="x";
	document.getElementById('mh').value="x";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "teapot";



	}
	
	
					
		function mques15()
{

	document.getElementById('mquestion').innerHTML="You saw me where I never was and where I could not be. And yet within that very place, my face you often see. What am I?";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="x";
	document.getElementById('mh').value="x";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "reflection";



	}
	
	
	
					
		function mques17()
{

	document.getElementById('mquestion').innerHTML="Say my name and I disappear. What am I?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "silence";



	}
	
	
			function mques19()
{

	document.getElementById('mquestion').innerHTML="Soft and fragile is my skin, I get my growth in mud I'm dangerous as much as pretty, for if not careful, I draw blood.";
	document.getElementById('ma').innerHTML="h";
	document.getElementById('ma').value="h";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="h";
	document.getElementById('mj').value="h";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "thorn";



	}
	
	
	


		
			function mques21()
{

	document.getElementById('mquestion').innerHTML="It is greater than God and more evil than the devil. The poor have it, the rich need it and if you eat it you'll die. What is it?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="g";
	document.getElementById('mb').value="g";
	document.getElementById('mc').innerHTML="h";
	document.getElementById('mc').value="h";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "nothing";



	}
	
	


		
			function mques23()
{

	document.getElementById('mquestion').innerHTML="What always runs but never walks, often murmurs, never talks, has a bed but never sleeps, has a mouth but never eats?";
	document.getElementById('ma').innerHTML="v";
	document.getElementById('ma').value="v";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="v";
	document.getElementById('md').value="v";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="r";
	document.getElementById('mg').value="r";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "river";



	}
	
	

		
			function mques25()
{

	document.getElementById('mquestion').innerHTML="I never was, am always to be. No one ever saw me, nor ever will. And yet I am the confidence of all, To live and breath on this terrestrial ball. What am I?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="r";
	document.getElementById('mg').value="r";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="f";
	document.getElementById('mi').value="f";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "future";



	}
	
	

	
			function mques27()
{

	document.getElementById('mquestion').innerHTML="I drive men mad For love of me, Easily beaten, Never free.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="h";
	document.getElementById('mb').value="h";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="d";
	document.getElementById('mf').value="d";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "gold";



	}
	
	

	
			function mques29()
{

	document.getElementById('mquestion').innerHTML="I am a box that holds keys without locks, yet they can unlock your soul. What am I?";
	document.getElementById('ma').innerHTML="d";
	document.getElementById('ma').value="d";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="d";
	document.getElementById('mf').value="d";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "piano";



	}
	
	
	
			function mques31()
{

	document.getElementById('mquestion').innerHTML="What gets wetter as it dries?";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="f";
	document.getElementById('md').value="f";
	document.getElementById('me').innerHTML="j";
	document.getElementById('me').value="j";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "towel";



	}
	
	
	
			function mques33()
{

	document.getElementById('mquestion').innerHTML="I'm full of holes, yet I'm full of water. What am I?";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="g";
	document.getElementById('mf').value="g";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="p";
	document.getElementById('mi').value="p";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sponge";



	}
	
	


			function mques35()
{

	document.getElementById('mquestion').innerHTML="It's red, blue, purple and green, no one can reach it, not even the queen. What is it?";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="b";
	document.getElementById('md').value="b";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="g";
	document.getElementById('mf').value="g";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "rainbow";



	}
	
	

			function mques37()
{

	document.getElementById('mquestion').innerHTML="What has a neck and no head, two arms but no hands?";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="y";
	document.getElementById('md').value="y";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="t";
	document.getElementById('mg').value="t";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="h";
	document.getElementById('mi').value="h";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "shirt";



	}
	
	

		function mques39()
{

	document.getElementById('mquestion').innerHTML="I live in water If you cut my head I'm at your door, If you cut my tail I'm fruit, If you cut both I'm with you";
	document.getElementById('ma').innerHTML="l";
	document.getElementById('ma').value="l";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="h";
	document.getElementById('md').value="h";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="p";
	document.getElementById('mi').value="p";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pearl";



	}
	
	

		function mques41()
{

	document.getElementById('mquestion').innerHTML="What makes a loud noise when changing its jacket, becomes larger but weighs less?";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="c";
	document.getElementById('mb').value="c";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="p";
	document.getElementById('mi').value="p";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "popcorn";



	}
	
	
	
		function mques43()
{

	document.getElementById('mquestion').innerHTML="I never was, am always to be, No one ever saw me, nor ever will And yet I am the confidence of all To live and breathe on this terrestrial ball.";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="m";
	document.getElementById('md').value="m";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="p";
	document.getElementById('mi').value="p";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "tomorrow";



	}
	
	
	
	
		function mques45()
{

	document.getElementById('mquestion').innerHTML="Die without me, Never thank me. Walk right through me, never feel me. Always watching, never speaking. Always lurking, never seen.";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="x";
	document.getElementById('mi').value="x";
	document.getElementById('mj').innerHTML="z";
	document.getElementById('mj').value="z";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "air";



	}
	
	
	
		function mques47()
{

	document.getElementById('mquestion').innerHTML="Pregnant every time you see her, yet she will never give birth.";
	document.getElementById('ma').innerHTML="l";
	document.getElementById('ma').value="l";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="o";
	document.getElementById('mf').value="o";
	document.getElementById('mg').innerHTML="f";
	document.getElementById('mg').value="f";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "fullmoon";



	}
	
	
	
		function mques49()
{

	document.getElementById('mquestion').innerHTML="I go around in circles, But always straight ahead Never complain, No matter where I am led.";
	document.getElementById('ma').innerHTML="l";
	document.getElementById('ma').value="l";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="o";
	document.getElementById('mf').value="o";
	document.getElementById('mg').innerHTML="f";
	document.getElementById('mg').value="f";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "wheel";



	}
	
	
		
	
		function mques50()
{

	document.getElementById('mquestion').innerHTML="Dalawang libing, laging may hangin.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="g";
	document.getElementById('mf').value="g";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="m";
	document.getElementById('mh').value="m";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "ilong";



	}

	
	
	
	function mques12()
{

	document.getElementById('mquestion').innerHTML="Bahay ni Kiko, walang bintana, walang pinto.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="m";
	document.getElementById('mh').value="m";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "itlog";



	}


	
	
	function mques14()
{

	document.getElementById('mquestion').innerHTML="Binili ko nang di kagustuhan,Ginamit ko nang di nalalaman.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kabaong";



	}

	
		
	function mques16()
{

	document.getElementById('mquestion').innerHTML="May binti walang hita,May tuktok walang mukha.";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="f";
	document.getElementById('mg').value="f";
	document.getElementById('mh').innerHTML="t";
	document.getElementById('mh').value="t";
	document.getElementById('mi').innerHTML="u";
	document.getElementById('mi').value="u";
	document.getElementById('mj').innerHTML="r";
	document.getElementById('mj').value="r";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kabute";



	}

	
	
		
	function mques18()
{

	document.getElementById('mquestion').innerHTML="Ang ina’y gumagapang pa, Ang anak ay umuupo na.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="b";
	document.getElementById('mj').value="b";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kalabasa";



	}
	
	
	function mques20()
{

	document.getElementById('mquestion').innerHTML="Araw araw bagong buhay,Taun-taon namamatay.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="d";
	document.getElementById('mc').value="d";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kalendaryo";



	}
	
	
	function mques22()
{

	document.getElementById('mquestion').innerHTML="Putukan nang putukan,hindi nag kakarinigan.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="p";
	document.getElementById('mc').value="p";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="m";
	document.getElementById('me').value="m";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="b";
	document.getElementById('mg').value="b";
	document.getElementById('mh').innerHTML="h";
	document.getElementById('mh').value="h";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kampana";



	}
	
	
	
	function mques24()
{

	document.getElementById('mquestion').innerHTML="Akoy ma’y kasama sa pahingi ng awa; ako’y di umiyak, siya ay lumuha.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="l";
	document.getElementById('mc').value="l";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kandila";



	}
	
	
	
	function mques26()
{

	document.getElementById('mquestion').innerHTML="Isang senyora,nakaupo sa tasa.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="c";
	document.getElementById('mj').value="c";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kasoy";



	}
	
	
	function mques28()
{

	document.getElementById('mquestion').innerHTML="Anong halaman ang sagana sa ugat, dahon, at sanga,ngunit wala sa bunga.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="f";
	document.getElementById('md').value="f";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kawayan";



	}
	
	
	
	
	function mques30()
{

	document.getElementById('mquestion').innerHTML="Ma-tag-init, ma-tag-ulan,dala-dala’y balutan.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kuba";



	}
	
	
	
	function mques32()
{

	document.getElementById('mquestion').innerHTML="Naabot na ng kamay,iginawa pa ng tulay.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kubyertos";



	}
	
	
	function mques34()
{

	document.getElementById('mquestion').innerHTML="Limang mag kakapatid,tig-tig-isa ng silid.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="y";
	document.getElementById('md').value="y";
	document.getElementById('me').innerHTML="k";
	document.getElementById('me').value="k";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="k";
	document.getElementById('mg').value="k";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kuko";



	}
	
	
	
	
	function mques36()
{

	document.getElementById('mquestion').innerHTML="May hita ay walang binti,may ngipin ay walang labi.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="d";
	document.getElementById('mc').value="d";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="k";
	document.getElementById('mg').value="k";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="u";
	document.getElementById('mj').value="u";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kudkuran";



	}
	
	
	
	
	function mques38()
{

	document.getElementById('mquestion').innerHTML="Maliit pa si kumara,marunong ng humuni.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kuliglig";



	}
	
	
	
	function mques1()
{

	document.getElementById('mquestion').innerHTML="Baka ko sa Maynila abot dito ang unga.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kulog";



	}
	
	
		function mques3()
{

	document.getElementById('mquestion').innerHTML="Aling paa ang nasa ulo?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="k";
	document.getElementById('md').value="k";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="u";
	document.getElementById('mf').value="u";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kuto";



	}
	
	
		function mques5()
{

	document.getElementById('mquestion').innerHTML="Kadena'y isinabit,sa batok nakakawit.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="k";
	document.getElementById('md').value="k";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="u";
	document.getElementById('mf').value="u";
	document.getElementById('mg').innerHTML="t";
	document.getElementById('mg').value="t";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kuwintas";



	}
	
	
	function mques7()
{

	document.getElementById('mquestion').innerHTML="Kung saan masikip doon nagpipilit.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="l";
	document.getElementById('mc').value="l";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="u";
	document.getElementById('mf').value="u";
	document.getElementById('mg').innerHTML="b";
	document.getElementById('mg').value="b";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="v";
	document.getElementById('mj').value="v";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "labong";



	}
	
	
	
	function mques9()
{

	document.getElementById('mquestion').innerHTML="Itulak at hilahin,sigurado ang kain.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="u";
	document.getElementById('mf').value="u";
	document.getElementById('mg').innerHTML="b";
	document.getElementById('mg').value="b";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="k";
	document.getElementById('mi').value="k";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "lagari";



	}
	

	
	
	
								
		function mques50()
{

	document.getElementById('mquestion').innerHTML="Take off my skin, I won't cry, but you will. What am I?";
	document.getElementById('ma').innerHTML="f";
	document.getElementById('ma').value="f";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="v";
	document.getElementById('mi').value="v";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "onion";



	}
	
	
	
		
								
		function mques51()
{

	document.getElementById('mquestion').innerHTML="I'm the son of water but when I return to water, I die Who am I?";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="c";
	document.getElementById('mb').value="c";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="y";
	document.getElementById('me').value="y";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="x";
	document.getElementById('mj').value="x";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "ice";



	}
	
	
	
			
								
		function mques52()
{

	document.getElementById('mquestion').innerHTML="I travel the world and I am drunk constantly. Who am I?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="x";
	document.getElementById('mj').value="x";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "water";



	}
	
	
	
		
	
			
								
		function mques53()
{

	document.getElementById('mquestion').innerHTML="You answer me, although I never ask you questions. What am I?";
	document.getElementById('ma').innerHTML="h";
	document.getElementById('ma').value="h";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "telephone";



	}
	
	
	
				
								
		function mques54()
{

	document.getElementById('mquestion').innerHTML="What has to be broken before it can be used?";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="d";
	document.getElementById('mb').value="d";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="g";
	document.getElementById('mh').value="g";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "egg";



	}
	
	
	
				
								
		function mques55()
{

	document.getElementById('mquestion').innerHTML="If you have it, you want to share it. If you share it, you don't have it. What is it?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="x";
	document.getElementById('mi').value="x";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "secret";



	}
	
	
	
		
				
								
		function mques56()
{

	document.getElementById('mquestion').innerHTML="He has married many women but has never married. Who is he?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="p";
	document.getElementById('mc').value="p";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "priest";



	}
	
	
	
	
				
								
		function mques57()
{

	document.getElementById('mquestion').innerHTML="	The more you take the more you leave behind.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "footstep";



	}
	
	
	
	
								
		function mques58()
{

	document.getElementById('mquestion').innerHTML="What can run but never walks, has a mouth but never talks, has a head but never weeps, has a bed but never sleeps?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="v";
	document.getElementById('mb').value="v";
	document.getElementById('mc').innerHTML="j";
	document.getElementById('mc').value="j";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "river";



	}
	
	
	
	
								
		function mques59()
{

	document.getElementById('mquestion').innerHTML="As I walked along the path I saw something with four fingers and one thumb, but it was not flesh, fish, bone, or fowl.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="v";
	document.getElementById('mb').value="v";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="d";
	document.getElementById('mg').value="d";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "gloves";



	}
	
	
	
	
								
		function mques60()
{

	document.getElementById('mquestion').innerHTML="What can fill a room but takes up no space?";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="h";
	document.getElementById('mg').value="h";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "light";



	}
	
	
								
		function mques61()
{

	document.getElementById('mquestion').innerHTML="What kind of dog keeps the best time?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="h";
	document.getElementById('mc').value="h";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="d";
	document.getElementById('mj').value="d";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "watchdog";



	}
	
	
	
	
	
								
		function mques62()
{

	document.getElementById('mquestion').innerHTML="What time of day, when written in capital letters, is the same forwards, backwards and upside down?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="z";
	document.getElementById('mc').value="z";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="x";
	document.getElementById('mf').value="x";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "noon";



	}
	
	
	
								
		function mques63()
{

	document.getElementById('mquestion').innerHTML="A tasty reward given to well behaved dogs and kids.";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="x";
	document.getElementById('mf').value="x";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "treat";



	}
	
	
								
		function mques64()
{

	document.getElementById('mquestion').innerHTML="A Caribbean shape that makes ships disappear.";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "triangle";



	}
	
	
	
	
								
		function mques65()
{

	document.getElementById('mquestion').innerHTML="What has a face and two hands but no arms or legs?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="c";
	document.getElementById('mc').value="c";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="o";
	document.getElementById('mf').value="o";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="c";
	document.getElementById('mj').value="c";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "clock";



	}
	
	
	
		
				
								
		function mques66()
{

	document.getElementById('mquestion').innerHTML="What five-letter word becomes shorter when you add two letters to it?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="h";
	document.getElementById('mg').value="h";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "short";



	}
	
	
	
	
				
								
		function mques67()
{

	document.getElementById('mquestion').innerHTML="What word begins and ends with an 'e' but only has one letter";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="v";
	document.getElementById('mf').value="v";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "envelope";



	}
	
	
	
	
								
		function mques68()
{

	document.getElementById('mquestion').innerHTML=" What has a neck but no head?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="b";
	document.getElementById('mb').value="b";
	document.getElementById('mc').innerHTML="l";
	document.getElementById('mc').value="l";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bottle";



	}
	
	
	
	
								
		function mques69()
{

	document.getElementById('mquestion').innerHTML="What type of cheese is made backwards?";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="v";
	document.getElementById('mb').value="v";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="d";
	document.getElementById('mg').value="d";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "edam";



	}
	
	
	
	
								
		function mques70()
{

	document.getElementById('mquestion').innerHTML="What gets wetter as it dries?";
	document.getElementById('ma').innerHTML="w";
	document.getElementById('ma').value="w";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="h";
	document.getElementById('mg').value="h";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "towel";



	}
	
	
	
	
								
		function mques71()
{

	document.getElementById('mquestion').innerHTML="starts with a 'p', ends with an 'e' and has thousands of letters?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="f";
	document.getElementById('mh').value="f";
	document.getElementById('mi').innerHTML="f";
	document.getElementById('mi').value="f";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "postoffice";



	}
	
	
	
	
	
								
		function mques72()
{

	document.getElementById('mquestion').innerHTML="What has to be broken before you can eat it?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "egg";



	}
	
	
	
								
		function mques73()
{

	document.getElementById('mquestion').innerHTML="What begins with T, ends with T and has T in it?";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="x";
	document.getElementById('mf').value="x";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "teapot";



	}
	
	
								
		function mques74()
{

	document.getElementById('mquestion').innerHTML="What belongs to you but others use it more than you do?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "name";



	}
	
	
	
	
								
		function mques75()
{

	document.getElementById('mquestion').innerHTML="The more you take away, the larger it becomes. What is it?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="o";
	document.getElementById('mf').value="o";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="h";
	document.getElementById('mj').value="h";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "hole";



	}
	
	
	
		
				
								
		function mques76()
{

	document.getElementById('mquestion').innerHTML="Where do fish keep their money";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="b";
	document.getElementById('mf').value="b";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="v";
	document.getElementById('mj').value="v";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "riverbank";



	}
	
	
	
	
				
								
		function mques77()
{

	document.getElementById('mquestion').innerHTML="What is it that you will break every time you name it?";
	document.getElementById('ma').innerHTML="c";
	document.getElementById('ma').value="c";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "silence";



	}
	
	
	
	
								
		function mques78()
{

	document.getElementById('mquestion').innerHTML="What flies without wings?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="b";
	document.getElementById('mb').value="b";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "time";



	}
	
	
	
	
								
		function mques79()
{

	document.getElementById('mquestion').innerHTML="What Kind of Fish chases a mouse?";
	document.getElementById('ma').innerHTML="f";
	document.getElementById('ma').value="f";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="d";
	document.getElementById('mg').value="d";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="h";
	document.getElementById('mi').value="h";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "catfish";



	}
	
	
	
	
								
		function mques80()
{

	document.getElementById('mquestion').innerHTML="What goes up and down without moving?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "stairs";



	}
	
	
	
		
	
	
	
	
								
		function mques81()
{

	document.getElementById('mquestion').innerHTML="I have a face, two arms, and two hands, yet I cannot move. I count to twelve, yet I cannot speak. I can still tell you something?";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="f";
	document.getElementById('mh').value="f";
	document.getElementById('mi').innerHTML="f";
	document.getElementById('mi').value="f";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "clock";



	}
	
	
	
	
	
								
		function mques82()
{

	document.getElementById('mquestion').innerHTML="What is round on both ends and hi in the middle?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "ohio";



	}
	
	
	
								
		function mques83()
{

	document.getElementById('mquestion').innerHTML="What do you call a dog that sweats so much?";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="x";
	document.getElementById('mf').value="x";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "hotdog";



	}
	
	
								
		function mques84()
{

	document.getElementById('mquestion').innerHTML="What rains at the north pole?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "reindeer";



	}
	
	
	
	
								
		function mques85()
{

	document.getElementById('mquestion').innerHTML="What calls for help, when written in capital letters, is the same forwards, backwards and upside down?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="o";
	document.getElementById('mf').value="o";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="h";
	document.getElementById('mj').value="h";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sos";



	}
	
	
	
		
				
								
		function mques86()
{

	document.getElementById('mquestion').innerHTML="Commits friendly home invasions one night a year";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="u";
	document.getElementById('mg').value="u";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="c";
	document.getElementById('mj').value="c";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "santaclaus";



	}
	
	
	
	
				
								
		function mques87()
{

	document.getElementById('mquestion').innerHTML="Everyone claims to know a way to stop these involuntary contractions but none of them work";
	document.getElementById('ma').innerHTML="c";
	document.getElementById('ma').value="c";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="h";
	document.getElementById('mi').value="h";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "hiccup";



	}
	
	
	
	
								
		function mques88()
{

	document.getElementById('mquestion').innerHTML="One of the best things you can hope for after whacking a ball with a stick?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="h";
	document.getElementById('mi').value="h";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "homerun";



	}
	
	
	
	
								
		function mques89()
{

	document.getElementById('mquestion').innerHTML="They put the heat in pop tarts";
	document.getElementById('ma').innerHTML="f";
	document.getElementById('ma').value="f";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="d";
	document.getElementById('mg').value="d";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "toaster";



	}
	
	
	
	
								
		function mques90()
{

	document.getElementById('mquestion').innerHTML="What has a ring, but no finger?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="h";
	document.getElementById('mb').value="h";
	document.getElementById('mc').innerHTML="p";
	document.getElementById('mc').value="p";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "telephone";



	}
	
	
	
	
	
	
		
	
	
	
	
								
		function mques91()
{

	document.getElementById('mquestion').innerHTML="What has four legs, but can't walk?";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="f";
	document.getElementById('mh').value="f";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "table";



	}
	
	
	
	
	
								
		function mques92()
{

	document.getElementById('mquestion').innerHTML="What is higher without the head, than with it?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="w";
	document.getElementById('mg').value="w";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="p";
	document.getElementById('mi').value="p";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pillow";



	}
	
	
	
								
		function mques93()
{

	document.getElementById('mquestion').innerHTML="What's harder to catch the faster you run?";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "breath";



	}
	
	
								
		function mques94()
{

	document.getElementById('mquestion').innerHTML="What invention lets you look right through a wall?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="r";
	document.getElementById('md').value="r";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="w";
	document.getElementById('mf').value="w";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "window";



	}
	
	
	
	
								
		function mques95()
{

	document.getElementById('mquestion').innerHTML="What is made of wood, but can't be sawed";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="o";
	document.getElementById('mf').value="o";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="h";
	document.getElementById('mj').value="h";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sawdust";



	}
	
	
	
		
				
								
		function mques96()
{

	document.getElementById('mquestion').innerHTML="What is a witch's favorite school subject?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="u";
	document.getElementById('mg').value="u";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "spelling";



	}
	
	
	
	
				
								
		function mques97()
{

	document.getElementById('mquestion').innerHTML="What is black and white and read all over?";
	document.getElementById('ma').innerHTML="c";
	document.getElementById('ma').value="c";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "newspaper";



	}
	
	
	
	
								
		function mques98()
{

	document.getElementById('mquestion').innerHTML="Easy to get into, but hard to get out ";
	document.getElementById('ma').innerHTML="l";
	document.getElementById('ma').value="l";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="f";
	document.getElementById('mf').value="f";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "trouble";



	}
	
	
	
	
								
		function mques99()
{

	document.getElementById('mquestion').innerHTML="What is as big as you are and yet does not weigh anything?";
	document.getElementById('ma').innerHTML="f";
	document.getElementById('ma').value="f";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="d";
	document.getElementById('mg').value="d";
	document.getElementById('mh').innerHTML="h";
	document.getElementById('mh').value="h";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "shadow";



	}
	
	
	
	
								
		function mques100()
{

	document.getElementById('mquestion').innerHTML="When you have me, you feel like sharing me, but, if you do share me, you don't have me. ";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="p";
	document.getElementById('mc').value="p";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "secret";



	}
	
	
	
	
	
		
	
	
		
	
	
	
	
								
		function mques101()
{

	document.getElementById('mquestion').innerHTML="It is an insect and the first part of it's name is the name of another insect. What is it?";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "beetle";



	}
	
	
	
	
	
								
		function mques102()
{

	document.getElementById('mquestion').innerHTML="What becomes white when it is dirty?";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="d";
	document.getElementById('mb').value="d";
	document.getElementById('mc').innerHTML="c";
	document.getElementById('mc').value="c";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="b";
	document.getElementById('mf').value="b";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "blackboard";



	}
	
	
	
								
		function mques103()
{

	document.getElementById('mquestion').innerHTML="What word of five letters has only left when two letters are removed?";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "stone";



	}
	
	
								
		function mques104()
{

	document.getElementById('mquestion').innerHTML="Which vehicle is spelled the same forwards and backwards?";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="r";
	document.getElementById('mh').value="r";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "racecar";



	}
	
	
	
	
								
		function mques105()
{

	document.getElementById('mquestion').innerHTML="I am lighter than air but a million men cannot lift me up. What am I?";
	document.getElementById('ma').innerHTML="b";
	document.getElementById('ma').value="b";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="b";
	document.getElementById('mf').value="b";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="h";
	document.getElementById('mj').value="h";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bubble";



	}
	
	
	
		
				
								
		function mques106()
{

	document.getElementById('mquestion').innerHTML="It is everything to someone, and nothing to everyone else. What is it?";
	document.getElementById('ma').innerHTML="d";
	document.getElementById('ma').value="d";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="u";
	document.getElementById('mg').value="u";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mind";



	}
	
	
	
	
				
								
		function mques107()
{

	document.getElementById('mquestion').innerHTML="Forward I am heavy, backwards I am not. What am I?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "not";



	}
	
	
	
	
								
		function mques108()
{

	document.getElementById('mquestion').innerHTML="What object has keys that open no locks, space but no room, and you can enter but not go in?";
	document.getElementById('ma').innerHTML="d";
	document.getElementById('ma').value="d";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="y";
	document.getElementById('mf').value="y";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="k";
	document.getElementById('mi').value="k";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "keyboard";



	}
	
	
	
	
								
		function mques109()
{

	document.getElementById('mquestion').innerHTML="What bone has a sense of humor?";
	document.getElementById('ma').innerHTML="f";
	document.getElementById('ma').value="f";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="d";
	document.getElementById('mg').value="d";
	document.getElementById('mh').innerHTML="h";
	document.getElementById('mh').value="h";
	document.getElementById('mi').innerHTML="u";
	document.getElementById('mi').value="u";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "humorous";



	}
	
	
	
	
								
		function mques110()
{

	document.getElementById('mquestion').innerHTML="What turns everything around, but does not move?";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mirror";



	}
	
	
	
	
		
	
	
	
	
								
		function mques111()
{

	document.getElementById('mquestion').innerHTML="What is half of two plus two?";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "three";



	}
	
	
	
	
	
								
		function mques112()
{

	document.getElementById('mquestion').innerHTML="What word looks the same upside down and backwards?";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="c";
	document.getElementById('mc').value="c";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="m";
	document.getElementById('mg').value="m";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "swims";



	}
	
	
	
								
		function mques113()
{

	document.getElementById('mquestion').innerHTML="What’s the difference between here and there?";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "t";



	}
	
	
								
		function mques114()
{

	document.getElementById('mquestion').innerHTML="What sits in a corner while traveling all around the world?";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="m";
	document.getElementById('mb').value="m";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="t";
	document.getElementById('mg').value="t";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "stamp";



	}
	
	
	
	
								
		function mques115()
{

	document.getElementById('mquestion').innerHTML=" What body part is pronounced as one letter but written three, only two different letters are used?";
	document.getElementById('ma').innerHTML="b";
	document.getElementById('ma').value="b";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="u";
	document.getElementById('md').value="u";
	document.getElementById('me').innerHTML="y";
	document.getElementById('me').value="y";
	document.getElementById('mf').innerHTML="b";
	document.getElementById('mf').value="b";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "eye";



	}
	
	
	
		
				
								
		function mques116()
{

	document.getElementById('mquestion').innerHTML="What keeps things green and keeps kids occupied in the summertime";
	document.getElementById('ma').innerHTML="l";
	document.getElementById('ma').value="l";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="k";
	document.getElementById('md').value="k";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="r";
	document.getElementById('mg').value="r";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sprinkler";



	}
	
	
	
	
				
								
		function mques117()
{

	document.getElementById('mquestion').innerHTML="A shower that lights up the sky";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "meteor";



	}
	
	
	
	
								
		function mques118()
{

	document.getElementById('mquestion').innerHTML="Longer than a decade and shorter than a millennium";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="c";
	document.getElementById('mi').value="c";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "century";



	}
	
	
	
	
								
		function mques119()
{

	document.getElementById('mquestion').innerHTML="I never was, am always to be. No one ever saw me, nor ever will. And yet I am the confidence of all, To live and breath on this terrestrial ball. What am I?";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="f";
	document.getElementById('mg').value="f";
	document.getElementById('mh').innerHTML="t";
	document.getElementById('mh').value="t";
	document.getElementById('mi').innerHTML="u";
	document.getElementById('mi').value="u";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "future";



	}
	
	
	
	
								
		function mques120()
{

	document.getElementById('mquestion').innerHTML="What has a head, a tail, and has no legs?";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "coin";



	}
	
	
		
		
	
	
								
		function mques121()
{

	document.getElementById('mquestion').innerHTML="Each morning I appear to lie at your feet, All day I will follow no matter how fast you run, Yet I nearly perish in the midday sun.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "shadow";



	}
	
	
	
	
	
								
		function mques122()
{

	document.getElementById('mquestion').innerHTML="My life can be measured in hours, I serve by being devoured. Thin, I am quick Fat, I am slow Wind is my foe.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="c";
	document.getElementById('mc').value="c";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="d";
	document.getElementById('mg').value="d";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "candle";



	}
	
	
	
								
		function mques123()
{

	document.getElementById('mquestion').innerHTML="I am seen in the water if seen in the sky, I am in the rainbow.";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="b";
	document.getElementById('mb').value="b";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="u";
	document.getElementById('mj').value="u";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "blue";



	}
	
	
								
		function mques124()
{

	document.getElementById('mquestion').innerHTML="Three lives have I. Gentle enough to soothe the skin, Light enough to caress the sky, Hard enough to crack rocks.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="c";
	document.getElementById('mf').value="c";
	document.getElementById('mg').innerHTML="t";
	document.getElementById('mg').value="t";
	document.getElementById('mh').innerHTML="w";
	document.getElementById('mh').value="w";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="r";
	document.getElementById('mj').value="r";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "water";



	}
	
	
	
	
								
		function mques125()
{

	document.getElementById('mquestion').innerHTML="Two in a corner, 1 in a room, 0 in a house, but 1 in a shelter. What am I?";
	document.getElementById('ma').innerHTML="b";
	document.getElementById('ma').value="b";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="u";
	document.getElementById('md').value="u";
	document.getElementById('me').innerHTML="y";
	document.getElementById('me').value="y";
	document.getElementById('mf').innerHTML="b";
	document.getElementById('mf').value="b";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "r";



	}
	
	
	
		
				
								
		function mques126()
{

	document.getElementById('mquestion').innerHTML="It cannot be seen, it weighs nothing, but when put into a barrel, it makes it lighter. What is it?";
	document.getElementById('ma').innerHTML="l";
	document.getElementById('ma').value="l";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="k";
	document.getElementById('md').value="k";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="r";
	document.getElementById('mg').value="r";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "hole";



	}
	
	
	
	
				
								
		function mques127()
{

	document.getElementById('mquestion').innerHTML="I can be long, or I can be short. I can be grown, and I can be bought. I can be painted, or left bare. I can be round, or square. What am I?";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "nail";



	}
	
	
	
	
								
		function mques128()
{

	document.getElementById('mquestion').innerHTML="Soft and fragile is my skin, I get my growth in mud I'm dangerous as much as pretty, for if not careful, I draw blood.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="h";
	document.getElementById('mh').value="h";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "thorn";



	}
	
	
	
	
								
		function mques129()
{

	document.getElementById('mquestion').innerHTML="My first is twice in apple but not once in tart. My second is in liver but not in heart. My third is in giant and also in ghost. Whole I'm best when I am roast. What am I?";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="p";
	document.getElementById('me').value="p";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="f";
	document.getElementById('mg').value="f";
	document.getElementById('mh').innerHTML="t";
	document.getElementById('mh').value="t";
	document.getElementById('mi').innerHTML="u";
	document.getElementById('mi').value="u";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pig";



	}
	
	
	
	
								
		function mques130()
{

	document.getElementById('mquestion').innerHTML="A mile from end to end, yet as close to as a friend. A precious commodity, freely given. What is it?";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="e";
	document.getElementById('md').value="e";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "smile";



	}
	
	
		
			
	
	
								
		function mques131()
{

	document.getElementById('mquestion').innerHTML="Alive without breath, As cold as death, Never thirsty, Ever drinking, Drowns on dry land.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="f";
	document.getElementById('mc').value="f";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "fish";



	}
	
	
	
	
	
								
		function mques132()
{

	document.getElementById('mquestion').innerHTML="Die without me, Never thank me. Walk right through me, never feel me. Always watching, never speaking. Always lurking, never seen.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="c";
	document.getElementById('mc').value="c";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="r";
	document.getElementById('mg').value="r";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "air";



	}
	
	
	
								
		function mques133()
{

	document.getElementById('mquestion').innerHTML="Take one out and scratch my head, I am now black but once was red.";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="e";
	document.getElementById('mc').value="e";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="m";
	document.getElementById('me').value="m";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="h";
	document.getElementById('mg').value="h";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="u";
	document.getElementById('mj').value="u";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "match";



	}
	
	
								
		function mques134()
{

	document.getElementById('mquestion').innerHTML="Only two backbones and thousands of ribs.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="w";
	document.getElementById('mh').value="w";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "railroad";



	}
	
	
	
	
								
		function mques135()
{

	document.getElementById('mquestion').innerHTML="Big as a biscuit, deep as a cup, Even a river can't fill it up. What is it?";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="t";
	document.getElementById('mh').value="t";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "strainer";



	}
	
	
	
		
				
								
		function mques136()
{

	document.getElementById('mquestion').innerHTML="It is greater than God and more evil than the devil. The poor have it, the rich need it and if you eat it you'll die. What is it?";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="n";
	document.getElementById('mb').value="n";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="r";
	document.getElementById('mg').value="r";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "nothing";



	}
	
	
	
	
				
								
		function mques137()
{

	document.getElementById('mquestion').innerHTML="I am always hungry, I must always be fed,The finger I touch, Will soon turn red.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="f";
	document.getElementById('mj').value="f";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "fire";



	}
	
	
	
	
								
		function mques138()
{

	document.getElementById('mquestion').innerHTML="All about, but cannot be seen, Can be captured, cannot be held, No throat, but can be heard.";
	document.getElementById('ma').innerHTML="d";
	document.getElementById('ma').value="d";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "wind";



	}
	
	
	
	
								
		function mques139()
{

	document.getElementById('mquestion').innerHTML="How far will a blind dog walk into a forest?";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="w";
	document.getElementById('mc').value="w";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="p";
	document.getElementById('me').value="p";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="f";
	document.getElementById('mg').value="f";
	document.getElementById('mh').innerHTML="t";
	document.getElementById('mh').value="t";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "halfway";



	}
	
	
	
	
								
		function mques140()
{

	document.getElementById('mquestion').innerHTML="I am, in truth, a yellow fork from tables in the sky, The apparatus of the dark to ignorance revealed.";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "lightning";



	}
	
	
		
	
	
								
		function mques141()
{

	document.getElementById('mquestion').innerHTML="Pedro hides but you can still see his head.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="f";
	document.getElementById('mc').value="f";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "nail";



	}
	
	
	
	
	
								
		function mques142()
{

	document.getElementById('mquestion').innerHTML="Riddle me, riddle me, here comes a roaring chain";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="r";
	document.getElementById('mg').value="r";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "train";



	}
	
	
	
								
		function mques143()
{

	document.getElementById('mquestion').innerHTML="Here comes Kaka, walking with an open leg.";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="h";
	document.getElementById('mg').value="h";
	document.getElementById('mh').innerHTML="c";
	document.getElementById('mh').value="c";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "scissor";



	}
	
	
								
		function mques144()
{

	document.getElementById('mquestion').innerHTML="Adam's hair, you can't count.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="c";
	document.getElementById('md').value="c";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="w";
	document.getElementById('mh').value="w";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "rain";



	}
	
	
	
	
								
		function mques145()
{

	document.getElementById('mquestion').innerHTML="Rice cake of the king, that you cannot divide.";
	document.getElementById('ma').innerHTML="n";
	document.getElementById('ma').value="n";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="w";
	document.getElementById('me').value="w";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="t";
	document.getElementById('mh').value="t";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "water";



	}
	
	
	
		
				
								
		function mques146()
{

	document.getElementById('mquestion').innerHTML="Cute hares that hop and deliver eggs at Easter are called by this nickname.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="n";
	document.getElementById('mb').value="n";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="r";
	document.getElementById('mg').value="r";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="u";
	document.getElementById('mj').value="u";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bunny";



	}
	
	
	
	
				
								
		function mques147()
{

	document.getElementById('mquestion').innerHTML="This monkey food makes people slip and fall in cartoons.";
	document.getElementById('ma').innerHTML="b";
	document.getElementById('ma').value="b";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="a";
	document.getElementById('mc').value="a";
	document.getElementById('md').innerHTML="b";
	document.getElementById('md').value="b";
	document.getElementById('me').innerHTML="e";
	document.getElementById('me').value="e";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "banana";



	}
	
	
	
	
								
		function mques148()
{

	document.getElementById('mquestion').innerHTML="Owned by Old McDonald.";
	document.getElementById('ma').innerHTML="d";
	document.getElementById('ma').value="d";
	document.getElementById('mb').innerHTML="r";
	document.getElementById('mb').value="r";
	document.getElementById('mc').innerHTML="f";
	document.getElementById('mc').value="f";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "farm";



	}
	
	
	
	
								
		function mques149()
{

	document.getElementById('mquestion').innerHTML="Poorly behaved children often find themselves sitting in these.";
	document.getElementById('ma').innerHTML="c";
	document.getElementById('ma').value="c";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="f";
	document.getElementById('mg').value="f";
	document.getElementById('mh').innerHTML="e";
	document.getElementById('mh').value="e";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="r";
	document.getElementById('mj').value="r";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "corners";



	}
	
	
	
	
								
		function mques150()
{

	document.getElementById('mquestion').innerHTML="It keeps things green and keeps the kids occupied in the summertime.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="p";
	document.getElementById('mc').value="p";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="e";
	document.getElementById('mi').value="e";
	document.getElementById('mj').innerHTML="n";
	document.getElementById('mj').value="n";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sprinkler";



	}
	
	
		
	
	
		function mques151()
{

	document.getElementById('mquestion').innerHTML="Bugtong-pala-bugtong, kadenang umuugong.";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="r";
	document.getElementById('mj').value="r";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "tren";



	}
	
	
	
		function mques152()
{

	document.getElementById('mquestion').innerHTML="Buhok ni Adan, hindi mabilang.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="m";
	document.getElementById('mb').value="m";
	document.getElementById('mc').innerHTML="l";
	document.getElementById('mc').value="l";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "ulan";



	}
	
	
	
	
		function mques153()
{

	document.getElementById('mquestion').innerHTML="Bibingka ng hari, hindi mo mahati. ";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="b";
	document.getElementById('mc').value="b";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="u";
	document.getElementById('mj').value="u";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "tubig";



	}
	
	
	
	
		function mques154()
{

	document.getElementById('mquestion').innerHTML="Iisa ang pasukan, tatlo ang labasan.";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="d";
	document.getElementById('mg').value="d";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "damit";



	}
	
	
	
	
		function mques155()
{

	document.getElementById('mquestion').innerHTML="Malaking supot ni Mang Jacob, kung sisidlan ay pataob.";
	document.getElementById('ma').innerHTML="u";
	document.getElementById('ma').value="u";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="k";
	document.getElementById('mi').value="k";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kulambo";



	}
	
	
	
	
		function mques156()
{

	document.getElementById('mquestion').innerHTML="Dalawang pipit nag titimbangan sa isang siit.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="b";
	document.getElementById('mf').value="b";
	document.getElementById('mg').innerHTML="h";
	document.getElementById('mg').value="h";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="k";
	document.getElementById('mj').value="k";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "hikaw";



	}
	
	
	
	
		function mques157()
{

	document.getElementById('mquestion').innerHTML="Nagdaan si Kabo Negro, namatay na lahat ang tao.";
	document.getElementById('ma').innerHTML="b";
	document.getElementById('ma').value="b";
	document.getElementById('mb').innerHTML="n";
	document.getElementById('mb').value="n";
	document.getElementById('mc').innerHTML="y";
	document.getElementById('mc').value="y";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="p";
	document.getElementById('mh').value="p";
	document.getElementById('mi').innerHTML="s";
	document.getElementById('mi').value="s";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "gabi";



	}
	
	
	
	
	function mques158()
{

	document.getElementById('mquestion').innerHTML="Ang alaga kong hugis bilog, barya-barya ang laman-loob.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="b";
	document.getElementById('md').value="b";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="y";
	document.getElementById('mi').value="y";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "alkansya";



	}
	
	
		function mques159()
{

	document.getElementById('mquestion').innerHTML="Sa liwanag ay hindi mo makita. Sa dilim ay maliwanag sila.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="g";
	document.getElementById('mb').value="g";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="b";
	document.getElementById('mj').value="b";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bituin";



	}

	
	

	
	function mques160()
{

	document.getElementById('mquestion').innerHTML="Nagsaing si Hudas, kinuha ang tubig itinapon ang bigas.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "gata";



	}
	
	
	
	
	
		
				
	
		
	
		function mques161()
{

	document.getElementById('mquestion').innerHTML="Bahay ni Tinyente nag-iisa ang poste.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="r";
	document.getElementById('mj').value="r";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "payong";



	}
	
	
	
		function mques162()
{

	document.getElementById('mquestion').innerHTML="Hiyas na puso, kulay ginto, mabango kung amuyin, masarap kung kainin.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="m";
	document.getElementById('mb').value="m";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mangga";



	}
	
	
	
	
		function mques163()
{

	document.getElementById('mquestion').innerHTML="Butong binalot ng bakal, bakal na binalot ng kristal.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="l";
	document.getElementById('mc').value="l";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "lansones";



	}
	
	
	
	
		function mques164()
{

	document.getElementById('mquestion').innerHTML="Nag tapis nang nag tapis nakalitaw ang bulbolis.";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mais";



	}
	
	
	
	
		function mques165()
{

	document.getElementById('mquestion').innerHTML="Aling pagkain sa mundo, ang nakalabas ang buto?";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="b";
	document.getElementById('me').value="b";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="k";
	document.getElementById('mi').value="k";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kasoy";



	}
	
	
	
	
		function mques166()
{

	document.getElementById('mquestion').innerHTML="Heto na si Ingkong, nakaupo sa lusong.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="o";
	document.getElementById('mf').value="o";
	document.getElementById('mg').innerHTML="h";
	document.getElementById('mg').value="h";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="k";
	document.getElementById('mj').value="k";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kasoy";



	}
	
	
	
	
		function mques167()
{

	document.getElementById('mquestion').innerHTML="Nakatalikod na ang prinsesa, mukha niya'y nakaharap pa.";
	document.getElementById('ma').innerHTML="b";
	document.getElementById('ma').value="b";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="y";
	document.getElementById('mc').value="y";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "balimbing";



	}
	
	
	
	
	function mques168()
{

	document.getElementById('mquestion').innerHTML="Balat niya'y berde, buto niya'y itim,laman niya'y pula, sino siya?";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="b";
	document.getElementById('md').value="b";
	document.getElementById('me').innerHTML="p";
	document.getElementById('me').value="p";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="y";
	document.getElementById('mi').value="y";
	document.getElementById('mj').innerHTML="w";
	document.getElementById('mj').value="w";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pakwan";



	}
	
	
		function mques169()
{

	document.getElementById('mquestion').innerHTML="Kung tawagin nila'y santo, hindi naman milagroso.";
	document.getElementById('ma').innerHTML="l";
	document.getElementById('ma').value="l";
	document.getElementById('mb').innerHTML="g";
	document.getElementById('mb').value="g";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="g";
	document.getElementById('md').value="g";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="b";
	document.getElementById('mj').value="b";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "santol";



	}

	
	

	
	function mques170()
{

	document.getElementById('mquestion').innerHTML="Bahay ni Mang Pedro, punung-puno ng bato.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="d";
	document.getElementById('me').value="d";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="p";
	document.getElementById('mi').value="p";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "papaya";



	}
	
	
	
	
	
		
		
	
		function mques171()
{

	document.getElementById('mquestion').innerHTML="Nakayuko ang reyna di nalalaglag ang korona.";
	document.getElementById('ma').innerHTML="b";
	document.getElementById('ma').value="b";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="b";
	document.getElementById('mj').value="b";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bayabas";



	}
	
	
	
		function mques172()
{

	document.getElementById('mquestion').innerHTML="Kumpul-kumpol na uling, hayon at bibitin-bitin.";
	document.getElementById('ma').innerHTML="h";
	document.getElementById('ma').value="h";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="d";
	document.getElementById('mj').value="d";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "duhat";



	}
	
	
	
	
		function mques173()
{

	document.getElementById('mquestion').innerHTML="Bunga na ay namumunga pa.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="b";
	document.getElementById('mc').value="b";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="u";
	document.getElementById('mi').value="u";
	document.getElementById('mj').innerHTML="g";
	document.getElementById('mj').value="g";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bunga";



	}
	
	
	
	
		function mques174()
{

	document.getElementById('mquestion').innerHTML="Tiningnan nang tiningnan. Bago ito nginitian.";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="h";
	document.getElementById('me').value="h";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mais";



	}
	
	
	
	
		function mques175()
{

	document.getElementById('mquestion').innerHTML="Isang magandang dalaga.‘Di mabilang ang mata.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="p";
	document.getElementById('mh').value="p";
	document.getElementById('mi').innerHTML="k";
	document.getElementById('mi').value="k";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pinya";



	}
	
	
	
	
		function mques176()
{

	document.getElementById('mquestion').innerHTML="Dumaan ang hari, nagkagatan ang mga pari.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="h";
	document.getElementById('mg').value="h";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="z";
	document.getElementById('mj').value="z";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "ziper";



	}
	
	
	
	
		function mques177()
{

	document.getElementById('mquestion').innerHTML="Dalawang batong itim, malayo ang nararating.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="y";
	document.getElementById('mc').value="y";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mata";



	}
	
	
	
	
	function mques178()
{

	document.getElementById('mquestion').innerHTML="Sa isang kalabit, may buhay na kapalit.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="b";
	document.getElementById('md').value="b";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "baril";



	}
	
	
		function mques179()
{

	document.getElementById('mquestion').innerHTML="Buto't balat na malapad, kay galing kung lumipad.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="g";
	document.getElementById('mb').value="g";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sarangola";



	}

	
	

	
	function mques180()
{

	document.getElementById('mquestion').innerHTML="Hinila ko ang baging, sumigaw ang matsing.";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="k";
	document.getElementById('mi').value="k";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kampana";



	}
	
	
	
	
	
		
	
		
		
	
		function mques181()
{

	document.getElementById('mquestion').innerHTML="Puno ay buku-buko, Dahon ay abaniko, Bunga ay parasko Perdegones ang mga buto.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="p";
	document.getElementById('mf').value="p";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="b";
	document.getElementById('mj').value="b";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "papaya";



	}
	
	
	
		function mques182()
{

	document.getElementById('mquestion').innerHTML="Hindi tao, hindi hayop, May tainga't may buhok.";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mais";



	}
	
	
	
	
		function mques183()
{

	document.getElementById('mquestion').innerHTML="Ang dalawa'y tatlo na, ang maitim ay puti na, ang bakod ay lagas na.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="b";
	document.getElementById('mc').value="b";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "matanda";



	}
	
	
	
	
		function mques184()
{

	document.getElementById('mquestion').innerHTML="Pantas ka man at maalam, Angkan ka ng mga paham Turan mo kung ano.";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "plantsa";



	}
	
	
	
	
		function mques185()
{

	document.getElementById('mquestion').innerHTML="Bahay ni Ligaya nalilibot ng mata.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="p";
	document.getElementById('mh').value="p";
	document.getElementById('mi').innerHTML="k";
	document.getElementById('mi').value="k";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pinya";



	}
	
	
	
	
		function mques186()
{

	document.getElementById('mquestion').innerHTML="Maitim na parang uwak Maputing parang busilak, Walang paa'y nakalalakad At sa hari'y nakikipag-usap.";
	document.getElementById('ma').innerHTML="h";
	document.getElementById('ma').value="h";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="e";
	document.getElementById('mf').value="e";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="u";
	document.getElementById('mh').value="u";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="z";
	document.getElementById('mj').value="z";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "liham";



	}
	
	
	
	
		function mques187()
{

	document.getElementById('mquestion').innerHTML="Bumuka'y walang bibig Ngumingiti nang tahimik.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="l";
	document.getElementById('mb').value="l";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="k";
	document.getElementById('me').value="k";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bulaklak";



	}
	
	
	
	
	function mques188()
{

	document.getElementById('mquestion').innerHTML="Isda ko sa Mariveles Nasa loob ang kaliskis.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "alimango";



	}
	
	
		function mques189()
{

	document.getElementById('mquestion').innerHTML="Oo nga't alimango Nasa loob ang ulo.";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="g";
	document.getElementById('mb').value="g";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pagong";



	}

	
	

	
	function mques190()
{

	document.getElementById('mquestion').innerHTML="Oo nga't pagong Tubig ay iniinom.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "niyog";



	}
	
	
	
	
	
		
	
		
		
	
		function mques191()
{

	document.getElementById('mquestion').innerHTML="Oo nga't niyog Nasa loob ang bunot.";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="g";
	document.getElementById('mf').value="g";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="b";
	document.getElementById('mj').value="b";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mangga";



	}
	
	
	
		function mques192()
{

	document.getElementById('mquestion').innerHTML="Oo nga't mangga Kay daming mga mata.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pinya";



	}
	
	
	
	
		function mques193()
{

	document.getElementById('mquestion').innerHTML="Puno'y layu-layo Dulo'y tagpu-tagpo.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="e";
	document.getElementById('mb').value="e";
	document.getElementById('mc').innerHTML="b";
	document.getElementById('mc').value="b";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="t";
	document.getElementById('me').value="t";
	document.getElementById('mf').innerHTML="y";
	document.getElementById('mf').value="y";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="h";
	document.getElementById('mj').value="h";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "bahay";



	}
	
	
	
	
		function mques194()
{

	document.getElementById('mquestion').innerHTML="Nakaluluto'y walang init, Umaaso kahi't malamig.";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="s";
	document.getElementById('mg').value="s";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="y";
	document.getElementById('mi').value="y";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "yelo";



	}
	
	
	
	
		function mques195()
{

	document.getElementById('mquestion').innerHTML="Hindi tao, hindi ibon Bumabalik kung itapon.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="k";
	document.getElementById('mi').value="k";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "yoyo";



	}
	
	
	
	
		function mques196()
{

	document.getElementById('mquestion').innerHTML="Eto na si bayaw Dala-dala'y ilaw.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="p";
	document.getElementById('mh').value="p";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "alitaptap";



	}
	
	
	
	
		function mques197()
{

	document.getElementById('mquestion').innerHTML="Eto na si Kaka May sunong na dampa.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pagong";



	}
	
	
	
	
	function mques198()
{

	document.getElementById('mquestion').innerHTML="Bahay ni Goring-goring Butas-butas ang dingding.";
	document.getElementById('ma').innerHTML="k";
	document.getElementById('ma').value="k";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="u";
	document.getElementById('mf').value="u";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kulambo";



	}
	
	
		function mques199()
{

	document.getElementById('mquestion').innerHTML="Alin sa mga ibon ang di makadapo sa kahoy?";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="g";
	document.getElementById('mb').value="g";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pugo";



	}

	
	

	
	function mques200()
{

	document.getElementById('mquestion').innerHTML="Gintong binalot sa pilak Pilak na binalot sa balat.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="n";
	document.getElementById('me').value="n";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "itlog";



	}
	
	
	
	
	
	
		
	
		function mques201()
{

	document.getElementById('mquestion').innerHTML="Mga kaloobang pinaghalu-halo na niluto sa init ng pagkakasundo.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="u";
	document.getElementById('mg').value="u";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="d";
	document.getElementById('mj').value="d";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "dinuguan";



	}
	
	
	
		function mques202()
{

	document.getElementById('mquestion').innerHTML="Di naman isda, di naman itik Nakahuhuni kung ibig maging sa kati, maging sa tubig ang huni'y nakabubuwisit.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "palaka";



	}
	
	
	
	
		function mques203()
{

	document.getElementById('mquestion').innerHTML="May puno walang sanga May dahon, walang bunga.";
	document.getElementById('ma').innerHTML="o";
	document.getElementById('ma').value="o";
	document.getElementById('mb').innerHTML="k";
	document.getElementById('mb').value="k";
	document.getElementById('mc').innerHTML="b";
	document.getElementById('mc').value="b";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="y";
	document.getElementById('mf').value="y";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="h";
	document.getElementById('mj').value="h";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sandok";



	}
	
	
	
	
		function mques204()
{

	document.getElementById('mquestion').innerHTML="Walang itak, walang kampit Gumagawa ng bahay na ipit.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="m";
	document.getElementById('mg').value="m";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="b";
	document.getElementById('mi').value="b";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "gagamba";



	}
	
	
	
	
		function mques205()
{

	document.getElementById('mquestion').innerHTML="Lumalakad walang paa Lumuluha walang mata.";
	document.getElementById('ma').innerHTML="u";
	document.getElementById('ma').value="u";
	document.getElementById('mb').innerHTML="w";
	document.getElementById('mb').value="w";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="p";
	document.getElementById('mi').value="p";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pluma";



	}
	
	
	
	
		function mques206()
{

	document.getElementById('mquestion').innerHTML="Dahong pinagbungahan, Bungang pinagdahunan.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="y";
	document.getElementById('mc').value="y";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="p";
	document.getElementById('mh').value="p";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pinya";



	}
	
	
	
	
		function mques207()
{

	document.getElementById('mquestion').innerHTML="Heto na si kurdapya may sunong na baga.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "manok";



	}
	
	
	
	
	function mques208()
{

	document.getElementById('mquestion').innerHTML="Isdang parang ahas, sa karagatan pumapagaspas.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="u";
	document.getElementById('mf').value="u";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "igat";



	}
	
	
		function mques209()
{

	document.getElementById('mquestion').innerHTML="May alaga akong hayop, malaki ang mata kaysa tuhod.";
	document.getElementById('ma').innerHTML="u";
	document.getElementById('ma').value="u";
	document.getElementById('mb').innerHTML="b";
	document.getElementById('mb').value="b";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="t";
	document.getElementById('mh').value="t";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "tutubi";



	}

	
	

	
	function mques210()
{

	document.getElementById('mquestion').innerHTML="Anong insekto sa mundo na naglalakad na walang buto.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "uod";



	}
	
	
	
	
		
		
	
		function mques211()
{

	document.getElementById('mquestion').innerHTML="Pinisa ko at pinirot bago sininghot.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="s";
	document.getElementById('mf').value="s";
	document.getElementById('mg').innerHTML="u";
	document.getElementById('mg').value="u";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "surot";



	}
	
	
	
		function mques212()
{

	document.getElementById('mquestion').innerHTML="Koronang mapula ay katulad nito lagi nang nakakabit sa ulo.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="y";
	document.getElementById('mj').value="y";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "palong";



	}
	
	
	
	
		function mques213()
{

	document.getElementById('mquestion').innerHTML="May puno walang sanga May dahon, walang bunga.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="b";
	document.getElementById('mc').value="b";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "pamingwit";



	}
	
	
	
	
		function mques214()
{

	document.getElementById('mquestion').innerHTML="Dumating si Canuto, nangabuhay ang mga tao.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="m";
	document.getElementById('mg').value="m";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="u";
	document.getElementById('mi').value="u";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "umaga";



	}
	
	
	
	
		function mques215()
{

	document.getElementById('mquestion').innerHTML="Kung araw ay patung-patong, kung gabi'y dugtong-dugtong.";
	document.getElementById('ma').innerHTML="u";
	document.getElementById('ma').value="u";
	document.getElementById('mb').innerHTML="n";
	document.getElementById('mb').value="n";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="o";
	document.getElementById('me').value="o";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "unan";



	}
	
	
	
	
		function mques216()
{

	document.getElementById('mquestion').innerHTML="Isang hukbong sundalo, dikit-dikit ang mga ulo,";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="y";
	document.getElementById('mc').value="y";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "walis";



	}
	
	
	
	
		function mques217()
{

	document.getElementById('mquestion').innerHTML="Dumaing paa'y walang kamay, may pamigkis sa baywang, ang ulo'y parang tagayan, alagad ng kalinisan.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "walis";



	}
	
	
	
	
	function mques218()
{

	document.getElementById('mquestion').innerHTML="Kung tingna'y mainit, hipui'y malamig, umuusok ang paligid.";
	document.getElementById('ma').innerHTML="e";
	document.getElementById('ma').value="e";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="y";
	document.getElementById('mf').value="y";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="g";
	document.getElementById('mi').value="g";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "yelo";



	}
	
	
		function mques219()
{

	document.getElementById('mquestion').innerHTML="Mayroon akong dalawang balon, hindi ko malingon.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="b";
	document.getElementById('mb').value="b";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="p";
	document.getElementById('md').value="p";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="t";
	document.getElementById('mh').value="t";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="t";
	document.getElementById('mj').value="t";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "tainga";



	}

	
	

	
	function mques220()
{

	document.getElementById('mquestion').innerHTML="Nang tangan ko'y patay, nang itapon ko'y nabuhay.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="r";
	document.getElementById('mi').value="r";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "trumpo";



	}
	
	
	
	
	
	
			
		
	
		function mques221()
{

	document.getElementById('mquestion').innerHTML="Binalangkas ko nang binalangkas, bago ko inihampas.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="p";
	document.getElementById('me').value="p";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="u";
	document.getElementById('mg').value="u";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="o";
	document.getElementById('mj').value="o";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "trumpo";



	}
	
	
	
		function mques222()
{

	document.getElementById('mquestion').innerHTML="Munting tumataginting, kung saan nanggagaling.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "telepono";



	}
	
	
	
	
		function mques223()
{

	document.getElementById('mquestion').innerHTML="Puno na naging tubig, tubig na naging bato, bato na kinain ng tao.";
	document.getElementById('ma').innerHTML="u";
	document.getElementById('ma').value="u";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="b";
	document.getElementById('mc').value="b";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="t";
	document.getElementById('mf').value="t";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="m";
	document.getElementById('mj').value="m";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "tubo";



	}
	
	
	
	
		function mques224()
{

	document.getElementById('mquestion').innerHTML="Ang ibabaw ay tawiran, ang ilalim ay lusutan.";
	document.getElementById('ma').innerHTML="y";
	document.getElementById('ma').value="y";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="m";
	document.getElementById('mg').value="m";
	document.getElementById('mh').innerHTML="l";
	document.getElementById('mh').value="l";
	document.getElementById('mi').innerHTML="u";
	document.getElementById('mi').value="u";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "tulay";



	}
	
	
	
	
		function mques225()
{

	document.getElementById('mquestion').innerHTML="Bulaklak muna ang dapat gawin, bago mo ito kanin. ";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="n";
	document.getElementById('mb').value="n";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "saging";



	}
	
	
	
	
		function mques226()
{

	document.getElementById('mquestion').innerHTML="Sapagkat lahat na ay nakahihipo, walang kasindumi't walang kasimbaho, bakit mahal nati't ipinakatatago.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="y";
	document.getElementById('mc').value="y";
	document.getElementById('md').innerHTML="w";
	document.getElementById('md').value="w";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "salapi";



	}
	
	
	
	
		function mques227()
{

	document.getElementById('mquestion').innerHTML="Aling mabuting retrato ang kuhang-kuha sa mukha mo? ";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="m";
	document.getElementById('mg').value="m";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "salamin";



	}
	
	
	
	
	function mques228()
{

	document.getElementById('mquestion').innerHTML="Sinampal ko muna bago inalok.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="k";
	document.getElementById('mf').value="k";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sampalok";



	}
	
	
		function mques229()
{

	document.getElementById('mquestion').innerHTML="Ang ulo'y nalalaga ang katawa'y pagala-gala.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="b";
	document.getElementById('mb').value="b";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="k";
	document.getElementById('mj').value="k";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sandok";



	}

	
	

	
	function mques230()
{

	document.getElementById('mquestion').innerHTML="Alipin ng hari, hindi makalakad, kung hindi itali.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="p";
	document.getElementById('mb').value="p";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="a";
	document.getElementById('mi').value="a";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sapatos";



	}
	
	
	
	
	
				
		
	
		function mques231()
{

	document.getElementById('mquestion').innerHTML="Baboy ko sa parang, namumula sa tapang.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="p";
	document.getElementById('me').value="p";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="u";
	document.getElementById('mg').value="u";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="l";
	document.getElementById('mj').value="l";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sili";



	}
	
	
	
		function mques232()
{

	document.getElementById('mquestion').innerHTML="Munting tampipi puno ng salapi.";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sili";



	}
	
	
	
	
		function mques233()
{

	document.getElementById('mquestion').innerHTML="Isang lupa-lupaan sa dulo ng kawayan.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="y";
	document.getElementById('mf').value="y";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sigarilyo";



	}
	
	
	
	
		function mques234()
{

	document.getElementById('mquestion').innerHTML="Hiyas akong mabilog, sa daliri isinusuot.";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="g";
	document.getElementById('mh').value="g";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "singsing";



	}
	
	
	
	
		function mques235()
{

	document.getElementById('mquestion').innerHTML="Buklod na tinampukan, saksi ng pag-iibigan.";
	document.getElementById('ma').innerHTML="g";
	document.getElementById('ma').value="g";
	document.getElementById('mb').innerHTML="n";
	document.getElementById('mb').value="n";
	document.getElementById('mc').innerHTML="m";
	document.getElementById('mc').value="m";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "singsing";



	}
	
	
	
	
		function mques236()
{

	document.getElementById('mquestion').innerHTML="Ipinalilok ko at ipinalubid, nang higpitan ang kapit.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="y";
	document.getElementById('mc').value="y";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="n";
	document.getElementById('mg').value="n";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="u";
	document.getElementById('mj').value="u";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sinturon";



	}
	
	
	
	
		function mques237()
{

	document.getElementById('mquestion').innerHTML="Nang munti pa ay paruparo, nang lumaki ay latigo.";
	document.getElementById('ma').innerHTML="t";
	document.getElementById('ma').value="t";
	document.getElementById('mb').innerHTML="s";
	document.getElementById('mb').value="s";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="m";
	document.getElementById('mg').value="m";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="i";
	document.getElementById('mj').value="i";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sitaw";



	}
	
	
	
	
	function mques238()
{

	document.getElementById('mquestion').innerHTML="Bumili ako ng alipin, mataas pa sa akin.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="s";
	document.getElementById('mc').value="s";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="r";
	document.getElementById('mf').value="r";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="b";
	document.getElementById('mh').value="b";
	document.getElementById('mi').innerHTML="m";
	document.getElementById('mi').value="m";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sumbrero";



	}
	
	
		function mques239()
{

	document.getElementById('mquestion').innerHTML="Isang tabo, laman ay pako.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="b";
	document.getElementById('mb').value="b";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="s";
	document.getElementById('md').value="s";
	document.getElementById('me').innerHTML="u";
	document.getElementById('me').value="u";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="h";
	document.getElementById('mi').value="h";
	document.getElementById('mj').innerHTML="k";
	document.getElementById('mj').value="k";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "suha";



	}

	
	

	
	function mques240()
{

	document.getElementById('mquestion').innerHTML="Isang panyong parisukat, kung buksa'y nakakausap.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "sulat";



	}
	
	
	
	
	
					
		
	
		function mques241()
{

	document.getElementById('mquestion').innerHTML="Dalawang magkaibigan, habulan nang habulan. ";
	document.getElementById('ma').innerHTML="s";
	document.getElementById('ma').value="s";
	document.getElementById('mb').innerHTML="i";
	document.getElementById('mb').value="i";
	document.getElementById('mc').innerHTML="u";
	document.getElementById('mc').value="u";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="p";
	document.getElementById('me').value="p";
	document.getElementById('mf').innerHTML="m";
	document.getElementById('mf').value="m";
	document.getElementById('mg').innerHTML="u";
	document.getElementById('mg').value="u";
	document.getElementById('mh').innerHTML="y";
	document.getElementById('mh').value="y";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="a";
	document.getElementById('mj').value="a";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "paa";



	}
	
	
	
		function mques242()
{

	document.getElementById('mquestion').innerHTML="May ulo'y walang mukha, may katawa'y walang sikmura. Namamahay ng sadya. ";
	document.getElementById('ma').innerHTML="i";
	document.getElementById('ma').value="i";
	document.getElementById('mb').innerHTML="t";
	document.getElementById('mb').value="t";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="l";
	document.getElementById('md').value="l";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="i";
	document.getElementById('mg').value="i";
	document.getElementById('mh').innerHTML="k";
	document.getElementById('mh').value="k";
	document.getElementById('mi').innerHTML="o";
	document.getElementById('mi').value="o";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "palito";



	}
	
	
	
	
		function mques243()
{

	document.getElementById('mquestion').innerHTML="Binatak ko ang isa, pawis ang kasama.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="n";
	document.getElementById('mb').value="n";
	document.getElementById('mc').innerHTML="r";
	document.getElementById('mc').value="r";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="y";
	document.getElementById('mf').value="y";
	document.getElementById('mg').innerHTML="o";
	document.getElementById('mg').value="o";
	document.getElementById('mh').innerHTML="i";
	document.getElementById('mh').value="i";
	document.getElementById('mi').innerHTML="w";
	document.getElementById('mi').value="w";
	document.getElementById('mj').innerHTML="s";
	document.getElementById('mj').value="s";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "panyo";



	}
	
	
	
	
		function mques244()
{

	document.getElementById('mquestion').innerHTML="Ang puno'y buku-buko,ang sanga'y baril, ang bunga'y bote, ang laman ay diyamante.";
	document.getElementById('ma').innerHTML="p";
	document.getElementById('ma').value="p";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="g";
	document.getElementById('mc').value="g";
	document.getElementById('md').innerHTML="n";
	document.getElementById('md').value="n";
	document.getElementById('me').innerHTML="a";
	document.getElementById('me').value="a";
	document.getElementById('mf').innerHTML="h";
	document.getElementById('mf').value="h";
	document.getElementById('mg').innerHTML="y";
	document.getElementById('mg').value="y";
	document.getElementById('mh').innerHTML="a";
	document.getElementById('mh').value="a";
	document.getElementById('mi').innerHTML="i";
	document.getElementById('mi').value="i";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "papaya";



	}
	
	
	
	
		function mques245()
{

	document.getElementById('mquestion').innerHTML="Ang labas ay tabla-tabla ang loob ay sala-sala.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="t";
	document.getElementById('mc').value="t";
	document.getElementById('md').innerHTML="i";
	document.getElementById('md').value="i";
	document.getElementById('me').innerHTML="g";
	document.getElementById('me').value="g";
	document.getElementById('mf').innerHTML="i";
	document.getElementById('mf').value="i";
	document.getElementById('mg').innerHTML="l";
	document.getElementById('mg').value="l";
	document.getElementById('mh').innerHTML="o";
	document.getElementById('mh').value="o";
	document.getElementById('mi').innerHTML="n";
	document.getElementById('mi').value="n";
	document.getElementById('mj').innerHTML="p";
	document.getElementById('mj').value="p";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "patola";



	}
	
	
	
	
		function mques246()
{

	document.getElementById('mquestion').innerHTML="Dalawang bolang sinulid, abot hanggang langit. ";
	document.getElementById('ma').innerHTML="m";
	document.getElementById('ma').value="m";
	document.getElementById('mb').innerHTML="o";
	document.getElementById('mb').value="o";
	document.getElementById('mc').innerHTML="y";
	document.getElementById('mc').value="y";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="i";
	document.getElementById('me').value="i";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="s";
	document.getElementById('mh').value="s";
	document.getElementById('mi').innerHTML="t";
	document.getElementById('mi').value="t";
	document.getElementById('mj').innerHTML="u";
	document.getElementById('mj').value="u";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "mata";



	}
	
	
	
	
		function mques247()
{

	document.getElementById('mquestion').innerHTML="Araw araw bagong buhay, Taun-taon namamatay. ";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="y";
	document.getElementById('mb').value="y";
	document.getElementById('mc').innerHTML="o";
	document.getElementById('mc').value="o";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="r";
	document.getElementById('me').value="r";
	document.getElementById('mf').innerHTML="l";
	document.getElementById('mf').value="l";
	document.getElementById('mg').innerHTML="e";
	document.getElementById('mg').value="e";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="d";
	document.getElementById('mi').value="d";
	document.getElementById('mj').innerHTML="k";
	document.getElementById('mj').value="k";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kalendaryo";



	}
	
	
	
	
	function mques248()
{

	document.getElementById('mquestion').innerHTML="Ako'y aklat ng panahon, Binabago taun taon.";
	document.getElementById('ma').innerHTML="r";
	document.getElementById('ma').value="r";
	document.getElementById('mb').innerHTML="a";
	document.getElementById('mb').value="a";
	document.getElementById('mc').innerHTML="k";
	document.getElementById('mc').value="k";
	document.getElementById('md').innerHTML="o";
	document.getElementById('md').value="o";
	document.getElementById('me').innerHTML="y";
	document.getElementById('me').value="y";
	document.getElementById('mf').innerHTML="d";
	document.getElementById('mf').value="d";
	document.getElementById('mg').innerHTML="a";
	document.getElementById('mg').value="a";
	document.getElementById('mh').innerHTML="n";
	document.getElementById('mh').value="n";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="e";
	document.getElementById('mj').value="e";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kalendaryo";



	}
	
	
		function mques249()
{

	document.getElementById('mquestion').innerHTML="May katawan walang mukha, walang mata'y lumuluha.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="b";
	document.getElementById('mb').value="b";
	document.getElementById('mc').innerHTML="i";
	document.getElementById('mc').value="i";
	document.getElementById('md').innerHTML="a";
	document.getElementById('md').value="a";
	document.getElementById('me').innerHTML="l";
	document.getElementById('me').value="l";
	document.getElementById('mf').innerHTML="n";
	document.getElementById('mf').value="n";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="h";
	document.getElementById('mi').value="h";
	document.getElementById('mj').innerHTML="k";
	document.getElementById('mj').value="k";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "kandila";



	}

	
	

	
	function mques250()
{

	document.getElementById('mquestion').innerHTML="Dalawang katawan, tagusan ang tadyang.";
	document.getElementById('ma').innerHTML="a";
	document.getElementById('ma').value="a";
	document.getElementById('mb').innerHTML="u";
	document.getElementById('mb').value="u";
	document.getElementById('mc').innerHTML="n";
	document.getElementById('mc').value="n";
	document.getElementById('md').innerHTML="t";
	document.getElementById('md').value="t";
	document.getElementById('me').innerHTML="s";
	document.getElementById('me').value="s";
	document.getElementById('mf').innerHTML="a";
	document.getElementById('mf').value="a";
	document.getElementById('mg').innerHTML="g";
	document.getElementById('mg').value="g";
	document.getElementById('mh').innerHTML="d";
	document.getElementById('mh').value="d";
	document.getElementById('mi').innerHTML="l";
	document.getElementById('mi').value="l";
	document.getElementById('mj').innerHTML="h";
	document.getElementById('mj').value="h";	
	document.getElementById("mnumero").innerHTML = "riddle no: " + mnumb;

mright_ans = "hagdan";



	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function msubmit()
{
document.getElementById("mdito").innerHTML = "";


 

if(msagot==mright_ans)
{
mscore++;
mnumb++;

document.getElementById("mscore").innerHTML = "score: " + mscore;
document.getElementById("mans").innerHTML = "";
alert("You are Correct!!!");



if(mnumb == 6 || mnumb == 11 || mnumb == 16 || mnumb == 21 || mnumb == 26 || mnumb == 31 || mnumb == 36 || mnumb == 41 || mnumb == 46 || mnumb == 51 || mnumb == 56 || mnumb == 61 || mnumb == 66 || mnumb == 71 || mnumb == 76 || mnumb == 81 || mnumb == 86 || mnumb == 91 || mnumb == 96 || mnumb == 101 || mnumb == 106 || mnumb == 111 || mnumb == 116 || mnumb == 121 || mnumb == 126 || mnumb == 131 || mnumb == 136 || mnumb == 141 || mnumb == 146 || mnumb == 151 || mnumb == 156 || mnumb == 161 || mnumb == 166 || mnumb == 171 || mnumb == 176 || mnumb == 181 || mnumb == 186 || mnumb == 191 || mnumb == 196 || mnumb == 201 || mnumb == 206 || mnumb == 211 || mnumb == 216 || mnumb == 221 || mnumb == 226 || mnumb == 231 || mnumb == 236 || mnumb == 241 || mnumb == 246)
{

$("#mhint").show(1500);
$("#mhint2").show(1500);
$("#mhint3").show(1500);


$("#f_mhint").hide();
$("#f_mhint2").hide();
$("#f_mhint3").hide();

}




mp++;
msagot = "";

if(mnumb>250)
{
document.getElementById("msubmit").href = "#winner_m_u";

document.getElementById("fscore_m_u").innerHTML = "score: " + mscore;
}

else{
start_m_u();}
}
else
{



mlife--;


if (mlife == 0){$("#mlif3").hide();}

document.getElementById("mscore").innerHTML = "score: " + mscore;
document.getElementById("mans").innerHTML = "";
alert("You are Wrong!!!");





if (mlife == 2){$("#mlif1").hide(1500);


}
else if (mlife == 1){$("#mlif2").hide(1500);


}







if(mlife == 0)
{

document.getElementById("msubmit").href = "#exit_m_u";

document.getElementById("gfscore_m_u").innerHTML = "score: " + mscore;

}


else{


mnumb++;

mp++;

msagot = "";

if(mnumb == 6 || mnumb == 11 || mnumb == 16 || mnumb == 21 || mnumb == 26 || mnumb == 31 || mnumb == 36 || mnumb == 41 || mnumb == 46 || mnumb == 51 || mnumb == 56 || mnumb == 61 || mnumb == 66 || mnumb == 71 || mnumb == 76 || mnumb == 81 || mnumb == 86 || mnumb == 91 || mnumb == 96 || mnumb == 101 || mnumb == 106 || mnumb == 111 || mnumb == 116 || mnumb == 121 || mnumb == 126 || mnumb == 131 || mnumb == 136 || mnumb == 141 || mnumb == 146 || mnumb == 151 || mnumb == 156 || mnumb == 161 || mnumb == 166 || mnumb == 171 || mnumb == 176 || mnumb == 181 || mnumb == 186 || mnumb == 191 || mnumb == 196 || mnumb == 201 || mnumb == 206 || mnumb == 211 || mnumb == 216 || mnumb == 221 || mnumb == 226 || mnumb == 231 || mnumb == 236 || mnumb == 241 || mnumb == 246)
{

$("#mhint").show(1500);
$("#mhint2").show(1500);
$("#mhint3").show(1500);


$("#f_mhint").hide();
$("#f_mhint2").hide();
$("#f_mhint3").hide();

}


if(mnumb>250)
{
document.getElementById("msubmit").href = "#winner_m_u";

document.getElementById("fscore_m_u").innerHTML = "score: " + mscore;
}
start_m_u();
}

}
changeColor3();

}


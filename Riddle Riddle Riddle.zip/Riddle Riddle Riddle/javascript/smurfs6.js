var mpt = 1 ;
var manst = "" ;
var msagott = "";
var mright_anst = "" ;
var mscoret = 0;
var mnumbt = 1;
var s3 = 59;
var m3 = 9;
var q3;
var let_num6 = "";





function bura6()
{
var dine = msagott.length - 1;

msagott = msagott.substring(0,dine);
document.getElementById("manst").innerHTML = msagott;

var dindin = let_num6.length - 1;
var pj = let_num6.charAt(dindin);
if(pj == "a")
{$("#mat").show(200);
let_num6 = let_num6.substring(0,dindin);
}
else if(pj == "b")
{$("#mbt").show(200);
let_num6 = let_num6.substring(0,dindin);}
else if(pj == "c")
{$("#mct").show(200);
let_num6 = let_num6.substring(0,dindin);}
else if(pj == "d")
{$("#mdt").show(200);
let_num6 = let_num6.substring(0,dindin);}
else if(pj == "e")
{$("#met").show(200);
let_num6 = let_num6.substring(0,dindin);}
else if(pj == "f")
{$("#mft").show(200);
let_num6 = let_num6.substring(0,dindin);}
else if(pj == "g")
{$("#mgt").show(200);
let_num6 = let_num6.substring(0,dindin);}
else if(pj == "h")
{$("#mht").show(200);
let_num6 = let_num6.substring(0,dindin);}
else if(pj == "i")
{$("#mit").show(200);
let_num6 = let_num6.substring(0,dindin);}
else if(pj == "j")
{$("#mjt").show(200);
let_num6 = let_num6.substring(0,dindin);}




}


























function homing6()
{
  var x;
    if (confirm("You want to quit?") == true) {
 document.getElementById("6home_b").href =  "#page1";
  } else {
 document.getElementById("6home_b").href =  "";
    }
}












$(document).ready(function(){
$("#mat").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#mbt").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#mct").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#mdt").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#met").click(function(){
$(this).hide(200);
});
});








$(document).ready(function(){
$("#mft").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#mgt").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#mht").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#mit").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#mjt").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#mresett,#msubmitt").click(function(){
$("#mat,#mct,#mbt,#mdt,#met,#mgt,#mft,#mht,#mit,#mjt").show(200);
});
});





function tgokay_m_u()
{
var mpt = 1 ;
var manst = "" ;
var msagott = "";
var mright_anst = "" ;
var mscoret = 0;
var mnumbt = 1;
var s3 = 59;
var m3 = 1;
var q3;


}




function tcokay_m_u()
{
var mpt = 1 ;
var manst = "" ;
var msagott = "";
var mright_anst = "" ;
var mscoret = 0;
var mnumbt = 1;
var s3 = 59;
var m3 = 1;
var q3;


}



function tstart_m_u()
{


var random = Math.floor(Math.random()*2);
if(random==0){random++;}

$("#mgameover").hide();


if(mpt==1)
	{
		
	mtquest1();
times3();
	}
	else if(mpt==2)
	{
		
	mtquest2();

	}
	else if(mpt==3)
		
	{
	mtquest3();

	}

	else if(mpt==4)
		
	{
	mtquest4();

	}
	else if(mpt==5)
		
	{
	mtquest5();

	}

	else if(mpt==6)
		
	{
	mtquest6();

	}
	else if(mpt==7)
		
	{
	mtquest7();

	}
	else if(mpt==8)
		
	{
	mtquest8();

	}
	else if(mpt==9)
		
	{
	mtquest9();

	}
	else if(mpt==10)
		
	{
	mtquest10();

	}




	else if(mpt==11)
	{
		
	mtquest11();

	}
	else if(mpt==12)
	{
		
	mtquest12();

	}
	else if(mpt==13)
		
	{
	mtquest13();

	}

	else if(mpt==14)
		
	{
	mtquest14();

	}
	else if(mpt==15)
		
	{
	mtquest15();

	}

	else if(mpt==16)
		
	{
	mtquest16();

	}
	else if(mpt==17)
		
	{
	mtquest17();

	}
	else if(mpt==18)
		
	{
	mtquest18();

	}
	else if(mpt==19)
		
	{
	mtquest19();

	}
	else if(mpt==20)
		
	{
	mtquest20();

	}

	

	else if(mpt==21)
	{
		
	mtquest21();

	}
	else if(mpt==22)
	{
		
	mtquest22();

	}
	else if(mpt==23)
		
	{
	mtquest23();

	}

	else if(mpt==24)
		
	{
	mtquest24();

	}
	else if(mpt==25)
		
	{
	mtquest25();

	}

	else if(mpt==26)
		
	{
	mtquest26();

	}
	else if(mpt==27)
		
	{
	mtquest27();

	}
	else if(mpt==28)
		
	{
	mtquest28();

	}
	else if(mpt==29)
		
	{
	mtquest29();

	}
	else if(mpt==30)
		
	{
	mtquest30();

	}



	else if(mpt==31)
	{
		
	mtquest31();

	}
	else if(mpt==32)
	{
		
	mtquest32();

	}
	else if(mpt==33)
		
	{
	mtquest33();

	}

	else if(mpt==34)
		
	{
	mtquest34();

	}
	else if(mpt==35)
		
	{
	mtquest35();

	}

	else if(mpt==36)
		
	{
	mtquest36();

	}
	else if(mpt==37)
		
	{
	mtquest37();

	}
	else if(mpt==38)
		
	{
	mtquest38();

	}
	else if(mpt==39)
		
	{
	mtquest39();

	}
	else if(mpt==40)
		
	{
	mtquest40();

	}




	else if(mpt==41)
	{
		
	mtquest41();

	}
	else if(mpt==42)
	{
		
	mtquest42();

	}
	else if(mpt==43)
		
	{
	mtquest43();

	}

	else if(mpt==44)
		
	{
	mtquest44();

	}
	else if(mpt==45)
		
	{
	mtquest45();

	}

	else if(mpt==46)
		
	{
	mtquest46();

	}
	else if(mpt==47)
		
	{
	mtquest47();

	}
	else if(mpt==48)
		
	{
	mtquest48();

	}
	else if(mpt==49)
		
	{
	mtquest49();

	}
	else if(mpt==50)
		
	{
	mtquest50();

	}

	
		
	else if(mpt==51)
	{
		
	mtquest51();

	}
	else if(mpt==52)
	{
		
	mtquest52();

	}
	else if(mpt==53)
		
	{
	mtquest53();

	}

	else if(mpt==54)
		
	{
	mtquest54();

	}
	else if(mpt==55)
		
	{
	mtquest55();

	}

	else if(mpt==56)
		
	{
	mtquest56();

	}
	else if(mpt==57)
		
	{
	mtquest57();

	}
	else if(mpt==58)
		
	{
	mtquest58();

	}
	else if(mpt==59)
		
	{
	mtquest59();

	}
	else if(mpt==60)
		
	{
	mtquest60();

	}
	
	
	else if(mpt==61)
	{
		
	mtquest61();

	}
	else if(mpt==62)
	{
		
	mtquest62();

	}
	else if(mpt==63)
		
	{
	mtquest63();

	}

	else if(mpt==64)
		
	{
	mtquest64();

	}
	else if(mpt==65)
		
	{
	mtquest65();

	}

	else if(mpt==66)
		
	{
	mtquest66();

	}
	else if(mpt==67)
		
	{
	mtquest67();

	}
	else if(mpt==68)
		
	{
	mtquest68();

	}
	else if(mpt==69)
		
	{
	mtquest69();

	}
	else if(mpt==70)
		
	{
	mtquest70();

	}
	
	
	else if(mpt==71)
	{
		
	mtquest71();

	}
	else if(mpt==72)
	{
		
	mtquest72();

	}
	else if(mpt==73)
		
	{
	mtquest73();

	}

	else if(mpt==74)
		
	{
	mtquest74();

	}
	else if(mpt==75)
		
	{
	mtquest75();

	}

	else if(mpt==76)
		
	{
	mtquest76();

	}
	else if(mpt==77)
		
	{
	mtquest77();

	}
	else if(mpt==78)
		
	{
	mtquest78();

	}
	else if(mpt==79)
		
	{
	mtquest79();

	}
	else if(mpt==80)
		
	{
	mtquest80();

	}
	
	
	else if(mpt==81)
	{
		
	mtquest81();

	}
	else if(mpt==82)
	{
		
	mtquest82();

	}
	else if(mpt==83)
		
	{
	mtquest83();

	}

	else if(mpt==84)
		
	{
	mtquest84();

	}
	else if(mpt==85)
		
	{
	mtquest85();

	}

	else if(mpt==86)
		
	{
	mtquest86();

	}
	else if(mpt==87)
		
	{
	mtquest87();

	}
	else if(mpt==88)
		
	{
	mtquest88();

	}
	else if(mpt==89)
		
	{
	mtquest89();

	}
	else if(mpt==90)
		
	{
	mtquest90();

	}
	
	
	
	
	else if(mpt==91)
	{
		
	mtquest91();

	}
	else if(mpt==92)
	{
		
	mtquest92();

	}
	else if(mpt==93)
		
	{
	mtquest93();

	}

	else if(mpt==94)
		
	{
	mtquest94();

	}
	else if(mpt==95)
		
	{
	mtquest95();

	}

	else if(mpt==96)
		
	{
	mtquest96();

	}
	else if(mpt==97)
		
	{
	mtquest97();

	}
	else if(mpt==98)
		
	{
	mtquest98();

	}
	else if(mpt==99)
		
	{
	mtquest99();

	}
	else if(mpt==100)
		
	{
	mtquest100();

	}
	
	
	

	else if(mpt==101)
	{
		
	mtquest101();

	}
	else if(mpt==102)
	{
		
	mtquest102();

	}
	else if(mpt==103)
		
	{
	mtquest103();

	}

	else if(mpt==104)
		
	{
	mtquest104();

	}
	else if(mpt==105)
		
	{
	mtquest105();

	}

	else if(mpt==106)
		
	{
	mtquest106();

	}
	else if(mpt==107)
		
	{
	mtquest107();

	}
	else if(mpt==108)
		
	{
	mtquest108();

	}
	else if(mpt==109)
		
	{
	mtquest109();

	}
	else if(mpt==110)
		
	{
	mtquest110();

	}

	

	else if(mpt==111)
	{
		
	mtquest111();

	}
	else if(mpt==112)
	{
		
	mtquest112();

	}
	else if(mpt==113)
		
	{
	mtquest113();

	}

	else if(mpt==114)
		
	{
	mtquest114();

	}
	else if(mpt==115)
		
	{
	mtquest115();

	}

	else if(mpt==116)
		
	{
	mtquest116();

	}
	else if(mpt==117)
		
	{
	mtquest117();

	}
	else if(mpt==118)
		
	{
	mtquest118();

	}
	else if(mpt==119)
		
	{
	mtquest119();

	}
	else if(mpt==120)
		
	{
	mtquest120();

	}

	else if(mpt==121)
	{
		
	mtquest121();

	}
	else if(mpt==122)
	{
		
	mtquest122();

	}
	else if(mpt==123)
		
	{
	mtquest123();

	}

	else if(mpt==124)
		
	{
	mtquest124();

	}
	else if(mpt==125)
		
	{
	mtquest125();

	}

	else if(mpt==126)
		
	{
	mtquest126();

	}
	else if(mpt==127)
		
	{
	mtquest127();

	}
	else if(mpt==128)
		
	{
	mtquest128();

	}
	else if(mpt==129)
		
	{
	mtquest129();

	}
	else if(mpt==130)
		
	{
	mtquest130();

	}
	
	
	else if(mpt==131)
	{
		
	mtquest131();

	}
	else if(mpt==132)
	{
		
	mtquest132();

	}
	else if(mpt==133)
		
	{
	mtquest133();

	}

	else if(mpt==134)
		
	{
	mtquest134();

	}
	else if(mpt==135)
		
	{
	mtquest135();

	}

	else if(mpt==136)
		
	{
	mtquest136();

	}
	else if(mpt==137)
		
	{
	mtquest137();

	}
	else if(mpt==138)
		
	{
	mtquest138();

	}
	else if(mpt==139)
		
	{
	mtquest139();

	}
	else if(mpt==140)
		
	{
	mtquest140();

	}
	
	
	
	else if(mpt==141)
	{
		
	mtquest141();

	}
	else if(mpt==142)
	{
		
	mtquest142();

	}
	else if(mpt==143)
		
	{
	mtquest143();

	}

	else if(mpt==144)
		
	{
	mtquest144();

	}
	else if(mpt==145)
		
	{
	mtquest145();

	}

	else if(mpt==146)
		
	{
	mtquest146();

	}
	else if(mpt==147)
		
	{
	mtquest147();

	}
	else if(mpt==148)
		
	{
	mtquest148();

	}
	else if(mpt==149)
		
	{
	mtquest149();

	}
	else if(mpt==150)
		
	{
	mtquest150();

	}
	
	
	
	
	else if(mpt==151)
	{
		
	mtquest151();

	}
	else if(mpt==152)
	{
		
	mtquest152();

	}
	else if(mpt==153)
		
	{
	mtquest153();

	}

	else if(mpt==154)
		
	{
	mtquest154();

	}
	else if(mpt==155)
		
	{
	mtquest155();

	}

	else if(mpt==156)
		
	{
	mtquest156();

	}
	else if(mpt==157)
		
	{
	mtquest157();

	}
	else if(mpt==158)
		
	{
	mtquest158();

	}
	else if(mpt==159)
		
	{
	mtquest159();

	}
	else if(mpt==160)
		
	{
	mtquest160();

	}
	
	
	else if(mpt==161)
	{
		
	mtquest161();

	}
	else if(mpt==162)
	{
		
	mtquest162();

	}
	else if(mpt==163)
		
	{
	mtquest163();

	}

	else if(mpt==164)
		
	{
	mtquest164();

	}
	else if(mpt==165)
		
	{
	mtquest165();

	}

	else if(mpt==166)
		
	{
	mtquest166();

	}
	else if(mpt==167)
		
	{
	mtquest167();

	}
	else if(mpt==168)
		
	{
	mtquest168();

	}
	else if(mpt==169)
		
	{
	mtquest169();

	}
	else if(mpt==170)
		
	{
	mtquest170();

	}
	
	
	else if(mpt==171)
	{
		
	mtquest171();

	}
	else if(mpt==172)
	{
		
	mtquest172();

	}
	else if(mpt==173)
		
	{
	mtquest173();

	}

	else if(mpt==174)
		
	{
	mtquest174();

	}
	else if(mpt==175)
		
	{
	mtquest175();

	}

	else if(mpt==176)
		
	{
	mtquest176();

	}
	else if(mpt==177)
		
	{
	mtquest177();

	}
	else if(mpt==178)
		
	{
	mtquest178();

	}
	else if(mpt==179)
		
	{
	mtquest179();

	}
	else if(mpt==180)
		
	{
	mtquest180();

	}
	
	
	else if(mpt==181)
	{
		
	mtquest181();

	}
	else if(mpt==182)
	{
		
	mtquest182();

	}
	else if(mpt==183)
		
	{
	mtquest183();

	}

	else if(mpt==184)
		
	{
	mtquest184();

	}
	else if(mpt==185)
		
	{
	mtquest185();

	}

	else if(mpt==186)
		
	{
	mtquest186();

	}
	else if(mpt==187)
		
	{
	mtquest187();

	}
	else if(mpt==188)
		
	{
	mtquest188();

	}
	else if(mpt==189)
		
	{
	mtquest189();

	}
	else if(mpt==190)
		
	{
	mtquest190();

	}
	
	
	
	
	else if(mpt==191)
	{
		
	mtquest191();

	}
	else if(mpt==192)
	{
		
	mtquest192();

	}
	else if(mpt==193)
		
	{
	mtquest193();

	}

	else if(mpt==194)
		
	{
	mtquest194();

	}
	else if(mpt==195)
		
	{
	mtquest195();

	}

	else if(mpt==196)
		
	{
	mtquest196();

	}
	else if(mpt==197)
		
	{
	mtquest197();

	}
	else if(mpt==198)
		
	{
	mtquest198();

	}
	else if(mpt==199)
		
	{
	mtquest199();

	}
	else if(mpt==200)
		
	{
	mtquest200();

	}
	
	
	
	
	else if(mpt==201)
	{
		
	mtquest201();

	}
	
	else if(mpt==202)
	{
		
	mtquest202();

	}
	else if(mpt==203)
		
	{
	mtquest203();

	}

	else if(mpt==204)
		
	{
	mtquest204();

	}
	else if(mpt==205)
		
	{
	mtquest205();

	}

	else if(mpt==206)
		
	{
	mtquest206();

	}
	else if(mpt==207)
		
	{
	mtquest207();

	}
	else if(mpt==208)
		
	{
	mtquest208();

	}
	else if(mpt==209)
		
	{
	mtquest209();

	}
	else if(mpt==210)
		
	{
	mtquest210();

	}


	else if(mpt==211)
	{
		
	mtquest211();

	}
	else if(mpt==212)
	{
		
	mtquest212();

	}
	else if(mpt==213)
		
	{
	mtquest213();

	}

	else if(mpt==214)
		
	{
	mtquest214();

	}
	else if(mpt==215)
		
	{
	mtquest215();

	}

	else if(mpt==216)
		
	{
	mtquest216();

	}
	else if(mpt==217)
		
	{
	mtquest217();

	}
	else if(mpt==218)
		
	{
	mtquest218();

	}
	else if(mpt==219)
		
	{
	mtquest219();

	}
	else if(mpt==220)
		
	{
	mtquest220();

	}

	
	else if(mpt==221)
	{
		
	mtquest221();

	}
	else if(mpt==222)
	{
		
	mtquest222();

	}
	else if(mpt==223)
		
	{
	mtquest223();

	}

	else if(mpt==224)
		
	{
	mtquest224();

	}
	else if(mpt==225)
		
	{
	mtquest225();

	}

	else if(mpt==226)
		
	{
	mtquest226();

	}
	else if(mpt==227)
		
	{
	mtquest227();

	}
	else if(mpt==228)
		
	{
	mtquest228();

	}
	else if(mpt==229)
		
	{
	mtquest229();

	}
	else if(mpt==230)
		
	{
	mtquest230();

	}

	
	else if(mpt==231)
	{
		
	mtquest231();

	}
	else if(mpt==232)
	{
		
	mtquest232();

	}
	else if(mpt==233)
		
	{
	mtquest233();

	}

	else if(mpt==234)
		
	{
	mtquest234();

	}
	else if(mpt==235)
		
	{
	mtquest235();

	}

	else if(mpt==236)
		
	{
	mtquest236();

	}
	else if(mpt==237)
		
	{
	mtquest237();

	}
	else if(mpt==238)
		
	{
	mtquest238();

	}
	else if(mpt==239)
		
	{
	mtquest239();

	}
	else if(mpt==240)
		
	{
	mtquest240();

	}


	else if(mpt==241)
	{
		
	mtquest241();

	}
	else if(mpt==242)
	{
		
	mtquest242();

	}
	else if(mpt==243)
		
	{
	mtquest243();

	}

	else if(mpt==244)
		
	{
	mtquest244();

	}
	else if(mpt==245)
		
	{
	mtquest245();

	}

	else if(mpt==246)
		
	{
	mtquest246();

	}
	else if(mpt==247)
		
	{
	mtquest247();

	}
	else if(mpt==248)
		
	{
	mtquest248();

	}
	else if(mpt==249)
		
	{
	mtquest249();

	}
	else if(mpt==250)
		
	{
	mtquest250();

	}

	
	
	
	
	
	
	
	
	

}






	
	
function mat()
{


var a = document.getElementById("mat").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "a";
}


	
function mbt()
{


var a = document.getElementById("mbt").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "b";
}



function mct()
{


var a = document.getElementById("mct").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "c";
}





function mdt()
{


var a = document.getElementById("mdt").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "d";
}



function met()
{

var a = document.getElementById("met").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "e";
}



function mft()
{

var a = document.getElementById("mft").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "f";
}

function mgt()
{

var a = document.getElementById("mgt").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "g";
}

function mht()
{

var a = document.getElementById("mht").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "h";
}

function mit()
{

var a = document.getElementById("mit").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "i";
}

function mjt()
{

var a = document.getElementById("mjt").value;

msagott = msagott + a;

document.getElementById("manst").innerHTML = msagott;
let_num6 = let_num6 + "j";
}




function mresett()
{


msagott = "";

document.getElementById("manst").innerHTML = msagott;
}




function mtquest1()
{

	document.getElementById('mquestiont').innerHTML="Baston ng kapitan, Hindi mahawakan.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="c";
	document.getElementById('mbt').value="c";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="y";
	document.getElementById('mgt').value="y";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="h";
	document.getElementById('mit').value="h";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "ahas";




	}

	
	
	
function mtquest142()
{

	document.getElementById('mquestiont').innerHTML="Heto na si kuya, May sunong sa baga";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="t";
	document.getElementById('mct').value="t";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="p";
	document.getElementById('mft').value="p";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "alitaptap";




	}

	
	
	
	
	
	
function mtquest3()
{

	document.getElementById('mquestiont').innerHTML="Ang loob ay pilak, Siit namimilipit, Ginto't pilak namumulaklak.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="y";
	document.getElementById('mct').value="y";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="d";
	document.getElementById('mft').value="d";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "ampalaya";


	}

	
	
	
	
	
function mtquest144()
{

	document.getElementById('mquestiont').innerHTML="Ako'y may kaibigan, Kasama ko kahit saan, Mapatubig ay di nalulunod, Mapaapoy ay di nasusunog.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "anino";



	}

	
			
		function mtquest5()
{

	document.getElementById('mquestiont').innerHTML="Hindi hayop, hindi tao, Hindi natin kaano-ano, Ate nating pareho.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="d";
	document.getElementById('mit').value="d";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "atis";


	}

	
	
	
	
	
	
	
	
		function mtquest146()
{

	document.getElementById('mquestiont').innerHTML= "Tubig na nagiging bato, Bato na nagiging tubig.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "asin";



	}

	
	
		
		function mtquest7()
{

	document.getElementById('mquestiont').innerHTML= "Mataas ang paupo, Kesa patayo.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="o";
	document.getElementById('mgt').value="o";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "aso";




	}

	
	
		
		function mtquest148()
{

	document.getElementById('mquestiont').innerHTML="Dinadala ko siya, Dinadala ako niya.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="y";
	document.getElementById('mft').value="y";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bakya";


	}

	
	
			
		function mtquest9()
{

	document.getElementById('mquestiont').innerHTML="Alin dito sa buong lupa, Kung lumakad ay tihaya.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="k";
	document.getElementById('mit').value="k";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bangka";



	}

	
	
	
				
		function mtquest150()
{

	document.getElementById('mquestiont').innerHTML="Nakalantay kung gabi, Kung araw ay nakatabi.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="x";
	document.getElementById('mgt').value="x";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "banig";


	}

	
		
				
		function mtquest11()
{

	document.getElementById('mquestiont').innerHTML="Walang bibig, walang pakpak, kahit hari'y kinakausap?";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="x";
	document.getElementById('mgt').value="x";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "aklat";


	}

	
	
				
		function mtquest141()
{

	document.getElementById('mquestiont').innerHTML="Isang biyas ng kawayan, Maraming lamang kayamanan ";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="s";
	document.getElementById('mgt').value="s";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="y";
	document.getElementById('mit').value="y";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "alkansya";


	}

	
			function mtquest13()
{

	document.getElementById('mquestiont').innerHTML="Heto , heto na, Malayo pa’y humahalakhak na. ";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="c";
	document.getElementById('mct').value="c";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="y";
	document.getElementById('mit').value="y";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "alon";


	}

	
	
	
		
			function mtquest143()
{

	document.getElementById('mquestiont').innerHTML="Pagkatapos na ang reyna'y Makapagpagawa ng templo, Siya na rin ang napreso.";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="c";
	document.getElementById('mct').value="c";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="y";
	document.getElementById('mit').value="y";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "anay";


	}

	
	
	
	
		
			function mtquest15()
{

	document.getElementById('mquestiont').innerHTML="Mayroon akong matapat na alipin, Sunod nang sunod sa akin.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "anino";


	}

	
	
		
		
			function mtquest145()
{

	document.getElementById('mquestiont').innerHTML="Manok kong pula, Inutusan ko ng umaga, Nang umuwi'y gabi na.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="r";
	document.getElementById('mdt').value="r";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="w";
	document.getElementById('mht').value="w";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "araw";


	}

	
	
			
		
			function mtquest17()
{

	document.getElementById('mquestiont').innerHTML="Buhay na hiram lamang, Pinagmulan ng sangkatauhan. ";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="r";
	document.getElementById('mdt').value="r";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="d";
	document.getElementById('mit').value="d";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "babae";


	}

	
	
	
			
			function mtquest147()
{

	document.getElementById('mquestiont').innerHTML="Tubig kung sa isda, Lungga kung sa daga, Kung sa tao'y ano kaya.";
	document.getElementById('mat').innerHTML="x";
	document.getElementById('mat').value="x";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="d";
	document.getElementById('mit').value="d";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bahay";


	}

	
	
	
			
			function mtquest19()
{

	document.getElementById('mquestiont').innerHTML="Kung dumating ang bisita ko, Dumarating din ang sa inyo.";
	document.getElementById('mat').innerHTML="w";
	document.getElementById('mat').value="w";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="x";
	document.getElementById('mjt').value="x";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "araw";



	}

	
	
		
			
			function mtquest149()
{

	document.getElementById('mquestiont').innerHTML="Isang biyas ng kawayan, Ang laman ay kamatayan.";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="k";
	document.getElementById('mgt').value="k";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "baril";


	}

	
	
	
				
			function mtquest21()
{

	document.getElementById('mquestiont').innerHTML="May katawa'y walang bituka, May puwit walang paa, Nakakagat tuwina.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="o";
	document.getElementById('met').value="o";
	document.getElementById('mft').innerHTML="m";
	document.getElementById('mft').value="m";
	document.getElementById('mgt').innerHTML="p";
	document.getElementById('mgt').value="p";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="k";
	document.getElementById('mit').value="k";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "baso";


	}

	
	
				
			function mtquest22()
{

	document.getElementById('mquestiont').innerHTML="Buhay na hindi kumikibo, Patay na hindi bumabaho.";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="m";
	document.getElementById('mft').value="m";
	document.getElementById('mgt').innerHTML="o";
	document.getElementById('mgt').value="o";
	document.getElementById('mht').innerHTML="s";
	document.getElementById('mht').value="s";
	document.getElementById('mit').innerHTML="x";
	document.getElementById('mit').value="x";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bato";


	}

		
	
	
		
				
			function mtquest23()
{

	document.getElementById('mquestiont').innerHTML="Isang balong malalim, Punong-puno ng patalim.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="m";
	document.getElementById('mft').value="m";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="c";
	document.getElementById('mht').value="c";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bibig";


	}

		
					
			function mtquest24()
{

	document.getElementById('mquestiont').innerHTML="Palayok ni isko, Punong-puno ng bato.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="y";
	document.getElementById('mdt').value="y";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="d";
	document.getElementById('mjt').value="d";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bayabas";


	}

		
	
	
						
			function mtquest25()
{

	document.getElementById('mquestiont').innerHTML="Nagsasaing si pusong, Sa ibabaw ang tutong.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bibingka";


	}

		
	
	
						
			function mtquest26()
{

	document.getElementById('mquestiont').innerHTML="Alin sa buong katawan, Nasa likod ang tiyan.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="n";
	document.getElementById('mct').value="n";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="x";
	document.getElementById('mit').value="x";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "binti";


	}

		
	
							
			function mtquest27()
{

	document.getElementById('mquestiont').innerHTML="Itinanim sa kagabihan, Inani sa kaumagahan.";
	document.getElementById('mat').innerHTML="u";
	document.getElementById('mat').value="u";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="x";
	document.getElementById('mit').value="x";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bituin";


	}

		
								
			function mtquest28()
{

	document.getElementById('mquestiont').innerHTML="Kung di pa sa liig pinigilan, Di pa ako bibigyan.";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bote";


	}


		
								
			function mtquest29()
{

	document.getElementById('mquestiont').innerHTML="Kung sa ilan walang kwenta, Sa gusali mahalaga. ";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bato";


	}

				
	
		
								
			function mtquest29()
{

	document.getElementById('mquestiont').innerHTML="Kung sa ilan walang kwenta, Sa gusali mahalaga. ";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bato";


	}

				
	
	
	
		
								
			function mtquest30()
{

	document.getElementById('mquestiont').innerHTML="Heto na si lulong, Bubulong bulong.";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="o";
	document.getElementById('mft').value="o";
	document.getElementById('mgt').innerHTML="y";
	document.getElementById('mgt').value="y";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bubuyog";


	}

				
	
	
								
			function mtquest31()
{

	document.getElementById('mquestiont').innerHTML="Inisip ng marunong, Sinabi ng gunggong.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="o";
	document.getElementById('mft').value="o";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bugtong";


	}

				
	
	
								
			function mtquest32()
{

	document.getElementById('mquestiont').innerHTML="Nagsaing si kuruktong, Kumuloy walang gatong.";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="m";
	document.getElementById('mft').value="m";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sabon";


	}
	
	
							
			function mtquest33()
{

	document.getElementById('mquestiont').innerHTML="Isang pinggan, laganapSa buong bayan.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="m";
	document.getElementById('mbt').value="m";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="w";
	document.getElementById('mft').value="w";
	document.getElementById('mgt').innerHTML="k";
	document.getElementById('mgt').value="k";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="r";
	document.getElementById('mjt').value="r";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "buwan";


	}

	
		function mtquest34()
{

	document.getElementById('mquestiont').innerHTML="Mahabang-mahaba, tinutungtungan ng madla.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="d";
	document.getElementById('met').value="d";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="d";
	document.getElementById('mgt').value="d";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="h";
	document.getElementById('mjt').value="h";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "daan";


	}
	
	
	
	
	
	
		function mtquest35()
{

	document.getElementById('mquestiont').innerHTML="Nagtanim ako ng dayap, sa gitna ng dagat, marami ang nagsihanap, iisa ang nagkapalad.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="d";
	document.getElementById('met').value="d";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="d";
	document.getElementById('mgt').value="d";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "dalaga";


	}
	
	
	
		function mtquest36()
{

	document.getElementById('mquestiont').innerHTML="Limang punong niyog, iisa ang matayog.";
	document.getElementById('mat').innerHTML="w";
	document.getElementById('mat').value="w";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="h";
	document.getElementById('mdt').value="h";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="d";
	document.getElementById('mgt').value="d";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "daliri";


	}
	
	
		function mtquest37()
{

	document.getElementById('mquestiont').innerHTML="Munting uling, bibitin-bitin, masarap kanin, mahirap kunin.";
	document.getElementById('mat').innerHTML="d";
	document.getElementById('mat').value="d";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="h";
	document.getElementById('mdt').value="h";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="d";
	document.getElementById('mgt').value="d";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "duhat";


	}


	
		function mtquest38()
{

	document.getElementById('mquestiont').innerHTML="Nang maliit ay kastila, nang tumanda ay baluga.";
	document.getElementById('mat').innerHTML="d";
	document.getElementById('mat').value="d";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "duling";


	}

	
		function mtquest39()
{

	document.getElementById('mquestiont').innerHTML="Takbo roon, takbo rito, hindi makaalis sa tayong ito.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="m";
	document.getElementById('mct').value="m";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "duyan";


	}

	
	
		function mtquest40()
{

	document.getElementById('mquestiont').innerHTML="Isang hayop na maliit, dumudumi ng sinulid.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="m";
	document.getElementById('mbt').value="m";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "gagamba";


	}


	
	
		function mtquest41()
{

	document.getElementById('mquestiont').innerHTML="Bahay ni San Vicente , punong-puno ng diamante.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "granada";



	}

	
	
		function mtquest42()
{

	document.getElementById('mquestiont').innerHTML="Bahay ni San Vicente , punong-puno ng diamante.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "granada";


	}

	
		function mtquest43()
{

	document.getElementById('mquestiont').innerHTML="Nagsaing si kurukutong, bumubula’y walang gatong.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "gugo";


	}

	
	
		function mtquest44()
{

	document.getElementById('mquestiont').innerHTML="Aso kong si pula, sumampa sa sanga, nag pakita ng ganda.";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "gumamela";


	}

	
	
		function mtquest45()
{

	document.getElementById('mquestiont').innerHTML="Heto na si kaka, bibika-bikaka.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="n";
	document.getElementById('mct').value="n";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "gunting";


	}


	
		function mtquest46()
{

	document.getElementById('mquestiont').innerHTML="Dalawang katawan, tagusan ang tadyang.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="d";
	document.getElementById('mft').value="d";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "hagdan";



	}
	
	
		function mtquest47()
{

	document.getElementById('mquestiont').innerHTML="Karga ng karga; walang renta.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="y";
	document.getElementById('mbt').value="y";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="d";
	document.getElementById('mft').value="d";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "haligi";


	}



	
	
	
	function mtquest48()
{

	document.getElementById('mquestiont').innerHTML="Heto na, heto na, di mo nakikita.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="h";
	document.getElementById('mbt').value="h";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="p";
	document.getElementById('mft').value="p";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="j";
	document.getElementById('mit').value="j";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "hangin";


	}

	
	
	
	function mtquest49()
{

	document.getElementById('mquestiont').innerHTML="Dalawang ibong marikit, nagmitimbangan ng siit.";
	document.getElementById('mat').innerHTML="w";
	document.getElementById('mat').value="w";
	document.getElementById('mbt').innerHTML="h";
	document.getElementById('mbt').value="h";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="h";
	document.getElementById('mit').value="h";
	document.getElementById('mjt').innerHTML="x";
	document.getElementById('mjt').value="x";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "hikaw";


	}
	
	
	
	function mtquest50()
{

	document.getElementById('mquestiont').innerHTML="Isang butil ng palay, buong bahay ay nakakalatan.";
	document.getElementById('mat').innerHTML="w";
	document.getElementById('mat').value="w";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="y";
	document.getElementById('mit').value="y";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "ilaw";


	}

	
	function mtquest51()
{

	document.getElementById('mquestiont').innerHTML="Dalawang libing, laging may hangin.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="g";
	document.getElementById('mft').value="g";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "ilong";


	}

	
	
	
	function mtquest52()
{

	document.getElementById('mquestiont').innerHTML="Bahay ni Kiko, walang bintana, walang pinto.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "itlog";



	}


	
	
	function mtquest53()
{

	document.getElementById('mquestiont').innerHTML="Binili ko nang di kagustuhan,Ginamit ko nang di nalalaman.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kabaong";


	}

	
		
	function mtquest54()
{

	document.getElementById('mquestiont').innerHTML="May binti walang hita,May tuktok walang mukha.";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="u";
	document.getElementById('mit').value="u";
	document.getElementById('mjt').innerHTML="r";
	document.getElementById('mjt').value="r";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kabute";


	}

	
	
		
	function mtquest55()
{

	document.getElementById('mquestiont').innerHTML="Ang ina’y gumagapang pa, Ang anak ay umuupo na.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="s";
	document.getElementById('mft').value="s";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kalabasa";


	}
	
	
	function mtquest56()
{

	document.getElementById('mquestiont').innerHTML="Araw araw bagong buhay,Taun-taon namamatay.";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="d";
	document.getElementById('mct').value="d";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="r";
	document.getElementById('mht').value="r";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kalendaryo";


	}
	
	
	function mtquest57()
{

	document.getElementById('mquestiont').innerHTML="Putukan nang putukan,hindi nag kakarinigan.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="p";
	document.getElementById('mct').value="p";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kampana";


	}
	
	
	
	function mtquest58()
{

	document.getElementById('mquestiont').innerHTML="Akoy ma’y kasama sa pahingi ng awa; ako’y di umiyak, siya ay lumuha.";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kandila";


	}
	
	
	
	function mtquest59()
{

	document.getElementById('mquestiont').innerHTML="Isang senyora,nakaupo sa tasa.";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="s";
	document.getElementById('mft').value="s";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="c";
	document.getElementById('mjt').value="c";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kasoy";

	}
	
	
	function mtquest60()
{

	document.getElementById('mquestiont').innerHTML="Anong halaman ang sagana sa ugat, dahon, at sanga,ngunit wala sa bunga.";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="f";
	document.getElementById('mdt').value="f";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="w";
	document.getElementById('mjt').value="w";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kawayan";


	}
	
	
	
	
	function mtquest61()
{

	document.getElementById('mquestiont').innerHTML="Ma-tag-init, ma-tag-ulan,dala-dala’y balutan.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="s";
	document.getElementById('mdt').value="s";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kuba";


	}
	
	
	
	function mtquest62()
{

	document.getElementById('mquestiont').innerHTML="Naabot na ng kamay,iginawa pa ng tulay.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="s";
	document.getElementById('mdt').value="s";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="y";
	document.getElementById('mjt').value="y";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kubyertos";


	}
	
	
	function mtquest63()
{

	document.getElementById('mquestiont').innerHTML="Limang mag kakapatid,tig-tig-isa ng silid.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="y";
	document.getElementById('mdt').value="y";
	document.getElementById('met').innerHTML="k";
	document.getElementById('met').value="k";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="k";
	document.getElementById('mgt').value="k";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kuko";


	}
	
	
	
	
	function mtquest64()
{

	document.getElementById('mquestiont').innerHTML="May hita ay walang binti,may ngipin ay walang labi.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="d";
	document.getElementById('mct').value="d";
	document.getElementById('mdt').innerHTML="r";
	document.getElementById('mdt').value="r";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="k";
	document.getElementById('mgt').value="k";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kudkuran";



	}
	
	
	
	
	function mtquest65()
{

	document.getElementById('mquestiont').innerHTML="Maliit pa si kumara,marunong ng humuni.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kuliglig";


	}
	
	
	
	function mtquest66()
{

	document.getElementById('mquestiont').innerHTML="Baka ko sa Maynila abot dito ang unga.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="u";
	document.getElementById('mht').value="u";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="y";
	document.getElementById('mjt').value="y";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kulog";


	}
	
	
		function mtquest67()
{

	document.getElementById('mquestiont').innerHTML="Aling paa ang nasa ulo?";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="u";
	document.getElementById('mht').value="u";
	document.getElementById('mit').innerHTML="d";
	document.getElementById('mit').value="d";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kuto";


	}
	
	
		function mtquest68()
{

	document.getElementById('mquestiont').innerHTML="Kadena’y isinabit,sa batok nakakawit.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="w";
	document.getElementById('mbt').value="w";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="u";
	document.getElementById('mht').value="u";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kwintas";


	}
	
	
	function mtquest69()
{

	document.getElementById('mquestiont').innerHTML="Kung saan masikip doon nagpipilit.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="v";
	document.getElementById('mjt').value="v";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "labong";


	}
	
	
	
	function mtquest70()
{

	document.getElementById('mquestiont').innerHTML="Itulak at hilahin,sigurado ang kain.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="r";
	document.getElementById('mht').value="r";
	document.getElementById('mit').innerHTML="k";
	document.getElementById('mit').value="k";
	document.getElementById('mjt').innerHTML="y";
	document.getElementById('mjt').value="y";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "lagari";


	}
	
	
	
	function mtquest71()
{

	document.getElementById('mquestiont').innerHTML="Butas na tinagpian ng kapuwa butas.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "lambat";


	}
	
	
	
	function mtquest72()
{

	document.getElementById('mquestiont').innerHTML="Kung kailan tahimik saka nambubuwisit.";
	document.getElementById('mat').innerHTML="h";
	document.getElementById('mat').value="h";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "lamok";


	}
	
	
	function mtquest73()
{

	document.getElementById('mquestiont').innerHTML="Naghain si Lolo,unang dumulog ang tukso.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="w";
	document.getElementById('mjt').value="w";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "langaw";


	}
	
	
	function mtquest74()
{

	document.getElementById('mquestiont').innerHTML="Baboy ko sa Marungko,balahibo'y pako.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="z";
	document.getElementById('mft').value="z";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "langka";


	}
	
	
	
	function mtquest75()
{

	document.getElementById('mquestiont').innerHTML="Munting-munti lang na hayop uliran sa pag-impok.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="g";
	document.getElementById('mbt').value="g";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="z";
	document.getElementById('mft').value="z";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "langgam";


	}
	
	
	function mtquest76()
{

	document.getElementById('mquestiont').innerHTML="Aso kong si puti,inutusan ko'y hindi na umuwi.";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="y";
	document.getElementById('mdt').value="y";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="w";
	document.getElementById('mit').value="w";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "laway";


	}
	
	
	function mtquest77()
{

	document.getElementById('mquestiont').innerHTML="Mayroon akong gatang,hindi ko matingnan.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="j";
	document.getElementById('mht').value="j";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "leeg";


	}
	
	
	
	
	function mtquest78()
{

	document.getElementById('mquestiont').innerHTML="Nahihiya, walang kinahihiyaan.";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="k";
	document.getElementById('mgt').value="k";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "makahiya";


	}
	
	
	
	
	function mtquest79()
{

	document.getElementById('mquestiont').innerHTML="May sunong, may kilik, may salakab sa puwit.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="j";
	document.getElementById('mgt').value="j";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="f";
	document.getElementById('mit').value="f";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mais";

	}
	
	
	
	
	function mtquest80()
{

	document.getElementById('mquestiont').innerHTML="Pusong bibitin-bitin,mabangong parang hasmin,masarap kanin.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="g";
	document.getElementById('mft').value="g";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mangga";


	}
	
	
	
	function mtquest81()
{

	document.getElementById('mquestiont').innerHTML="Pusong bibitin-bitin,mabangong parang hasmin,masarap kanin.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="g";
	document.getElementById('mft').value="g";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mangga";


	}
	
	
	
		
	function mtquest82()
{

	document.getElementById('mquestiont').innerHTML="Tag-ulan at tag-arawhanggang tuhod ng salawal.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="g";
	document.getElementById('mft').value="g";
	document.getElementById('mgt').innerHTML="o";
	document.getElementById('mgt').value="o";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "manok";


	}
	
	
	
	function mtquest83()
{

	document.getElementById('mquestiont').innerHTML="Dalawang bolang sinulid,abot hanggang langit.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="j";
	document.getElementById('mct').value="j";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="o";
	document.getElementById('mgt').value="o";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mata";

	}
	
	
	function mtquest84()
{

	document.getElementById('mquestiont').innerHTML="Ang mukha'y parang tao,magaling lumukso.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="j";
	document.getElementById('mct').value="j";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "matsing";


	}
	
	
	
	function mtquest85()
{

	document.getElementById('mquestiont').innerHTML="Kastila kung natutulog kapag gising ay tagalog.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mantika";


	}
	
	
	function mtquest86()
{

	document.getElementById('mquestiont').innerHTML="Maliit pa si Tsikito,marunong nang manukso.";
	document.getElementById('mat').innerHTML="l";
	document.getElementById('mat').value="l";
	document.getElementById('mbt').innerHTML="q";
	document.getElementById('mbt').value="q";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="y";
	document.getElementById('mft').value="y";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "lamok";


	}
	
	
	function mtquest87()
{

	document.getElementById('mquestiont').innerHTML="Noong bata ay nag saya,at naghubo nung dalaga.";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="y";
	document.getElementById('mbt').value="y";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="w";
	document.getElementById('met').value="w";
	document.getElementById('mft').innerHTML="y";
	document.getElementById('mft').value="y";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kawayan";


	}
	
	
	
		
	function mtquest88()
{

	document.getElementById('mquestiont').innerHTML="Nang aking mapatay,lalong humaba ang buhay.";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kandila";


	}
	
	
	function mtquest89()
{

	document.getElementById('mquestiont').innerHTML="Bugtong-bugtong,Magkakarugtong.";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "tanikala";


	}
	
	
	
		function mtquest90()
{

	document.getElementById('mquestiont').innerHTML="Bahay ni Kiko, walang bintana, walang pinto.";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="m";
	document.getElementById('mit').value="m";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "itlog";


	}
	
	
	
	
	
		function mtquest91()
{

	document.getElementById('mquestiont').innerHTML="Dalawang magkaibigan, may talim ang tiyan; matagal ng nagkakagatan di pa nagkakasakitan.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="g";
	document.getElementById('mbt').value="g";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "gunting";


	}
	
	
	
		function mtquest92()
{

	document.getElementById('mquestiont').innerHTML="Malaki kung bata, maliit kung matanda dahil sa kahahasa.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="m";
	document.getElementById('mbt').value="m";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "itak";


	}
	
	
	
	
		function mtquest93()
{

	document.getElementById('mquestiont').innerHTML="nagbabahay si maitim, walang haliging itinanim.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "gagamba";


	}
	
	
	
	
		function mtquest94()
{

	document.getElementById('mquestiont').innerHTML="Kung di pa sa liig pinigilan, Di pa ako bibigyan.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bote";


	}
	
	
	
	
		function mtquest95()
{

	document.getElementById('mquestiont').innerHTML="Itinanim sa kagabihan, Inani sa kaumagahan.";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="t";
	document.getElementById('mct').value="t";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="u";
	document.getElementById('mht').value="u";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bituin";


	}
	
	
	
	
		function mtquest96()
{

	document.getElementById('mquestiont').innerHTML="Alin sa buong katawan, Nasa likod ang tiyan.";
	document.getElementById('mat').innerHTML="j";
	document.getElementById('mat').value="j";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="t";
	document.getElementById('mct').value="t";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="u";
	document.getElementById('mht').value="u";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "binti";


	}
	
	
	
	
		function mtquest97()
{

	document.getElementById('mquestiont').innerHTML="Nagsasaing si pusong, Sa ibabaw ang tutong.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="q";
	document.getElementById('mct').value="q";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bibingka";


	}
	
	
	
	
	function mtquest98()
{

	document.getElementById('mquestiont').innerHTML="Buhay na hindi kumikibo, Patay na hindi bumabaho.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="g";
	document.getElementById('mbt').value="g";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="o";
	document.getElementById('mgt').value="o";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bato";


	}
	
	
		function mtquest99()
{

	document.getElementById('mquestiont').innerHTML="Nakalantay kung gabi, Kung araw ay nakatabi.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="g";
	document.getElementById('mbt').value="g";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="b";
	document.getElementById('mdt').value="b";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="y";
	document.getElementById('mgt').value="y";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "banig";


	}

	
	

	
	function mtquest100()
{

	document.getElementById('mquestiont').innerHTML="Tubig na nagiging bato, Bato na nagiging tubig.";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="p";
	document.getElementById('met').value="p";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="s";
	document.getElementById('mgt').value="s";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "asin";


	}
	
	
	
								
		function mtquest101()
{

	document.getElementById('mquestiont').innerHTML="It is an insect and the first part of it's name is the name of another insect. What is it?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "beetle";



	}
	
	
	
	
	
								
		function mtquest102()
{

	document.getElementById('mquestiont').innerHTML="What becomes white when it is dirty?";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="c";
	document.getElementById('mct').value="c";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "blackboard";



	}
	
	
	
								
		function mtquest103()
{

	document.getElementById('mquestiont').innerHTML="What word of five letters has only left when two letters are removed?";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="h";
	document.getElementById('met').value="h";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "stone";



	}
	
	
								
		function mtquest104()
{

	document.getElementById('mquestiont').innerHTML="Which vehicle is spelled the same forwards and backwards?";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="d";
	document.getElementById('met').value="d";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="r";
	document.getElementById('mht').value="r";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "racecar";



	}
	
	
	
	
								
		function mtquest105()
{

	document.getElementById('mquestiont').innerHTML="I am lighter than air but a million men cannot lift me up. What am I?";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="w";
	document.getElementById('mdt').value="w";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="s";
	document.getElementById('mgt').value="s";
	document.getElementById('mht').innerHTML="u";
	document.getElementById('mht').value="u";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="h";
	document.getElementById('mjt').value="h";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "bubble";



	}
	
	
	
		
				
								
		function mtquest106()
{

	document.getElementById('mquestiont').innerHTML="It is everything to someone, and nothing to everyone else. What is it?";
	document.getElementById('mat').innerHTML="d";
	document.getElementById('mat').value="d";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="n";
	document.getElementById('mct').value="n";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="m";
	document.getElementById('mit').value="m";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mind";



	}
	
	
	
	
				
								
		function mtquest107()
{

	document.getElementById('mquestiont').innerHTML="Forward I am heavy, backwards I am not. What am I?";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="w";
	document.getElementById('mjt').value="w";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "not";



	}
	
	
	
	
								
		function mtquest108()
{

	document.getElementById('mquestiont').innerHTML="What object has keys that open no locks, space but no room, and you can enter but not go in?";
	document.getElementById('mat').innerHTML="d";
	document.getElementById('mat').value="d";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="y";
	document.getElementById('mft').value="y";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="k";
	document.getElementById('mit').value="k";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "keyboard";



	}
	
	
	
	
								
		function mtquest109()
{

	document.getElementById('mquestiont').innerHTML="What bone has a sense of humor?";
	document.getElementById('mat').innerHTML="f";
	document.getElementById('mat').value="f";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="s";
	document.getElementById('mft').value="s";
	document.getElementById('mgt').innerHTML="d";
	document.getElementById('mgt').value="d";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="u";
	document.getElementById('mit').value="u";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "humorous";



	}
	
	
	
	
								
		function mtquest110()
{

	document.getElementById('mquestiont').innerHTML="What turns everything around, but does not move?";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="c";
	document.getElementById('mht').value="c";
	document.getElementById('mit').innerHTML="m";
	document.getElementById('mit').value="m";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mirror";



	}
	
	
	
	
		
	
	
	
	
								
		function mtquest111()
{

	document.getElementById('mquestiont').innerHTML="What is half of two plus two?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "three";



	}
	
	
	
	
	
								
		function mtquest112()
{

	document.getElementById('mquestiont').innerHTML="What word looks the same upside down and backwards?";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="c";
	document.getElementById('mct').value="c";
	document.getElementById('mdt').innerHTML="w";
	document.getElementById('mdt').value="w";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "swims";



	}
	
	
	
								
		function mtquest113()
{

	document.getElementById('mquestiont').innerHTML="What’s the difference between here and there?";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="h";
	document.getElementById('met').value="h";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "t";



	}
	
	
								
		function mtquest114()
{

	document.getElementById('mquestiont').innerHTML="What sits in a corner while traveling all around the world?";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="m";
	document.getElementById('mbt').value="m";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="d";
	document.getElementById('met').value="d";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="s";
	document.getElementById('mht').value="s";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "stamp";



	}
	
	
	
	
								
		function mtquest115()
{

	document.getElementById('mquestiont').innerHTML=" What body part is pronounced as one letter but written three, only two different letters are used?";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="u";
	document.getElementById('mdt').value="u";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="s";
	document.getElementById('mgt').value="s";
	document.getElementById('mht').innerHTML="u";
	document.getElementById('mht').value="u";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "eye";



	}
	
	
	
		
				
								
		function mtquest116()
{

	document.getElementById('mquestiont').innerHTML="What keeps things green and keeps kids occupied in the summertime";
	document.getElementById('mat').innerHTML="l";
	document.getElementById('mat').value="l";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="n";
	document.getElementById('mct').value="n";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sprinkler";



	}
	
	
	
	
				
								
		function mtquest117()
{

	document.getElementById('mquestiont').innerHTML="A shower that lights up the sky";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "meteor";



	}
	
	
	
	
								
		function mtquest118()
{

	document.getElementById('mquestiont').innerHTML="Longer than a decade and shorter than a millennium";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="c";
	document.getElementById('mit').value="c";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "century";



	}
	
	
	
	
								
		function mtquest119()
{

	document.getElementById('mquestiont').innerHTML="I never was, am always to be. No one ever saw me, nor ever will. And yet I am the confidence of all, To live and breath on this terrestrial ball. What am I?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="s";
	document.getElementById('mft').value="s";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="u";
	document.getElementById('mit').value="u";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "future";



	}
	
	
	
	
								
		function mtquest120()
{

	document.getElementById('mquestiont').innerHTML="What has a head, a tail, and has no legs?";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="c";
	document.getElementById('mht').value="c";
	document.getElementById('mit').innerHTML="m";
	document.getElementById('mit').value="m";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "coin";



	}
	
	
		
		
	
	
								
		function mtquest121()
{

	document.getElementById('mquestiont').innerHTML="Each morning I appear to lie at your feet, All day I will follow no matter how fast you run, Yet I nearly perish in the midday sun.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="w";
	document.getElementById('mjt').value="w";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "shadow";



	}
	
	
	
	
	
								
		function mtquest122()
{

	document.getElementById('mquestiont').innerHTML="My life can be measured in hours, I serve by being devoured. Thin, I am quick Fat, I am slow Wind is my foe.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="c";
	document.getElementById('mct').value="c";
	document.getElementById('mdt').innerHTML="w";
	document.getElementById('mdt').value="w";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="d";
	document.getElementById('mgt').value="d";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "candle";



	}
	
	
	
								
		function mtquest123()
{

	document.getElementById('mquestiont').innerHTML="I am seen in the water if seen in the sky, I am in the rainbow.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="h";
	document.getElementById('met').value="h";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "blue";



	}
	
	
								
		function mtquest124()
{

	document.getElementById('mquestiont').innerHTML="Three lives have I. Gentle enough to soothe the skin, Light enough to caress the sky, Hard enough to crack rocks.";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="d";
	document.getElementById('met').value="d";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="w";
	document.getElementById('mht').value="w";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="r";
	document.getElementById('mjt').value="r";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "water";



	}
	
	
	
	
								
		function mtquest125()
{

	document.getElementById('mquestiont').innerHTML="Two in a corner, 1 in a room, 0 in a house, but 1 in a shelter. What am I?";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="u";
	document.getElementById('mdt').value="u";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="s";
	document.getElementById('mgt').value="s";
	document.getElementById('mht').innerHTML="u";
	document.getElementById('mht').value="u";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "r";



	}
	
	
	
		
				
								
		function mtquest126()
{

	document.getElementById('mquestiont').innerHTML="It cannot be seen, it weighs nothing, but when put into a barrel, it makes it lighter. What is it?";
	document.getElementById('mat').innerHTML="l";
	document.getElementById('mat').value="l";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="n";
	document.getElementById('mct').value="n";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="o";
	document.getElementById('met').value="o";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "hole";



	}
	
	
	
	
				
								
		function mtquest127()
{

	document.getElementById('mquestiont').innerHTML="I can be long, or I can be short. I can be grown, and I can be bought. I can be painted, or left bare. I can be round, or square. What am I?";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "nail";



	}
	
	
	
	
								
		function mtquest128()
{

	document.getElementById('mquestiont').innerHTML="Soft and fragile is my skin, I get my growth in mud I'm dangerous as much as pretty, for if not careful, I draw blood.";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "thorn";



	}
	
	
	
	
								
		function mtquest129()
{

	document.getElementById('mquestiont').innerHTML="My first is twice in apple but not once in tart. My second is in liver but not in heart. My third is in giant and also in ghost. Whole I'm best when I am roast. What am I?";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="p";
	document.getElementById('met').value="p";
	document.getElementById('mft').innerHTML="s";
	document.getElementById('mft').value="s";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="u";
	document.getElementById('mit').value="u";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "pig";



	}
	
	
	
	
								
		function mtquest130()
{

	document.getElementById('mquestiont').innerHTML="A mile from end to end, yet as close to as a friend. A precious commodity, freely given. What is it?";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="c";
	document.getElementById('mht').value="c";
	document.getElementById('mit').innerHTML="m";
	document.getElementById('mit').value="m";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "smile";



	}
	
	
		
			
	
	
								
		function mtquest131()
{

	document.getElementById('mquestiont').innerHTML="Alive without breath, As cold as death, Never thirsty, Ever drinking, Drowns on dry land.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="f";
	document.getElementById('mct').value="f";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="w";
	document.getElementById('mjt').value="w";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "fish";



	}
	
	
	
	
	
								
		function mtquest132()
{

	document.getElementById('mquestiont').innerHTML="Die without me, Never thank me. Walk right through me, never feel me. Always watching, never speaking. Always lurking, never seen.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="c";
	document.getElementById('mct').value="c";
	document.getElementById('mdt').innerHTML="w";
	document.getElementById('mdt').value="w";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "air";



	}
	
	
	
								
		function mtquest133()
{

	document.getElementById('mquestiont').innerHTML="Take one out and scratch my head, I am now black but once was red.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="m";
	document.getElementById('met').value="m";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="h";
	document.getElementById('mgt').value="h";
	document.getElementById('mht').innerHTML="c";
	document.getElementById('mht').value="c";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "match";



	}
	
	
								
		function mtquest134()
{

	document.getElementById('mquestiont').innerHTML="Only two backbones and thousands of ribs.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="d";
	document.getElementById('met').value="d";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="w";
	document.getElementById('mht').value="w";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "railroad";



	}
	
	
	
	
								
		function mtquest135()
{

	document.getElementById('mquestiont').innerHTML="Big as a biscuit, deep as a cup, Even a river can't fill it up. What is it?";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="s";
	document.getElementById('mgt').value="s";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "strainer";



	}
	
	
	
		
				
								
		function mtquest136()
{

	document.getElementById('mquestiont').innerHTML="It is greater than God and more evil than the devil. The poor have it, the rich need it and if you eat it you'll die. What is it?";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="n";
	document.getElementById('mct').value="n";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "nothing";



	}
	
	
	
	
				
								
		function mtquest137()
{

	document.getElementById('mquestiont').innerHTML="I am always hungry, I must always be fed,The finger I touch, Will soon turn red.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="f";
	document.getElementById('mjt').value="f";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "fire";



	}
	
	
	
	
								
		function mtquest138()
{

	document.getElementById('mquestiont').innerHTML="All about, but cannot be seen, Can be captured, cannot be held, No throat, but can be heard.";
	document.getElementById('mat').innerHTML="d";
	document.getElementById('mat').value="d";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="w";
	document.getElementById('mjt').value="w";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "wind";



	}
	
	
	
	
								
		function mtquest139()
{

	document.getElementById('mquestiont').innerHTML="How far will a blind dog walk into a forest?";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="w";
	document.getElementById('mct').value="w";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="p";
	document.getElementById('met').value="p";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "halfway";



	}
	
	
	
	
								
		function mtquest140()
{

	document.getElementById('mquestiont').innerHTML="I am, in truth, a yellow fork from tables in the sky, The apparatus of the dark to ignorance revealed.";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="n";
	document.getElementById('mct').value="n";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "lightning";



	}
	
	
	
	
	

function mtquest12()
{

	document.getElementById('mquestiont').innerHTML="What's black when you get it, red when you use it, and white when you're all through with it?";
	document.getElementById('mat').innerHTML="c";
	document.getElementById('mat').value="c";
	document.getElementById('mbt').innerHTML="c";
	document.getElementById('mbt').value="c";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="y";
	document.getElementById('mgt').value="y";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="h";
	document.getElementById('mit').value="h";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "charcoal";




	}

	
	
	
function mtquest2()
{

	document.getElementById('mquestiont').innerHTML="Feed me and I live, give me drink and I die. What am I?";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="f";
	document.getElementById('mdt').value="f";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="d";
	document.getElementById('mft').value="d";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "fire";




	}

	
	
	
	
	
	
function mtquest14()
{

	document.getElementById('mquestiont').innerHTML="It walks on four legs in the morning, two legs at noon and three legs in the evening. What is it?";
	document.getElementById('mat').innerHTML="x";
	document.getElementById('mat').value="x";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="d";
	document.getElementById('mft').value="d";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "man";




	}

	
	
	
	
	
function mtquest4()
{

	document.getElementById('mquestiont').innerHTML="At night it comes without being fetched. By day it is lost without being stolen. What is it?";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "star";




	}

	
			
		function mtquest16()
{

	document.getElementById('mquestiont').innerHTML="You throw away the outside and cook the inside. Then you eat the outside and throw away the inside. What did you eat?";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="p";
	document.getElementById('mht').value="p";
	document.getElementById('mit').innerHTML="d";
	document.getElementById('mit').value="d";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "corn";




	}

	
	
	
	
	
	
	
	
		function mtquest6()
{

	document.getElementById('mquestiont').innerHTML= "Until I am measured I am not known, Yet how you miss me when I have flown.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "time";





	}

	
	
		
		function mtquest18()
{

	document.getElementById('mquestiont').innerHTML= "Lighter than what I am made of, More of me is hidden Than is seen.";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "iceberg";





	}

	
	
		
		function mtquest8()
{

	document.getElementById('mquestiont').innerHTML="You heard me before, yet you hear me again, Then I die, 'till you call me again.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="h";
	document.getElementById('mdt').value="h";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "echo";




	}

	
	
			
		function mtquest20()
{

	document.getElementById('mquestiont').innerHTML="A box without hinges, lock or key, yet golden treasure lies within. What is it?";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="c";
	document.getElementById('mft').value="c";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="y";
	document.getElementById('mjt').value="y";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "egg";




	}

	
	
	
				
		function mtquest10()
{

	document.getElementById('mquestiont').innerHTML="Light as a feather, there is nothing in it.";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="x";
	document.getElementById('mgt').value="x";
	document.getElementById('mht').innerHTML="h";
	document.getElementById('mht').value="h";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "breath";



	}

	
	
	
	
								
		function mtquest151()
{

	document.getElementById('mquestiont').innerHTML="If a dog were filling out a resume, he might list his mastery of this game under “skills.";
	document.getElementById('mat').innerHTML="c";
	document.getElementById('mat').value="c";
	document.getElementById('mbt').innerHTML="h";
	document.getElementById('mbt').value="h";
	document.getElementById('mct').innerHTML="f";
	document.getElementById('mct').value="f";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "fetch";



	}
	
	
	
	
	
								
		function mtquest152()
{

	document.getElementById('mquestiont').innerHTML="Sleep-inducing melody";
	document.getElementById('mat').innerHTML="l";
	document.getElementById('mat').value="l";
	document.getElementById('mbt').innerHTML="l";
	document.getElementById('mbt').value="l";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="u";
	document.getElementById('mit').value="u";
	document.getElementById('mjt').innerHTML="y";
	document.getElementById('mjt').value="y";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "lullaby";



	}
	
	
	
								
		function mtquest153()
{

	document.getElementById('mquestiont').innerHTML="He crushed on Wendy Darling.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "peterpan";



	}
	
	
								
		function mtquest154()
{

	document.getElementById('mquestiont').innerHTML="This guy crossed a road and everyone wants an explanation";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="h";
	document.getElementById('met').value="h";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="c";
	document.getElementById('mgt').value="c";
	document.getElementById('mht').innerHTML="w";
	document.getElementById('mht').value="w";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "chicken";



	}
	
	
	
	
								
		function mtquest155()
{

	document.getElementById('mquestiont').innerHTML="A twiggy home";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="w";
	document.getElementById('met').value="w";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "nest";



	}
	
	
	
		
				
								
		function mtquest156()
{

	document.getElementById('mquestiont').innerHTML="Very helpful if you intend to go gently down a stream";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="w";
	document.getElementById('mbt').value="w";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="b";
	document.getElementById('mft').value="b";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "rowboat";



	}
	
	
	
	
				
								
		function mtquest157()
{

	document.getElementById('mquestiont').innerHTML="A storage facility for criminals and fire-breathing reptiles.";
	document.getElementById('mat').innerHTML="b";
	document.getElementById('mat').value="b";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="e";
	document.getElementById('met').value="e";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "dungeon";



	}
	
	
	
	
								
		function mtquest158()
{

	document.getElementById('mquestiont').innerHTML="Casper was a friendly one and Demi Moore made a clay pot with one.";
	document.getElementById('mat').innerHTML="h";
	document.getElementById('mat').value="h";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="f";
	document.getElementById('mct').value="f";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "ghost";



	}
	
	
	
	
								
		function mtquest159()
{

	document.getElementById('mquestiont').innerHTML="Where everyone wants to run home and stealing is encouraged.";
	document.getElementById('mat').innerHTML="l";
	document.getElementById('mat').value="l";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "baseball";



	}
	
	
	
	
								
		function mtquest160()
{

	document.getElementById('mquestiont').innerHTML="Special abilities and brightly colored underwear are all you need to be one of these.";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="p";
	document.getElementById('mct').value="p";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="h";
	document.getElementById('mgt').value="h";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="e";
	document.getElementById('mit').value="e";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "superhero";



	}
	
	
	
		
								
		function mtquest161()
{

	document.getElementById('mquestiont').innerHTML="Consuming food would be pretty tough without these chompers.";
	document.getElementById('mat').innerHTML="c";
	document.getElementById('mat').value="c";
	document.getElementById('mbt').innerHTML="h";
	document.getElementById('mbt').value="h";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "teeth";



	}
	
	
	
	
	
								
		function mtquest162()
{

	document.getElementById('mquestiont').innerHTML="A shower that lights up the sky";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "meteor";



	}
	
	
	
								
		function mtquest163()
{

	document.getElementById('mquestiont').innerHTML="If you blow past your destination, you’ll have to throw your car into this.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="v";
	document.getElementById('mit').value="v";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "reverse";



	}
	
	
								
		function mtquest164()
{

	document.getElementById('mquestiont').innerHTML="The state of holding a person in your person";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="c";
	document.getElementById('mgt').value="c";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "pregnant";



	}
	
	
	
	
								
		function mtquest165()
{

	document.getElementById('mquestiont').innerHTML="Between daylight and darkness when sparkling blood suckers like to come out";
	document.getElementById('mat').innerHTML="l";
	document.getElementById('mat').value="l";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="t";
	document.getElementById('mct').value="t";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="w";
	document.getElementById('met').value="w";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "twilight";



	}
	
	
	
		
				
								
		function mtquest166()
{

	document.getElementById('mquestiont').innerHTML="Longer than a decade and shorter than a millennium";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="c";
	document.getElementById('mbt').value="c";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "century";



	}
	
	
	
	
				
								
		function mtquest167()
{

	document.getElementById('mquestiont').innerHTML="Fuels backyard get-togethers.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="c";
	document.getElementById('mbt').value="c";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="c";
	document.getElementById('mht').value="c";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "charcoal";



	}
	
	
	
	
								
		function mtquest168()
{

	document.getElementById('mquestiont').innerHTML="Only you can prevent forest fires.";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="f";
	document.getElementById('mct').value="f";
	document.getElementById('mdt').innerHTML="k";
	document.getElementById('mdt').value="k";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "smokey";



	}
	
	
	
	
								
		function mtquest169()
{

	document.getElementById('mquestiont').innerHTML="A defendant will go free if a reasonable amount of this exists.";
	document.getElementById('mat').innerHTML="u";
	document.getElementById('mat').value="u";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="d";
	document.getElementById('mdt').value="d";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="o";
	document.getElementById('mft').value="o";
	document.getElementById('mgt').innerHTML="b";
	document.getElementById('mgt').value="b";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "doubt";



	}
	
	
	
	
								
		function mtquest170()
{

	document.getElementById('mquestiont').innerHTML="Godzilla calls this place home";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="p";
	document.getElementById('mct').value="p";
	document.getElementById('mdt').innerHTML="j";
	document.getElementById('mdt').value="j";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="h";
	document.getElementById('mgt').value="h";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "japan";



	}
	
	
	
		
	
	
	
	
	
		
								
		function mtquest171()
{

	document.getElementById('mquestiont').innerHTML="This would be a good place to find Can-Can girls and drunk Cowboys.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "saloon";



	}
	
	
	
	
	
								
		function mtquest172()
{

	document.getElementById('mquestiont').innerHTML="Santa’s reindeer make this noise.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="j";
	document.getElementById('mft').value="j";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "jingle";



	}
	
	
	
								
		function mtquest173()
{

	document.getElementById('mquestiont').innerHTML="He prefers to travel on vines and pal around with gorillas.";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="z";
	document.getElementById('mct').value="z";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="v";
	document.getElementById('mit').value="v";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "tarzan";



	}
	
	
								
		function mtquest174()
{

	document.getElementById('mquestiont').innerHTML="Angels and pilots earn these.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="w";
	document.getElementById('mct').value="w";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="c";
	document.getElementById('mgt').value="c";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "wing";



	}
	
	
	
	
								
		function mtquest175()
{

	document.getElementById('mquestiont').innerHTML="What becomes wetter the more it dries?";
	document.getElementById('mat').innerHTML="l";
	document.getElementById('mat').value="l";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="t";
	document.getElementById('mct').value="t";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="w";
	document.getElementById('met').value="w";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "towel";



	}
	
	
	
		
				
								
		function mtquest176()
{

	document.getElementById('mquestiont').innerHTML="What is so fragile, even saying its name can break it?";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="c";
	document.getElementById('mbt').value="c";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="c";
	document.getElementById('mjt').value="c";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "silence";



	}
	
	
	
	
				
								
		function mtquest177()
{

	document.getElementById('mquestiont').innerHTML="What can run but never walks, often murmurs, never talks, has a mouth but never eats, has a bed but never sleeps?";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="v";
	document.getElementById('mht').value="v";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "river";



	}
	
	
	
	
								
		function mtquest178()
{

	document.getElementById('mquestiont').innerHTML="Anyone can hold me, even without their hands, yet no one can do it for long. What am I?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="f";
	document.getElementById('mct').value="f";
	document.getElementById('mdt').innerHTML="h";
	document.getElementById('mdt').value="h";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "breath";



	}
	
	
	
	
								
		function mtquest179()
{

	document.getElementById('mquestiont').innerHTML="I have a hundred eyes, yet cannot see. What am I?";
	document.getElementById('mat').innerHTML="u";
	document.getElementById('mat').value="u";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="d";
	document.getElementById('mdt').value="d";
	document.getElementById('met').innerHTML="b";
	document.getElementById('met').value="b";
	document.getElementById('mft').innerHTML="o";
	document.getElementById('mft').value="o";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "potato";



	}
	
	
	
	
								
		function mtquest180()
{

	document.getElementById('mquestiont').innerHTML="I am invisible, weigh nothing, and if you put me in a barrel, it will become lighter. What am I?";
	document.getElementById('mat').innerHTML="n";
	document.getElementById('mat').value="n";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="j";
	document.getElementById('mdt').value="j";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="h";
	document.getElementById('mgt').value="h";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "hole";



	}
	
	
	
	
	
	
	
	
	
	
		
								
		function mtquest181()
{

	document.getElementById('mquestiont').innerHTML="I am always there, some distance away, somewhere between land and sky I lay, you may move toward me, yet distant I'll stay. What am I?";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="h";
	document.getElementById('mbt').value="h";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="r";
	document.getElementById('mdt').value="r";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="o";
	document.getElementById('mft').value="o";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="z";
	document.getElementById('mit').value="z";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "horizon";



	}
	
	
	
	
	
								
		function mtquest182()
{

	document.getElementById('mquestiont').innerHTML="What has four fingers and a thumb, but is not made of flesh, fish, bone, or fowl?";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="g";
	document.getElementById('mdt').value="g";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="j";
	document.getElementById('mft').value="j";
	document.getElementById('mgt').innerHTML="v";
	document.getElementById('mgt').value="v";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "glove";



	}
	
	
	
								
		function mtquest183()
{

	document.getElementById('mquestiont').innerHTML="The man who made it doesn't want it. The man who bought it doesn't need it. The man who needs it doesn't know it. What is it?";
	document.getElementById('mat').innerHTML="f";
	document.getElementById('mat').value="f";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="z";
	document.getElementById('mct').value="z";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "coffin";



	}
	
	
								
		function mtquest184()
{

	document.getElementById('mquestiont').innerHTML="What can go around the world, yet stays in a corner?";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="w";
	document.getElementById('mct').value="w";
	document.getElementById('mdt').innerHTML="s";
	document.getElementById('mdt').value="s";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="c";
	document.getElementById('mgt').value="c";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "stamp";



	}
	
	
	
	
								
		function mtquest185()
{

	document.getElementById('mquestiont').innerHTML="I am not alive, yet I grow; I have no lungs, yet I need air; I have no mouth, yet I can drown. What am I?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="w";
	document.getElementById('met').value="w";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "fire";



	}
	
	
	
		
				
								
		function mtquest186()
{

	document.getElementById('mquestiont').innerHTML="Throw me off the highest building, and I shall not break, but toss me in the smallest pool, and my life's at stake. What am I?";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="t";
	document.getElementById('mct').value="t";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="s";
	document.getElementById('mgt').value="s";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="c";
	document.getElementById('mjt').value="c";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "tissue";



	}
	
	
	
	
				
								
		function mtquest187()
{

	document.getElementById('mquestiont').innerHTML="For what crime can an offender be arrested for attempting, but not committing?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="v";
	document.getElementById('mht').value="v";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "suicide";



	}
	
	
	
	
								
		function mtquest188()
{

	document.getElementById('mquestiont').innerHTML="What can you always count on when trying to solve math problems?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="f";
	document.getElementById('mct').value="f";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="b";
	document.getElementById('mjt').value="b";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "fingers";



	}
	
	
	
	
								
		function mtquest189()
{

	document.getElementById('mquestiont').innerHTML="The rich want it, and the poor have it; it is greater than God, but worse than Satan; and if you eat it you will die. What is it?";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="h";
	document.getElementById('met').value="h";
	document.getElementById('mft').innerHTML="o";
	document.getElementById('mft').value="o";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "nothing";



	}
	
	
	
	
								
		function mtquest190()
{

	document.getElementById('mquestiont').innerHTML="If you have me, you want to share me. If you share me, I no longer exist. What am I?";
	document.getElementById('mat').innerHTML="c";
	document.getElementById('mat').value="c";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="t";
	document.getElementById('mgt').value="t";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "secret";



	}
	
	
	
	
	
	
		
								
		function mtquest191()
{

	document.getElementById('mquestiont').innerHTML="Before Mount Everest was discovered, what was the tallest mountain in the world?";
	document.getElementById('mat').innerHTML="v";
	document.getElementById('mat').value="v";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="e";
	document.getElementById('mct').value="e";
	document.getElementById('mdt').innerHTML="r";
	document.getElementById('mdt').value="r";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="o";
	document.getElementById('mft').value="o";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="z";
	document.getElementById('mit').value="z";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "everest";



	}
	
	
	
	
	
								
		function mtquest192()
{

	document.getElementById('mquestiont').innerHTML="If a plane crashed on the border between the US and Mexico, where would the survivors be buried?";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="e";
	document.getElementById('mbt').value="e";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="w";
	document.getElementById('mdt').value="w";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="j";
	document.getElementById('mft').value="j";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "nowhere";



	}
	
	
	
								
		function mtquest193()
{

	document.getElementById('mquestiont').innerHTML="A man living in the UK cannot be buried in America because he is?";
	document.getElementById('mat').innerHTML="f";
	document.getElementById('mat').value="f";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="z";
	document.getElementById('mct').value="z";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="t";
	document.getElementById('met').value="t";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="v";
	document.getElementById('mgt').value="v";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="g";
	document.getElementById('mjt').value="g";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "living";



	}
	
	
								
		function mtquest194()
{

	document.getElementById('mquestiont').innerHTML="What has been around for millions of years, but is never more than a month old?";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="s";
	document.getElementById('mdt').value="s";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="c";
	document.getElementById('mgt').value="c";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="n";
	document.getElementById('mjt').value="n";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "moon";



	}
	
	
	
	
								
		function mtquest195()
{

	document.getElementById('mquestiont').innerHTML="What belongs to you, but is used mostly by others?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="a";
	document.getElementById('mct').value="a";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="w";
	document.getElementById('met').value="w";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="f";
	document.getElementById('mgt').value="f";
	document.getElementById('mht').innerHTML="m";
	document.getElementById('mht').value="m";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "name";



	}
	
	
	
		
				
								
		function mtquest196()
{

	document.getElementById('mquestiont').innerHTML="Here there is no north or west or east, and the weather, it is fitting for no man or bird or beast.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="h";
	document.getElementById('mbt').value="h";
	document.getElementById('mct').innerHTML="t";
	document.getElementById('mct').value="t";
	document.getElementById('mdt').innerHTML="e";
	document.getElementById('mdt').value="e";
	document.getElementById('met').innerHTML="o";
	document.getElementById('met').value="o";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="p";
	document.getElementById('mgt').value="p";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "north pole";



	}
	
	
	
	
				
								
		function mtquest197()
{

	document.getElementById('mquestiont').innerHTML="What goes up but never comes down?";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="d";
	document.getElementById('mbt').value="d";
	document.getElementById('mct').innerHTML="h";
	document.getElementById('mct').value="h";
	document.getElementById('mdt').innerHTML="c";
	document.getElementById('mdt').value="c";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="g";
	document.getElementById('mft').value="g";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="v";
	document.getElementById('mht').value="v";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "age";



	}
	
	
	
	
								
		function mtquest198()
{

	document.getElementById('mquestiont').innerHTML="The more there is, the less you see. What is it?";
	document.getElementById('mat').innerHTML="k";
	document.getElementById('mat').value="k";
	document.getElementById('mbt').innerHTML="r";
	document.getElementById('mbt').value="r";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="s";
	document.getElementById('mdt').value="s";
	document.getElementById('met').innerHTML="n";
	document.getElementById('met').value="n";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="s";
	document.getElementById('mit').value="s";
	document.getElementById('mjt').innerHTML="d";
	document.getElementById('mjt').value="d";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "darkness";



	}
	
	
	
	
								
		function mtquest199()
{

	document.getElementById('mquestiont').innerHTML="What can go up and come down without moving?";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="v";
	document.getElementById('mbt').value="v";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="o";
	document.getElementById('mft').value="o";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="e";
	document.getElementById('mht').value="e";
	document.getElementById('mit').innerHTML="m";
	document.getElementById('mit').value="m";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "volume";



	}
	
	
	
	
								
		function mtquest200()
{

	document.getElementById('mquestiont').innerHTML="What turns everything around without moving?";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="l";
	document.getElementById('mct').value="l";
	document.getElementById('mdt').innerHTML="m";
	document.getElementById('mdt').value="m";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="e";
	document.getElementById('mft').value="e";
	document.getElementById('mgt').innerHTML="r";
	document.getElementById('mgt').value="r";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mirror";



	}
	
	
	
	
	
	
	
		
	
		function mtquest201()
{

	document.getElementById('mquestiont').innerHTML="Mga kaloobang pinaghalu-halo na niluto sa init ng pagkakasundo.";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="d";
	document.getElementById('mjt').value="d";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "dinuguan";



	}
	
	
	
		function mtquest202()
{

	document.getElementById('mquestiont').innerHTML="Di naman isda, di naman itik Nakahuhuni kung ibig maging sa kati, maging sa tubig ang huni'y nakabubuwisit.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="y";
	document.getElementById('mjt').value="y";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "palaka";



	}
	
	
	
	
		function mtquest203()
{

	document.getElementById('mquestiont').innerHTML="May puno walang sanga May dahon, walang bunga.";
	document.getElementById('mat').innerHTML="o";
	document.getElementById('mat').value="o";
	document.getElementById('mbt').innerHTML="k";
	document.getElementById('mbt').value="k";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="y";
	document.getElementById('mft').value="y";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="d";
	document.getElementById('mit').value="d";
	document.getElementById('mjt').innerHTML="h";
	document.getElementById('mjt').value="h";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sandok";



	}
	
	
	
	
		function mtquest204()
{

	document.getElementById('mquestiont').innerHTML="Walang itak, walang kampit Gumagawa ng bahay na ipit.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="b";
	document.getElementById('mit').value="b";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "gagamba";



	}
	
	
	
	
		function mtquest205()
{

	document.getElementById('mquestiont').innerHTML="Lumalakad walang paa Lumuluha walang mata.";
	document.getElementById('mat').innerHTML="u";
	document.getElementById('mat').value="u";
	document.getElementById('mbt').innerHTML="w";
	document.getElementById('mbt').value="w";
	document.getElementById('mct').innerHTML="m";
	document.getElementById('mct').value="m";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="o";
	document.getElementById('met').value="o";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="p";
	document.getElementById('mit').value="p";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "pluma";



	}
	
	
	
	
		function mtquest206()
{

	document.getElementById('mquestiont').innerHTML="Dahong pinagbungahan, Bungang pinagdahunan.";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="y";
	document.getElementById('mct').value="y";
	document.getElementById('mdt').innerHTML="p";
	document.getElementById('mdt').value="p";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="p";
	document.getElementById('mht').value="p";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "pinya";



	}
	
	
	
	
		function mtquest207()
{

	document.getElementById('mquestiont').innerHTML="Heto na si kurdapya may sunong na baga.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="m";
	document.getElementById('mft').value="m";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "manok";



	}
	
	
	
	
	function mtquest208()
{

	document.getElementById('mquestiont').innerHTML="Isdang parang ahas, sa karagatan pumapagaspas.";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="u";
	document.getElementById('mft').value="u";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "igat";



	}
	
	
		function mtquest209()
{

	document.getElementById('mquestiont').innerHTML="May alaga akong hayop, malaki ang mata kaysa tuhod.";
	document.getElementById('mat').innerHTML="u";
	document.getElementById('mat').value="u";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="p";
	document.getElementById('mdt').value="p";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "tutubi";



	}

	
	

	
	function mtquest210()
{

	document.getElementById('mquestiont').innerHTML="Anong insekto sa mundo na naglalakad na walang buto.";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="y";
	document.getElementById('mjt').value="y";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "uod";



	}
	
	
	
	
		
		
	
		function mtquest211()
{

	document.getElementById('mquestiont').innerHTML="Pinisa ko at pinirot bago sininghot.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="s";
	document.getElementById('mft').value="s";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "surot";



	}
	
	
	
		function mtquest212()
{

	document.getElementById('mquestiont').innerHTML="Koronang mapula ay katulad nito lagi nang nakakabit sa ulo.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="y";
	document.getElementById('mjt').value="y";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "palong";



	}
	
	
	
	
		function mtquest213()
{

	document.getElementById('mquestiont').innerHTML="May puno walang sanga May dahon, walang bunga.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="w";
	document.getElementById('mit').value="w";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "pamingwit";



	}
	
	
	
	
		function mtquest214()
{

	document.getElementById('mquestiont').innerHTML="Dumating si Canuto, nangabuhay ang mga tao.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="u";
	document.getElementById('mit').value="u";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "umaga";



	}
	
	
	
	
		function mtquest215()
{

	document.getElementById('mquestiont').innerHTML="Kung araw ay patung-patong, kung gabi'y dugtong-dugtong.";
	document.getElementById('mat').innerHTML="u";
	document.getElementById('mat').value="u";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="m";
	document.getElementById('mct').value="m";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="o";
	document.getElementById('met').value="o";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "unan";



	}
	
	
	
	
		function mtquest216()
{

	document.getElementById('mquestiont').innerHTML="Isang hukbong sundalo, dikit-dikit ang mga ulo,";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="y";
	document.getElementById('mct').value="y";
	document.getElementById('mdt').innerHTML="w";
	document.getElementById('mdt').value="w";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="s";
	document.getElementById('mht').value="s";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "walis";



	}
	
	
	
	
		function mtquest217()
{

	document.getElementById('mquestiont').innerHTML="Dumaing paa'y walang kamay, may pamigkis sa baywang, ang ulo'y parang tagayan, alagad ng kalinisan.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="w";
	document.getElementById('mit').value="w";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "walis";



	}
	
	
	
	
	function mtquest218()
{

	document.getElementById('mquestiont').innerHTML="Kung tingna'y mainit, hipui'y malamig, umuusok ang paligid.";
	document.getElementById('mat').innerHTML="e";
	document.getElementById('mat').value="e";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="y";
	document.getElementById('mft').value="y";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="g";
	document.getElementById('mit').value="g";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "yelo";



	}
	
	
		function mtquest219()
{

	document.getElementById('mquestiont').innerHTML="Mayroon akong dalawang balon, hindi ko malingon.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="p";
	document.getElementById('mdt').value="p";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="t";
	document.getElementById('mht').value="t";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="t";
	document.getElementById('mjt').value="t";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "tainga";



	}

	
	

	
	function mtquest220()
{

	document.getElementById('mquestiont').innerHTML="Nang tangan ko'y patay, nang itapon ko'y nabuhay.";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="r";
	document.getElementById('mit').value="r";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "trumpo";



	}
	
	
	
	
	
	
			
		
	
		function mtquest221()
{

	document.getElementById('mquestiont').innerHTML="Binalangkas ko nang binalangkas, bago ko inihampas.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="p";
	document.getElementById('met').value="p";
	document.getElementById('mft').innerHTML="m";
	document.getElementById('mft').value="m";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="o";
	document.getElementById('mjt').value="o";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "trumpo";



	}
	
	
	
		function mtquest222()
{

	document.getElementById('mquestiont').innerHTML="Munting tumataginting, kung saan nanggagaling.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "telepono";



	}
	
	
	
	
		function mtquest223()
{

	document.getElementById('mquestiont').innerHTML="Puno na naging tubig, tubig na naging bato, bato na kinain ng tao.";
	document.getElementById('mat').innerHTML="u";
	document.getElementById('mat').value="u";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="b";
	document.getElementById('mct').value="b";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="t";
	document.getElementById('mft').value="t";
	document.getElementById('mgt').innerHTML="o";
	document.getElementById('mgt').value="o";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="w";
	document.getElementById('mit').value="w";
	document.getElementById('mjt').innerHTML="m";
	document.getElementById('mjt').value="m";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "tubo";



	}
	
	
	
	
		function mtquest224()
{

	document.getElementById('mquestiont').innerHTML="Ang ibabaw ay tawiran, ang ilalim ay lusutan.";
	document.getElementById('mat').innerHTML="y";
	document.getElementById('mat').value="y";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="l";
	document.getElementById('mht').value="l";
	document.getElementById('mit').innerHTML="u";
	document.getElementById('mit').value="u";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "tulay";



	}
	
	
	
	
		function mtquest225()
{

	document.getElementById('mquestiont').innerHTML="Bulaklak muna ang dapat gawin, bago mo ito kanin. ";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="m";
	document.getElementById('mct').value="m";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="s";
	document.getElementById('mht').value="s";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "saging";



	}
	
	
	
	
		function mtquest226()
{

	document.getElementById('mquestiont').innerHTML="Sapagkat lahat na ay nakahihipo, walang kasindumi't walang kasimbaho, bakit mahal nati't ipinakatatago.";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="y";
	document.getElementById('mct').value="y";
	document.getElementById('mdt').innerHTML="w";
	document.getElementById('mdt').value="w";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="s";
	document.getElementById('mht').value="s";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "salapi";



	}
	
	
	
	
		function mtquest227()
{

	document.getElementById('mquestiont').innerHTML="Aling mabuting retrato ang kuhang-kuha sa mukha mo? ";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="w";
	document.getElementById('mit').value="w";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "salamin";



	}
	
	
	
	
	function mtquest228()
{

	document.getElementById('mquestiont').innerHTML="Sinampal ko muna bago inalok.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="k";
	document.getElementById('mft').value="k";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="m";
	document.getElementById('mit').value="m";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sampalok";



	}
	
	
		function mtquest229()
{

	document.getElementById('mquestiont').innerHTML="Ang ulo'y nalalaga ang katawa'y pagala-gala.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="s";
	document.getElementById('mdt').value="s";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sandok";



	}

	
	

	
	function mtquest230()
{

	document.getElementById('mquestiont').innerHTML="Alipin ng hari, hindi makalakad, kung hindi itali.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="p";
	document.getElementById('mbt').value="p";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="a";
	document.getElementById('mit').value="a";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sapatos";



	}
	
	
	
	
	
				
		
	
		function mtquest231()
{

	document.getElementById('mquestiont').innerHTML="Baboy ko sa parang, namumula sa tapang.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="p";
	document.getElementById('met').value="p";
	document.getElementById('mft').innerHTML="m";
	document.getElementById('mft').value="m";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="l";
	document.getElementById('mjt').value="l";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sili";



	}
	
	
	
		function mtquest232()
{

	document.getElementById('mquestiont').innerHTML="Munting tampipi puno ng salapi.";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sili";



	}
	
	
	
	
		function mtquest233()
{

	document.getElementById('mquestiont').innerHTML="Isang lupa-lupaan sa dulo ng kawayan.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="y";
	document.getElementById('mft').value="y";
	document.getElementById('mgt').innerHTML="o";
	document.getElementById('mgt').value="o";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="w";
	document.getElementById('mit').value="w";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sigarilyo";



	}
	
	
	
	
		function mtquest234()
{

	document.getElementById('mquestiont').innerHTML="Hiyas akong mabilog, sa daliri isinusuot.";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="g";
	document.getElementById('mht').value="g";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "singsing";



	}
	
	
	
	
		function mtquest235()
{

	document.getElementById('mquestiont').innerHTML="Buklod na tinampukan, saksi ng pag-iibigan.";
	document.getElementById('mat').innerHTML="g";
	document.getElementById('mat').value="g";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="m";
	document.getElementById('mct').value="m";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="s";
	document.getElementById('mht').value="s";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "singsing";



	}
	
	
	
	
		function mtquest236()
{

	document.getElementById('mquestiont').innerHTML="Ipinalilok ko at ipinalubid, nang higpitan ang kapit.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="y";
	document.getElementById('mct').value="y";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="n";
	document.getElementById('mgt').value="n";
	document.getElementById('mht').innerHTML="s";
	document.getElementById('mht').value="s";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sinturon";



	}
	
	
	
	
		function mtquest237()
{

	document.getElementById('mquestiont').innerHTML="Nang munti pa ay paruparo, nang lumaki ay latigo.";
	document.getElementById('mat').innerHTML="t";
	document.getElementById('mat').value="t";
	document.getElementById('mbt').innerHTML="s";
	document.getElementById('mbt').value="s";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="m";
	document.getElementById('mgt').value="m";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="w";
	document.getElementById('mit').value="w";
	document.getElementById('mjt').innerHTML="i";
	document.getElementById('mjt').value="i";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sitaw";



	}
	
	
	
	
	function mtquest238()
{

	document.getElementById('mquestiont').innerHTML="Bumili ako ng alipin, mataas pa sa akin.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="s";
	document.getElementById('mct').value="s";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="r";
	document.getElementById('mft').value="r";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="b";
	document.getElementById('mht').value="b";
	document.getElementById('mit').innerHTML="m";
	document.getElementById('mit').value="m";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sumbrero";



	}
	
	
		function mtquest239()
{

	document.getElementById('mquestiont').innerHTML="Isang tabo, laman ay pako.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="s";
	document.getElementById('mdt').value="s";
	document.getElementById('met').innerHTML="u";
	document.getElementById('met').value="u";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="h";
	document.getElementById('mit').value="h";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "suha";



	}

	
	

	
	function mtquest240()
{

	document.getElementById('mquestiont').innerHTML="Isang panyong parisukat, kung buksa'y nakakausap.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "sulat";



	}
	
	
	
	
	
					
		
	
		function mtquest241()
{

	document.getElementById('mquestiont').innerHTML="Dalawang magkaibigan, habulan nang habulan. ";
	document.getElementById('mat').innerHTML="s";
	document.getElementById('mat').value="s";
	document.getElementById('mbt').innerHTML="i";
	document.getElementById('mbt').value="i";
	document.getElementById('mct').innerHTML="u";
	document.getElementById('mct').value="u";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="p";
	document.getElementById('met').value="p";
	document.getElementById('mft').innerHTML="m";
	document.getElementById('mft').value="m";
	document.getElementById('mgt').innerHTML="u";
	document.getElementById('mgt').value="u";
	document.getElementById('mht').innerHTML="y";
	document.getElementById('mht').value="y";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="a";
	document.getElementById('mjt').value="a";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "paa";



	}
	
	
	
		function mtquest242()
{

	document.getElementById('mquestiont').innerHTML="May ulo'y walang mukha, may katawa'y walang sikmura. Namamahay ng sadya. ";
	document.getElementById('mat').innerHTML="i";
	document.getElementById('mat').value="i";
	document.getElementById('mbt').innerHTML="t";
	document.getElementById('mbt').value="t";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="l";
	document.getElementById('mdt').value="l";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="i";
	document.getElementById('mgt').value="i";
	document.getElementById('mht').innerHTML="k";
	document.getElementById('mht').value="k";
	document.getElementById('mit').innerHTML="o";
	document.getElementById('mit').value="o";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "palito";



	}
	
	
	
	
		function mtquest243()
{

	document.getElementById('mquestiont').innerHTML="Binatak ko ang isa, pawis ang kasama.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="n";
	document.getElementById('mbt').value="n";
	document.getElementById('mct').innerHTML="r";
	document.getElementById('mct').value="r";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="y";
	document.getElementById('mft').value="y";
	document.getElementById('mgt').innerHTML="o";
	document.getElementById('mgt').value="o";
	document.getElementById('mht').innerHTML="i";
	document.getElementById('mht').value="i";
	document.getElementById('mit').innerHTML="w";
	document.getElementById('mit').value="w";
	document.getElementById('mjt').innerHTML="s";
	document.getElementById('mjt').value="s";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "panyo";



	}
	
	
	
	
		function mtquest244()
{

	document.getElementById('mquestiont').innerHTML="Ang puno'y buku-buko,ang sanga'y baril, ang bunga'y bote, ang laman ay diyamante.";
	document.getElementById('mat').innerHTML="p";
	document.getElementById('mat').value="p";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="g";
	document.getElementById('mct').value="g";
	document.getElementById('mdt').innerHTML="n";
	document.getElementById('mdt').value="n";
	document.getElementById('met').innerHTML="a";
	document.getElementById('met').value="a";
	document.getElementById('mft').innerHTML="h";
	document.getElementById('mft').value="h";
	document.getElementById('mgt').innerHTML="y";
	document.getElementById('mgt').value="y";
	document.getElementById('mht').innerHTML="a";
	document.getElementById('mht').value="a";
	document.getElementById('mit').innerHTML="i";
	document.getElementById('mit').value="i";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "papaya";



	}
	
	
	
	
		function mtquest245()
{

	document.getElementById('mquestiont').innerHTML="Ang labas ay tabla-tabla ang loob ay sala-sala.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="t";
	document.getElementById('mct').value="t";
	document.getElementById('mdt').innerHTML="i";
	document.getElementById('mdt').value="i";
	document.getElementById('met').innerHTML="g";
	document.getElementById('met').value="g";
	document.getElementById('mft').innerHTML="i";
	document.getElementById('mft').value="i";
	document.getElementById('mgt').innerHTML="l";
	document.getElementById('mgt').value="l";
	document.getElementById('mht').innerHTML="o";
	document.getElementById('mht').value="o";
	document.getElementById('mit').innerHTML="n";
	document.getElementById('mit').value="n";
	document.getElementById('mjt').innerHTML="p";
	document.getElementById('mjt').value="p";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "patola";



	}
	
	
	
	
		function mtquest246()
{

	document.getElementById('mquestiont').innerHTML="Dalawang bolang sinulid, abot hanggang langit. ";
	document.getElementById('mat').innerHTML="m";
	document.getElementById('mat').value="m";
	document.getElementById('mbt').innerHTML="o";
	document.getElementById('mbt').value="o";
	document.getElementById('mct').innerHTML="y";
	document.getElementById('mct').value="y";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="i";
	document.getElementById('met').value="i";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="s";
	document.getElementById('mht').value="s";
	document.getElementById('mit').innerHTML="t";
	document.getElementById('mit').value="t";
	document.getElementById('mjt').innerHTML="u";
	document.getElementById('mjt').value="u";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "mata";



	}
	
	
	
	
		function mtquest247()
{

	document.getElementById('mquestiont').innerHTML="Araw araw bagong buhay, Taun-taon namamatay. ";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="y";
	document.getElementById('mbt').value="y";
	document.getElementById('mct').innerHTML="o";
	document.getElementById('mct').value="o";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="r";
	document.getElementById('met').value="r";
	document.getElementById('mft').innerHTML="l";
	document.getElementById('mft').value="l";
	document.getElementById('mgt').innerHTML="e";
	document.getElementById('mgt').value="e";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="d";
	document.getElementById('mit').value="d";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kalendaryo";



	}
	
	
	
	
	function mtquest248()
{

	document.getElementById('mquestiont').innerHTML="Ako'y aklat ng panahon, Binabago taun taon.";
	document.getElementById('mat').innerHTML="r";
	document.getElementById('mat').value="r";
	document.getElementById('mbt').innerHTML="a";
	document.getElementById('mbt').value="a";
	document.getElementById('mct').innerHTML="k";
	document.getElementById('mct').value="k";
	document.getElementById('mdt').innerHTML="o";
	document.getElementById('mdt').value="o";
	document.getElementById('met').innerHTML="y";
	document.getElementById('met').value="y";
	document.getElementById('mft').innerHTML="d";
	document.getElementById('mft').value="d";
	document.getElementById('mgt').innerHTML="a";
	document.getElementById('mgt').value="a";
	document.getElementById('mht').innerHTML="n";
	document.getElementById('mht').value="n";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="e";
	document.getElementById('mjt').value="e";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kalendaryo";



	}
	
	
		function mtquest249()
{

	document.getElementById('mquestiont').innerHTML="May katawan walang mukha, walang mata'y lumuluha.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="b";
	document.getElementById('mbt').value="b";
	document.getElementById('mct').innerHTML="i";
	document.getElementById('mct').value="i";
	document.getElementById('mdt').innerHTML="a";
	document.getElementById('mdt').value="a";
	document.getElementById('met').innerHTML="l";
	document.getElementById('met').value="l";
	document.getElementById('mft').innerHTML="n";
	document.getElementById('mft').value="n";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="h";
	document.getElementById('mit').value="h";
	document.getElementById('mjt').innerHTML="k";
	document.getElementById('mjt').value="k";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "kandila";



	}

	
	

	
	function mtquest250()
{

	document.getElementById('mquestiont').innerHTML="Dalawang katawan, tagusan ang tadyang.";
	document.getElementById('mat').innerHTML="a";
	document.getElementById('mat').value="a";
	document.getElementById('mbt').innerHTML="u";
	document.getElementById('mbt').value="u";
	document.getElementById('mct').innerHTML="n";
	document.getElementById('mct').value="n";
	document.getElementById('mdt').innerHTML="t";
	document.getElementById('mdt').value="t";
	document.getElementById('met').innerHTML="s";
	document.getElementById('met').value="s";
	document.getElementById('mft').innerHTML="a";
	document.getElementById('mft').value="a";
	document.getElementById('mgt').innerHTML="g";
	document.getElementById('mgt').value="g";
	document.getElementById('mht').innerHTML="d";
	document.getElementById('mht').value="d";
	document.getElementById('mit').innerHTML="l";
	document.getElementById('mit').value="l";
	document.getElementById('mjt').innerHTML="h";
	document.getElementById('mjt').value="h";	
	document.getElementById("mnumerot").innerHTML = "riddle no: " + mnumbt;

mright_anst = "hagdan";



	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function msubmitt()
{


 

if(msagott==mright_anst)
{
mscoret++;
mnumbt++;
document.getElementById("lifet").innerHTML = "life: " + lifet;

document.getElementById("mscoret").innerHTML = "score: " + mscoret;
document.getElementById("manst").innerHTML = "";
alert("You are Correct!!!");


mpt++;
msagott = "";

if(mnumbt>250)
{
document.getElementById("msubmitt").href = "#twinner_m_u";

document.getElementById("tfscore_m_u").innerHTML = "score: " + mscoret;
}

else{
tstart_m_u();}
}
else
{

alert("You are Wrong!!!");

document.getElementById("lifet").innerHTML = "life: " + lifet;

document.getElementById("mscoret").innerHTML = "score: " + mscoret;
document.getElementById("manst").innerHTML = "";

if(lifet == 0)
{

document.getElementById("msubmitt").href = "#texit_m_u";

document.getElementById("tgfmscoret_m_u").innerHTML = "score: " + mscoret;

}


else{
mnumbt++;

mpt++;

msagott = "";


if(mnumbt>250)
{
document.getElementById("msubmitt").href = "#twinner_m_u";

document.getElementById("tfscore_m_u").innerHTML = "score: " + mscoret;
}

tstart_m_u();
}

}

changeColor6();
}





function times3()
{
document.getElementById('mlifet').innerHTML=m3+":"+s3+" remaining";
s3--;
q=setTimeout("times3()", 1000);
if (s3<0)
{ m3=m3-1; s3=59;}

if (m3<0)
{
timesstop3();
}
}
function timesstop3()
{
clearTimeout(q3);
s3=0;
m3=0;
document.getElementById('mlifet').innerHTML=" ";
mright_anst = "" ;
msagott = "";

$("#try3,#mquestiont,#manst,#mat,#mbt,#mct,#mdt,#met,#mft,#mgt,#mht,#mit,#mjt").hide();
		$("#msubmitt,#mresett").hide();

		document.getElementById('tgfscore_m_u').innerHTML="score: " + mscoret;

	$("#mgameover").show();
	
}


	
	function mbalik()
{
$("#try3").show();
$("#mquestiont,#manst,#mat,#mbt,#mct,#mdt,#met,#mft,#mgt,#mht,#mit,#mjt").show();
		$("#msubmitt,#mresett").show();

	$("#mgameover").hide();


	
document.getElementById('tgfscore_m_u').innerHTML="score: " + mscoret;
	

}




function tgokay_m_u()
{

mpt = 1 ;
manst = "" ;
msagott = "";
mright_anst = "" ;
mscoret = 0;
mnumbt = 1;
s3 = 10;
m3 = 0;	
q3;


}

var tpt = 1 ;
var tanst = "" ;
var tsagott = "";
var tright_anst = "" ;
var tscoret = 0;
var tnumbt = 1;
var s2 = 59;
var m2 = 9;
var q2;
var let_num5 = "";





function bura5()
{
var dine = tsagott.length - 1;

tsagott = tsagott.substring(0,dine);
document.getElementById("tanst").innerHTML = tsagott;

var dindin = let_num5.length - 1;
var pj = let_num5.charAt(dindin);
if(pj == "a")
{$("#tat").show(200);
let_num5 = let_num5.substring(0,dindin);
}
else if(pj == "b")
{$("#tbt").show(200);
let_num5 = let_num5.substring(0,dindin);}
else if(pj == "c")
{$("#tct").show(200);
let_num5 = let_num5.substring(0,dindin);}
else if(pj == "d")
{$("#tdt").show(200);
let_num5 = let_num5.substring(0,dindin);}
else if(pj == "e")
{$("#tet").show(200);
let_num5 = let_num5.substring(0,dindin);}
else if(pj == "f")
{$("#tft").show(200);
let_num5 = let_num5.substring(0,dindin);}
else if(pj == "g")
{$("#tgt").show(200);
let_num5 = let_num5.substring(0,dindin);}
else if(pj == "h")
{$("#tht").show(200);
let_num5 = let_num5.substring(0,dindin);}
else if(pj == "i")
{$("#tit").show(200);
let_num5 = let_num5.substring(0,dindin);}
else if(pj == "j")
{$("#tjt").show(200);
let_num5 = let_num5.substring(0,dindin);}




}






















function homing5()
{
  var x;
    if (confirm("You want to quit?") == true) {
 document.getElementById("5home_b").href =  "#page1";
  } else {
 document.getElementById("5home_b").href =  "";
    }
}












$(document).ready(function(){
$("#tat").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#tbt").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#tct").click(function(){
$(this).hide(200);
});
});


$(document).ready(function(){
$("#tdt").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#tet").click(function(){
$(this).hide(200);
});
});








$(document).ready(function(){
$("#tft").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#tgt").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#tht").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#tit").click(function(){
$(this).hide(200);
});
});




$(document).ready(function(){
$("#tjt").click(function(){
$(this).hide(200);
});
});



$(document).ready(function(){
$("#tresett,#tsubmitt").click(function(){
$("#tat,#tct,#tbt,#tdt,#tet,#tgt,#tft,#tht,#tit,#tjt").show(200);
});
});





function tgokay_t_u()
{
var tpt = 1 ;
var tanst = "" ;
var tsagott = "";
var tright_anst = "" ;
var tscoret = 0;
var tnumbt = 1;
var s2 = 59;
var m2 = 1;
var q2;


}




function tcokay_t_u()
{
var tpt = 1 ;
var tanst = "" ;
var tsagott = "";
var tright_anst = "" ;
var tscoret = 0;
var tnumbt = 1;
var s2 = 59;
var m2 = 1;
var q2;


}

function tstart_t_u()
{

var random = Math.floor(Math.random()*2);
if(random==0){random++;}

$("#tgameover").hide();


if(tpt==1)
	{
		
	ttquest1();
times2();
	}
	else if(tpt==2)
	{
		
	ttquest2();

	}
	else if(tpt==3)
		
	{
	ttquest3();

	}

	else if(tpt==4)
		
	{
	ttquest4();

	}
	else if(tpt==5)
		
	{
	ttquest5();

	}

	else if(tpt==6)
		
	{
	ttquest6();

	}
	else if(tpt==7)
		
	{
	ttquest7();

	}
	else if(tpt==8)
		
	{
	ttquest8();

	}
	else if(tpt==9)
		
	{
	ttquest9();

	}
	else if(tpt==10)
		
	{
	ttquest10();

	}




	else if(tpt==11)
	{
		
	ttquest11();

	}
	else if(tpt==12)
	{
		
	ttquest12();

	}
	else if(tpt==13)
		
	{
	ttquest13();

	}

	else if(tpt==14)
		
	{
	ttquest14();

	}
	else if(tpt==15)
		
	{
	ttquest15();

	}

	else if(tpt==16)
		
	{
	ttquest16();

	}
	else if(tpt==17)
		
	{
	ttquest17();

	}
	else if(tpt==18)
		
	{
	ttquest18();

	}
	else if(tpt==19)
		
	{
	ttquest19();

	}
	else if(tpt==20)
		
	{
	ttquest20();

	}

	

	else if(tpt==21)
	{
		
	ttquest21();

	}
	else if(tpt==22)
	{
		
	ttquest22();

	}
	else if(tpt==23)
		
	{
	ttquest23();

	}

	else if(tpt==24)
		
	{
	ttquest24();

	}
	else if(tpt==25)
		
	{
	ttquest25();

	}

	else if(tpt==26)
		
	{
	ttquest26();

	}
	else if(tpt==27)
		
	{
	ttquest27();

	}
	else if(tpt==28)
		
	{
	ttquest28();

	}
	else if(tpt==29)
		
	{
	ttquest29();

	}
	else if(tpt==30)
		
	{
	ttquest30();

	}



	else if(tpt==31)
	{
		
	ttquest31();

	}
	else if(tpt==32)
	{
		
	ttquest32();

	}
	else if(tpt==33)
		
	{
	ttquest33();

	}

	else if(tpt==34)
		
	{
	ttquest34();

	}
	else if(tpt==35)
		
	{
	ttquest35();

	}

	else if(tpt==36)
		
	{
	ttquest36();

	}
	else if(tpt==37)
		
	{
	ttquest37();

	}
	else if(tpt==38)
		
	{
	ttquest38();

	}
	else if(tpt==39)
		
	{
	ttquest39();

	}
	else if(tpt==40)
		
	{
	ttquest40();

	}




	else if(tpt==41)
	{
		
	ttquest41();

	}
	else if(tpt==42)
	{
		
	ttquest42();

	}
	else if(tpt==43)
		
	{
	ttquest43();

	}

	else if(tpt==44)
		
	{
	ttquest44();

	}
	else if(tpt==45)
		
	{
	ttquest45();

	}

	else if(tpt==46)
		
	{
	ttquest46();

	}
	else if(tpt==47)
		
	{
	ttquest47();

	}
	else if(tpt==48)
		
	{
	ttquest48();

	}
	else if(tpt==49)
		
	{
	ttquest49();

	}
	else if(tpt==50)
		
	{
	ttquest50();

	}

	
	else if(tpt==51)
	{
		
	ttquest51();

	}
	else if(tpt==52)
	{
		
	ttquest52();

	}
	else if(tpt==53)
		
	{
	ttquest53();

	}

	else if(tpt==54)
		
	{
	ttquest54();

	}
	else if(tpt==55)
		
	{
	ttquest55();

	}

	else if(tpt==56)
		
	{
	ttquest56();

	}
	else if(tpt==57)
		
	{
	ttquest57();

	}
	else if(tpt==58)
		
	{
	ttquest58();

	}
	else if(tpt==59)
		
	{
	ttquest59();

	}
	else if(tpt==60)
		
	{
	ttquest60();

	}
	
	
	else if(tpt==61)
	{
		
	ttquest61();

	}
	else if(tpt==62)
	{
		
	ttquest62();

	}
	else if(tpt==63)
		
	{
	ttquest63();

	}

	else if(tpt==64)
		
	{
	ttquest64();

	}
	else if(tpt==65)
		
	{
	ttquest65();

	}

	else if(tpt==66)
		
	{
	ttquest66();

	}
	else if(tpt==67)
		
	{
	ttquest67();

	}
	else if(tpt==68)
		
	{
	ttquest68();

	}
	else if(tpt==69)
		
	{
	ttquest69();

	}
	else if(tpt==70)
		
	{
	ttquest70();

	}
	
	
	else if(tpt==71)
	{
		
	ttquest71();

	}
	else if(tpt==72)
	{
		
	ttquest72();

	}
	else if(tpt==73)
		
	{
	ttquest73();

	}

	else if(tpt==74)
		
	{
	ttquest74();

	}
	else if(tpt==75)
		
	{
	ttquest75();

	}

	else if(tpt==76)
		
	{
	ttquest76();

	}
	else if(tpt==77)
		
	{
	ttquest77();

	}
	else if(tpt==78)
		
	{
	ttquest78();

	}
	else if(tpt==79)
		
	{
	ttquest79();

	}
	else if(tpt==80)
		
	{
	ttquest80();

	}
	
	
	else if(tpt==81)
	{
		
	ttquest81();

	}
	else if(tpt==82)
	{
		
	ttquest82();

	}
	else if(tpt==83)
		
	{
	ttquest83();

	}

	else if(tpt==84)
		
	{
	ttquest84();

	}
	else if(tpt==85)
		
	{
	ttquest85();

	}

	else if(tpt==86)
		
	{
	ttquest86();

	}
	else if(tpt==87)
		
	{
	ttquest87();

	}
	else if(tpt==88)
		
	{
	ttquest88();

	}
	else if(tpt==89)
		
	{
	ttquest89();

	}
	else if(tpt==90)
		
	{
	ttquest90();

	}
	
	
	
	
	else if(tpt==91)
	{
		
	ttquest91();

	}
	else if(tpt==92)
	{
		
	ttquest92();

	}
	else if(tpt==93)
		
	{
	ttquest93();

	}

	else if(tpt==94)
		
	{
	ttquest94();

	}
	else if(tpt==95)
		
	{
	ttquest95();

	}

	else if(tpt==96)
		
	{
	ttquest96();

	}
	else if(tpt==97)
		
	{
	ttquest97();

	}
	else if(tpt==98)
		
	{
	ttquest98();

	}
	else if(tpt==99)
		
	{
	ttquest99();

	}
	else if(tpt==100)
		
	{
	ttquest100();

	}
	
	
	

	else if(tpt==101)
	{
		
	ttquest101();

	}
	else if(tpt==102)
	{
		
	ttquest102();

	}
	else if(tpt==103)
		
	{
	ttquest103();

	}

	else if(tpt==104)
		
	{
	ttquest104();

	}
	else if(tpt==105)
		
	{
	ttquest105();

	}

	else if(tpt==106)
		
	{
	ttquest106();

	}
	else if(tpt==107)
		
	{
	ttquest107();

	}
	else if(tpt==108)
		
	{
	ttquest108();

	}
	else if(tpt==109)
		
	{
	ttquest109();

	}
	else if(tpt==110)
		
	{
	ttquest110();

	}

	

	else if(tpt==111)
	{
		
	ttquest111();

	}
	else if(tpt==112)
	{
		
	ttquest112();

	}
	else if(tpt==113)
		
	{
	ttquest113();

	}

	else if(tpt==114)
		
	{
	ttquest114();

	}
	else if(tpt==115)
		
	{
	ttquest115();

	}

	else if(tpt==116)
		
	{
	ttquest116();

	}
	else if(tpt==117)
		
	{
	ttquest117();

	}
	else if(tpt==118)
		
	{
	ttquest118();

	}
	else if(tpt==119)
		
	{
	ttquest119();

	}
	else if(tpt==120)
		
	{
	ttquest120();

	}

	else if(tpt==121)
	{
		
	ttquest121();

	}
	else if(tpt==122)
	{
		
	ttquest122();

	}
	else if(tpt==123)
		
	{
	ttquest123();

	}

	else if(tpt==124)
		
	{
	ttquest124();

	}
	else if(tpt==125)
		
	{
	ttquest125();

	}

	else if(tpt==126)
		
	{
	ttquest126();

	}
	else if(tpt==127)
		
	{
	ttquest127();

	}
	else if(tpt==128)
		
	{
	ttquest128();

	}
	else if(tpt==129)
		
	{
	ttquest129();

	}
	else if(tpt==130)
		
	{
	ttquest130();

	}
	
	
	else if(tpt==131)
	{
		
	ttquest131();

	}
	else if(tpt==132)
	{
		
	ttquest132();

	}
	else if(tpt==133)
		
	{
	ttquest133();

	}

	else if(tpt==134)
		
	{
	ttquest134();

	}
	else if(tpt==135)
		
	{
	ttquest135();

	}

	else if(tpt==136)
		
	{
	ttquest136();

	}
	else if(tpt==137)
		
	{
	ttquest137();

	}
	else if(tpt==138)
		
	{
	ttquest138();

	}
	else if(tpt==139)
		
	{
	ttquest139();

	}
	else if(tpt==140)
		
	{
	ttquest140();

	}
	
	
	
	else if(tpt==141)
	{
		
	ttquest141();

	}
	else if(tpt==142)
	{
		
	ttquest142();

	}
	else if(tpt==143)
		
	{
	ttquest143();

	}

	else if(tpt==144)
		
	{
	ttquest144();

	}
	else if(tpt==145)
		
	{
	ttquest145();

	}

	else if(tpt==146)
		
	{
	ttquest146();

	}
	else if(tpt==147)
		
	{
	ttquest147();

	}
	else if(tpt==148)
		
	{
	ttquest148();

	}
	else if(tpt==149)
		
	{
	ttquest149();

	}
	else if(tpt==150)
		
	{
	ttquest150();

	}
	
	
	
	else if(tpt==151)
	{
		
	ttquest151();

	}
	else if(tpt==152)
	{
		
	ttquest152();

	}
	else if(tpt==153)
		
	{
	ttquest153();

	}

	else if(tpt==154)
		
	{
	ttquest154();

	}
	else if(tpt==155)
		
	{
	ttquest155();

	}

	else if(tpt==156)
		
	{
	ttquest156();

	}
	else if(tpt==157)
		
	{
	ttquest157();

	}
	else if(tpt==158)
		
	{
	ttquest158();

	}
	else if(tpt==159)
		
	{
	ttquest159();

	}
	else if(tpt==160)
		
	{
	ttquest160();

	}
	
	
	else if(tpt==161)
	{
		
	ttquest161();

	}
	else if(tpt==162)
	{
		
	ttquest162();

	}
	else if(tpt==163)
		
	{
	ttquest163();

	}

	else if(tpt==164)
		
	{
	ttquest164();

	}
	else if(tpt==165)
		
	{
	ttquest165();

	}

	else if(tpt==166)
		
	{
	ttquest166();

	}
	else if(tpt==167)
		
	{
	ttquest167();

	}
	else if(tpt==168)
		
	{
	ttquest168();

	}
	else if(tpt==169)
		
	{
	ttquest169();

	}
	else if(tpt==170)
		
	{
	ttquest170();

	}
	
	
	else if(tpt==171)
	{
		
	ttquest171();

	}
	else if(tpt==172)
	{
		
	ttquest172();

	}
	else if(tpt==173)
		
	{
	ttquest173();

	}

	else if(tpt==174)
		
	{
	ttquest174();

	}
	else if(tpt==175)
		
	{
	ttquest175();

	}

	else if(tpt==176)
		
	{
	ttquest176();

	}
	else if(tpt==177)
		
	{
	ttquest177();

	}
	else if(tpt==178)
		
	{
	ttquest178();

	}
	else if(tpt==179)
		
	{
	ttquest179();

	}
	else if(tpt==180)
		
	{
	ttquest180();

	}
	
	
	else if(tpt==181)
	{
		
	ttquest181();

	}
	else if(tpt==182)
	{
		
	ttquest182();

	}
	else if(tpt==183)
		
	{
	ttquest183();

	}

	else if(tpt==184)
		
	{
	ttquest184();

	}
	else if(tpt==185)
		
	{
	ttquest185();

	}

	else if(tpt==186)
		
	{
	ttquest186();

	}
	else if(tpt==187)
		
	{
	ttquest187();

	}
	else if(tpt==188)
		
	{
	ttquest188();

	}
	else if(tpt==189)
		
	{
	ttquest189();

	}
	else if(tpt==190)
		
	{
	ttquest190();

	}
	
	
	
	
	else if(tpt==191)
	{
		
	ttquest191();

	}
	else if(tpt==192)
	{
		
	ttquest192();

	}
	else if(tpt==193)
		
	{
	ttquest193();

	}

	else if(tpt==194)
		
	{
	ttquest194();

	}
	else if(tpt==195)
		
	{
	ttquest195();

	}

	else if(tpt==196)
		
	{
	ttquest196();

	}
	else if(tpt==197)
		
	{
	ttquest197();

	}
	else if(tpt==198)
		
	{
	ttquest198();

	}
	else if(tpt==199)
		
	{
	ttquest199();

	}
	else if(tpt==200)
		
	{
	ttquest200();

	}
	
	
	
	
	else if(tpt==201)
	{
		
	ttquest201();

	}
	
	else if(tpt==202)
	{
		
	ttquest202();

	}
	else if(tpt==203)
		
	{
	ttquest203();

	}

	else if(tpt==204)
		
	{
	ttquest204();

	}
	else if(tpt==205)
		
	{
	ttquest205();

	}

	else if(tpt==206)
		
	{
	ttquest206();

	}
	else if(tpt==207)
		
	{
	ttquest207();

	}
	else if(tpt==208)
		
	{
	ttquest208();

	}
	else if(tpt==209)
		
	{
	ttquest209();

	}
	else if(tpt==210)
		
	{
	ttquest210();

	}


	else if(tpt==211)
	{
		
	ttquest211();

	}
	else if(tpt==212)
	{
		
	ttquest212();

	}
	else if(tpt==213)
		
	{
	ttquest213();

	}

	else if(tpt==214)
		
	{
	ttquest214();

	}
	else if(tpt==215)
		
	{
	ttquest215();

	}

	else if(tpt==216)
		
	{
	ttquest216();

	}
	else if(tpt==217)
		
	{
	ttquest217();

	}
	else if(tpt==218)
		
	{
	ttquest218();

	}
	else if(tpt==219)
		
	{
	ttquest219();

	}
	else if(tpt==220)
		
	{
	ttquest220();

	}

	
	else if(tpt==221)
	{
		
	ttquest221();

	}
	else if(tpt==222)
	{
		
	ttquest222();

	}
	else if(tpt==223)
		
	{
	ttquest223();

	}

	else if(tpt==224)
		
	{
	ttquest224();

	}
	else if(tpt==225)
		
	{
	ttquest225();

	}

	else if(tpt==226)
		
	{
	ttquest226();

	}
	else if(tpt==227)
		
	{
	ttquest227();

	}
	else if(tpt==228)
		
	{
	ttquest228();

	}
	else if(tpt==229)
		
	{
	ttquest229();

	}
	else if(tpt==230)
		
	{
	ttquest230();

	}

	
	else if(tpt==231)
	{
		
	ttquest231();

	}
	else if(tpt==232)
	{
		
	ttquest232();

	}
	else if(tpt==233)
		
	{
	ttquest233();

	}

	else if(tpt==234)
		
	{
	ttquest234();

	}
	else if(tpt==235)
		
	{
	ttquest235();

	}

	else if(tpt==236)
		
	{
	ttquest236();

	}
	else if(tpt==237)
		
	{
	ttquest237();

	}
	else if(tpt==238)
		
	{
	ttquest238();

	}
	else if(tpt==239)
		
	{
	ttquest239();

	}
	else if(tpt==240)
		
	{
	ttquest240();

	}


	else if(tpt==241)
	{
		
	ttquest241();

	}
	else if(tpt==242)
	{
		
	ttquest242();

	}
	else if(tpt==243)
		
	{
	ttquest243();

	}

	else if(tpt==244)
		
	{
	ttquest244();

	}
	else if(tpt==245)
		
	{
	ttquest245();

	}

	else if(tpt==246)
		
	{
	ttquest246();

	}
	else if(tpt==247)
		
	{
	ttquest247();

	}
	else if(tpt==248)
		
	{
	ttquest248();

	}
	else if(tpt==249)
		
	{
	ttquest249();

	}
	else if(tpt==250)
		
	{
	ttquest250();

	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}







	
	
function tat()
{


var a = document.getElementById("tat").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "a";
}


	
function tbt()
{


var a = document.getElementById("tbt").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "b";
}



function tct()
{


var a = document.getElementById("tct").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "c";
}





function tdt()
{


var a = document.getElementById("tdt").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "d";
}



function tet()
{

var a = document.getElementById("tet").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "e";
}



function tft()
{

var a = document.getElementById("tft").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "f";
}

function tgt()
{

var a = document.getElementById("tgt").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "g";
}

function tht()
{

var a = document.getElementById("tht").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "h";
}

function tit()
{

var a = document.getElementById("tit").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "i";
}

function tjt()
{

var a = document.getElementById("tjt").value;

tsagott = tsagott + a;

document.getElementById("tanst").innerHTML = tsagott;
let_num5 = let_num5 + "j";
}




function tresett()
{


tsagott = "";

document.getElementById("tanst").innerHTML = tsagott;
}




function ttquest31()
{

	document.getElementById('tquestiont').innerHTML="Baston ng kapitan, Hindi mahawakan.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="c";
	document.getElementById('tbt').value="c";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="y";
	document.getElementById('tgt').value="y";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="h";
	document.getElementById('tit').value="h";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "ahas";



	}

	
	
	
function ttquest2()
{

	document.getElementById('tquestiont').innerHTML="Heto na si kuya, May sunong sa baga";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="p";
	document.getElementById('tft').value="p";
	document.getElementById('tgt').innerHTML="i";
	document.getElementById('tgt').value="i";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alitaptap";




	}

	
	
	
	
	
	
function ttquest3()
{

	document.getElementById('tquestiont').innerHTML="Ang loob ay pilak, Siit namimilipit, Ginto't pilak namumulaklak.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="e";
	document.getElementById('tbt').value="e";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="l";
	document.getElementById('tdt').value="l";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="d";
	document.getElementById('tft').value="d";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="m";
	document.getElementById('tht').value="m";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="p";
	document.getElementById('tjt').value="p";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "ampalaya";


	}

	
	
	
	
	
function ttquest4()
{

	document.getElementById('tquestiont').innerHTML="Ako'y may kaibigan, Kasama ko kahit saan, Mapatubig ay di nalulunod, Mapaapoy ay di nasusunog.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="m";
	document.getElementById('tdt').value="m";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "anino";



	}

	
			
		function ttquest5()
{

	document.getElementById('tquestiont').innerHTML="Hindi hayop, hindi tao, Hindi natin kaano-ano, Ate nating pareho.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="c";
	document.getElementById('tft').value="c";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="d";
	document.getElementById('tit').value="d";
	document.getElementById('tjt').innerHTML="n";
	document.getElementById('tjt').value="n";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "atis";


	}

	
	
	
	
	
	
	
	
		function ttquest6()
{

	document.getElementById('tquestiont').innerHTML= "Tubig na nagiging bato, Bato na nagiging tubig.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="m";
	document.getElementById('tdt').value="m";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="c";
	document.getElementById('tft').value="c";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "asin";



	}

	
	
		
		function ttquest7()
{

	document.getElementById('tquestiont').innerHTML= "Mataas ang paupo, Kesa patayo.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="c";
	document.getElementById('tft').value="c";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "aso";




	}

	
	
		
		function ttquest8()
{

	document.getElementById('tquestiont').innerHTML="Dinadala ko siya, Dinadala ako niya.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="e";
	document.getElementById('tet').value="e";
	document.getElementById('tft').innerHTML="y";
	document.getElementById('tft').value="y";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bakya";


	}

	
	
			
		function ttquest9()
{

	document.getElementById('tquestiont').innerHTML="Alin dito sa buong lupa, Kung lumakad ay tihaya.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="c";
	document.getElementById('tft').value="c";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bangka";



	}

	
	
	
				
		function ttquest10()
{

	document.getElementById('tquestiont').innerHTML="Nakalantay kung gabi, Kung araw ay nakatabi.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="x";
	document.getElementById('tgt').value="x";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "banig";


	}

	
		
				
		function ttquest11()
{

	document.getElementById('tquestiont').innerHTML="Walang bibig, walang pakpak, kahit hari'y kinakausap?";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="x";
	document.getElementById('tgt').value="x";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "aklat";


	}

	
	
				
		function ttquest12()
{

	document.getElementById('tquestiont').innerHTML="Isang biyas ng kawayan, Maraming lamang kayamanan ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="s";
	document.getElementById('tgt').value="s";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="y";
	document.getElementById('tit').value="y";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alkansya";


	}

	
			function ttquest13()
{

	document.getElementById('tquestiont').innerHTML="Heto , heto na, Malayo pa’y humahalakhak na. ";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="c";
	document.getElementById('tct').value="c";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="y";
	document.getElementById('tit').value="y";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alon";


	}

	
	
	
		
			function ttquest14()
{

	document.getElementById('tquestiont').innerHTML="Pagkatapos na ang reyna'y Makapagpagawa ng templo, Siya na rin ang napreso.";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="c";
	document.getElementById('tct').value="c";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="y";
	document.getElementById('tit').value="y";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "anay";


	}

	
	
	
	
		
			function ttquest15()
{

	document.getElementById('tquestiont').innerHTML="Mayroon akong matapat na alipin, Sunod nang sunod sa akin.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "anino";


	}

	
	
		
		
			function ttquest16()
{

	document.getElementById('tquestiont').innerHTML="Manok kong pula, Inutusan ko ng umaga, Nang umuwi'y gabi na.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="r";
	document.getElementById('tdt').value="r";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="w";
	document.getElementById('tht').value="w";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "araw";


	}

	
	
			
		
			function ttquest17()
{

	document.getElementById('tquestiont').innerHTML="Buhay na hiram lamang, Pinagmulan ng sangkatauhan. ";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="r";
	document.getElementById('tdt').value="r";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="f";
	document.getElementById('tgt').value="f";
	document.getElementById('tht').innerHTML="e";
	document.getElementById('tht').value="e";
	document.getElementById('tit').innerHTML="d";
	document.getElementById('tit').value="d";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "babae";


	}

	
	
	
			
			function ttquest18()
{

	document.getElementById('tquestiont').innerHTML="Tubig kung sa isda, Lungga kung sa daga, Kung sa tao'y ano kaya.";
	document.getElementById('tat').innerHTML="x";
	document.getElementById('tat').value="x";
	document.getElementById('tbt').innerHTML="d";
	document.getElementById('tbt').value="d";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="y";
	document.getElementById('tet').value="y";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="f";
	document.getElementById('tgt').value="f";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="d";
	document.getElementById('tit').value="d";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bahay";


	}

	
	
	
			
			function ttquest19()
{

	document.getElementById('tquestiont').innerHTML="Kung dumating ang bisita ko, Dumarating din ang sa inyo.";
	document.getElementById('tat').innerHTML="w";
	document.getElementById('tat').value="w";
	document.getElementById('tbt').innerHTML="r";
	document.getElementById('tbt').value="r";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="y";
	document.getElementById('tet').value="y";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="r";
	document.getElementById('tgt').value="r";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="x";
	document.getElementById('tjt').value="x";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "araw";



	}

	
	
		
			
			function ttquest20()
{

	document.getElementById('tquestiont').innerHTML="Isang biyas ng kawayan, Ang laman ay kamatayan.";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="r";
	document.getElementById('tbt').value="r";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="y";
	document.getElementById('tet').value="y";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "baril";


	}

	
	
	
				
			function ttquest1()
{

	document.getElementById('tquestiont').innerHTML="May katawa'y walang bituka, May puwit walang paa, Nakakagat tuwina.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="o";
	document.getElementById('tet').value="o";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="p";
	document.getElementById('tgt').value="p";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "baso";

	}

	
	
				
			function ttquest22()
{

	document.getElementById('tquestiont').innerHTML="Buhay na hindi kumikibo, Patay na hindi bumabaho.";
	document.getElementById('tat').innerHTML="t";
	document.getElementById('tat').value="t";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="x";
	document.getElementById('tit').value="x";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bato";


	}

		
	
	
		
				
			function ttquest23()
{

	document.getElementById('tquestiont').innerHTML="Isang balong malalim, Punong-puno ng patalim.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="b";
	document.getElementById('tgt').value="b";
	document.getElementById('tht').innerHTML="c";
	document.getElementById('tht').value="c";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bibig";


	}

		
					
			function ttquest24()
{

	document.getElementById('tquestiont').innerHTML="Palayok ni isko, Punong-puno ng bato.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="y";
	document.getElementById('tdt').value="y";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="b";
	document.getElementById('tgt').value="b";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="d";
	document.getElementById('tjt').value="d";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bayabas";


	}

		
	
	
						
			function ttquest25()
{

	document.getElementById('tquestiont').innerHTML="Nagsasaing si pusong, Sa ibabaw ang tutong.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bibingka";


	}

		
	
	
						
			function ttquest26()
{

	document.getElementById('tquestiont').innerHTML="Alin sa buong katawan, Nasa likod ang tiyan.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="n";
	document.getElementById('tct').value="n";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="x";
	document.getElementById('tit').value="x";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "binti";


	}

		
	
							
			function ttquest27()
{

	document.getElementById('tquestiont').innerHTML="Itinanim sa kagabihan, Inani sa kaumagahan.";
	document.getElementById('tat').innerHTML="u";
	document.getElementById('tat').value="u";
	document.getElementById('tbt').innerHTML="d";
	document.getElementById('tbt').value="d";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="x";
	document.getElementById('tit').value="x";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bituin";


	}

		
								
			function ttquest28()
{

	document.getElementById('tquestiont').innerHTML="Kung di pa sa liig pinigilan, Di pa ako bibigyan.";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="e";
	document.getElementById('tht').value="e";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bote";


	}


		
								
			function ttquest29()
{

	document.getElementById('tquestiont').innerHTML="Kung sa ilan walang kwenta, Sa gusali mahalaga. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="e";
	document.getElementById('tht').value="e";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bato";


	}

				
	
		
								
			function ttquest29()
{

	document.getElementById('tquestiont').innerHTML="Kung sa ilan walang kwenta, Sa gusali mahalaga. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="e";
	document.getElementById('tht').value="e";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bato";


	}

				
	
	
	
		
								
			function ttquest30()
{

	document.getElementById('tquestiont').innerHTML="Heto na si lulong, Bubulong bulong.";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="o";
	document.getElementById('tft').value="o";
	document.getElementById('tgt').innerHTML="y";
	document.getElementById('tgt').value="y";
	document.getElementById('tht').innerHTML="e";
	document.getElementById('tht').value="e";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bubuyog";


	}

				
	
	
								
			function ttquest21()
{

	document.getElementById('tquestiont').innerHTML="Inisip ng marunong, Sinabi ng gunggong.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="o";
	document.getElementById('tft').value="o";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="e";
	document.getElementById('tht').value="e";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bugtong";


	}

				
	
	
								
			function ttquest32()
{

	document.getElementById('tquestiont').innerHTML="Nagsaing si kuruktong, Kumuloy walang gatong.";
	document.getElementById('tat').innerHTML="n";
	document.getElementById('tat').value="n";
	document.getElementById('tbt').innerHTML="e";
	document.getElementById('tbt').value="e";
	document.getElementById('tct').innerHTML="h";
	document.getElementById('tct').value="h";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="b";
	document.getElementById('tgt').value="b";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sabon";


	}
	
	
							
			function ttquest33()
{

	document.getElementById('tquestiont').innerHTML="Isang pinggan, laganapSa buong bayan.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="w";
	document.getElementById('tft').value="w";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="r";
	document.getElementById('tjt').value="r";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "buwan";


	}

	
		function ttquest34()
{

	document.getElementById('tquestiont').innerHTML="Mahabang-mahaba, tinutungtungan ng madla.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="d";
	document.getElementById('tet').value="d";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="d";
	document.getElementById('tgt').value="d";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="h";
	document.getElementById('tjt').value="h";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "daan";


	}
	
	
	
	
	
	
		function ttquest35()
{

	document.getElementById('tquestiont').innerHTML="Nagtanim ako ng dayap, sa gitna ng dagat, marami ang nagsihanap, iisa ang nagkapalad.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="d";
	document.getElementById('tet').value="d";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="d";
	document.getElementById('tgt').value="d";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "dalaga";


	}
	
	
	
		function ttquest36()
{

	document.getElementById('tquestiont').innerHTML="Limang punong niyog, iisa ang matayog.";
	document.getElementById('tat').innerHTML="w";
	document.getElementById('tat').value="w";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="h";
	document.getElementById('tdt').value="h";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="d";
	document.getElementById('tgt').value="d";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "daliri";


	}
	
	
		function ttquest37()
{

	document.getElementById('tquestiont').innerHTML="Munting uling, bibitin-bitin, masarap kanin, mahirap kunin.";
	document.getElementById('tat').innerHTML="d";
	document.getElementById('tat').value="d";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="h";
	document.getElementById('tdt').value="h";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="d";
	document.getElementById('tgt').value="d";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="s";
	document.getElementById('tit').value="s";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "duhat";


	}


	
		function ttquest38()
{

	document.getElementById('tquestiont').innerHTML="Nang maliit ay kastila, nang tumanda ay baluga.";
	document.getElementById('tat').innerHTML="d";
	document.getElementById('tat').value="d";
	document.getElementById('tbt').innerHTML="d";
	document.getElementById('tbt').value="d";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="u";
	document.getElementById('tgt').value="u";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="s";
	document.getElementById('tit').value="s";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "duling";


	}

	
		function ttquest39()
{

	document.getElementById('tquestiont').innerHTML="Takbo roon, takbo rito, hindi makaalis sa tayong ito.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="d";
	document.getElementById('tbt').value="d";
	document.getElementById('tct').innerHTML="m";
	document.getElementById('tct').value="m";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="y";
	document.getElementById('tet').value="y";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="u";
	document.getElementById('tgt').value="u";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="s";
	document.getElementById('tit').value="s";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "duyan";


	}

	
	
		function ttquest40()
{

	document.getElementById('tquestiont').innerHTML="Isang hayop na maliit, dumudumi ng sinulid.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="u";
	document.getElementById('tgt').value="u";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gagamba";


	}


	
	
		function ttquest41()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni San Vicente , punong-puno ng diamante.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="r";
	document.getElementById('tit').value="r";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "granada";



	}

	
	
		function ttquest42()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni San Vicente , punong-puno ng diamante.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="r";
	document.getElementById('tit').value="r";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "granada";


	}

	
		function ttquest43()
{

	document.getElementById('tquestiont').innerHTML="Nagsaing si kurukutong, bumubula’y walang gatong.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="r";
	document.getElementById('tit').value="r";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gugo";


	}

	
	
		function ttquest44()
{

	document.getElementById('tquestiont').innerHTML="Aso kong si pula, sumampa sa sanga, nag pakita ng ganda.";
	document.getElementById('tat').innerHTML="e";
	document.getElementById('tat').value="e";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="m";
	document.getElementById('tht').value="m";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="e";
	document.getElementById('tjt').value="e";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gumamela";


	}

	
	
		function ttquest45()
{

	document.getElementById('tquestiont').innerHTML="Heto na si kaka, bibika-bikaka.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="n";
	document.getElementById('tct').value="n";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gunting";


	}


	
		function ttquest46()
{

	document.getElementById('tquestiont').innerHTML="Dalawang katawan, tagusan ang tadyang.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="h";
	document.getElementById('tct').value="h";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="d";
	document.getElementById('tft').value="d";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "hagdan";



	}
	
	
		function ttquest47()
{

	document.getElementById('tquestiont').innerHTML="Karga ng karga; walang renta.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="y";
	document.getElementById('tbt').value="y";
	document.getElementById('tct').innerHTML="h";
	document.getElementById('tct').value="h";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="d";
	document.getElementById('tft').value="d";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "haligi";


	}



	
	
	
	function ttquest48()
{

	document.getElementById('tquestiont').innerHTML="Heto na, heto na, di mo nakikita.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="h";
	document.getElementById('tbt').value="h";
	document.getElementById('tct').innerHTML="h";
	document.getElementById('tct').value="h";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="p";
	document.getElementById('tft').value="p";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="j";
	document.getElementById('tit').value="j";
	document.getElementById('tjt').innerHTML="n";
	document.getElementById('tjt').value="n";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "hangin";


	}

	
	
	
	function ttquest49()
{

	document.getElementById('tquestiont').innerHTML="Dalawang ibong marikit, nagtitimbangan ng siit.";
	document.getElementById('tat').innerHTML="w";
	document.getElementById('tat').value="w";
	document.getElementById('tbt').innerHTML="h";
	document.getElementById('tbt').value="h";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="h";
	document.getElementById('tit').value="h";
	document.getElementById('tjt').innerHTML="x";
	document.getElementById('tjt').value="x";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "hikaw";


	}
	
	
	
	function ttquest50()
{

	document.getElementById('tquestiont').innerHTML="Isang butil ng palay, buong bahay ay nakakalatan.";
	document.getElementById('tat').innerHTML="w";
	document.getElementById('tat').value="w";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="m";
	document.getElementById('tht').value="m";
	document.getElementById('tit').innerHTML="y";
	document.getElementById('tit').value="y";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "ilaw";


	}

	
	function ttquest51()
{

	document.getElementById('tquestiont').innerHTML="Dalawang libing, laging may hangin.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="g";
	document.getElementById('tft').value="g";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="m";
	document.getElementById('tht').value="m";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="n";
	document.getElementById('tjt').value="n";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "ilong";


	}

	
	
	
	function ttquest52()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni Kiko, walang bintana, walang pinto.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="e";
	document.getElementById('tft').value="e";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="m";
	document.getElementById('tht').value="m";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="p";
	document.getElementById('tjt').value="p";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "itlog";



	}


	
	
	function ttquest53()
{

	document.getElementById('tquestiont').innerHTML="Binili ko nang di kagustuhan,Ginamit ko nang di nalalaman.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="b";
	document.getElementById('tet').value="b";
	document.getElementById('tft').innerHTML="e";
	document.getElementById('tft').value="e";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="o";
	document.getElementById('tit').value="o";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kabaong";


	}

	
		
	function ttquest54()
{

	document.getElementById('tquestiont').innerHTML="May binti walang hita,May tuktok walang mukha.";
	document.getElementById('tat').innerHTML="e";
	document.getElementById('tat').value="e";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="b";
	document.getElementById('tet').value="b";
	document.getElementById('tft').innerHTML="e";
	document.getElementById('tft').value="e";
	document.getElementById('tgt').innerHTML="f";
	document.getElementById('tgt').value="f";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="u";
	document.getElementById('tit').value="u";
	document.getElementById('tjt').innerHTML="r";
	document.getElementById('tjt').value="r";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kabute";


	}

	
	
		
	function ttquest55()
{

	document.getElementById('tquestiont').innerHTML="Ang ina’y gumagapang pa, Ang anak ay umuupo na.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="b";
	document.getElementById('tet').value="b";
	document.getElementById('tft').innerHTML="s";
	document.getElementById('tft').value="s";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kalabasa";


	}
	
	
	function ttquest56()
{

	document.getElementById('tquestiont').innerHTML="Araw araw bagong buhay,Taun-taon namamatay.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="d";
	document.getElementById('tct').value="d";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="e";
	document.getElementById('tft').value="e";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="r";
	document.getElementById('tht').value="r";
	document.getElementById('tit').innerHTML="o";
	document.getElementById('tit').value="o";
	document.getElementById('tjt').innerHTML="n";
	document.getElementById('tjt').value="n";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kalendaryo";


	}
	
	
	function ttquest57()
{

	document.getElementById('tquestiont').innerHTML="Putukan nang putukan,hindi nag kakarinigan.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="p";
	document.getElementById('tct').value="p";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="e";
	document.getElementById('tft').value="e";
	document.getElementById('tgt').innerHTML="b";
	document.getElementById('tgt').value="b";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="n";
	document.getElementById('tjt').value="n";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kampana";


	}
	
	
	
	function ttquest58()
{

	document.getElementById('tquestiont').innerHTML="Akoy ma’y kasama sa pahingi ng awa; ako’y di umiyak, siya ay lumuha.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="e";
	document.getElementById('tft').value="e";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kandila";


	}
	
	
	
	function ttquest59()
{

	document.getElementById('tquestiont').innerHTML="Isang senyora,nakaupo sa tasa.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="s";
	document.getElementById('tft').value="s";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="c";
	document.getElementById('tjt').value="c";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kasoy";

	}
	
	
	function ttquest60()
{

	document.getElementById('tquestiont').innerHTML="Anong halaman ang sagana sa ugat, dahon, at sanga,ngunit wala sa bunga.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="f";
	document.getElementById('tdt').value="f";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="w";
	document.getElementById('tjt').value="w";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kawayan";


	}
	
	
	
	
	function ttquest61()
{

	document.getElementById('tquestiont').innerHTML="Ma-tag-init, ma-tag-ulan,dala-dala’y balutan.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kuba";


	}
	
	
	
	function ttquest62()
{

	document.getElementById('tquestiont').innerHTML="Naabot na ng kamay,iginawa pa ng tulay.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="r";
	document.getElementById('tet').value="r";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="e";
	document.getElementById('tht').value="e";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kubyertos";


	}
	
	
	function ttquest63()
{

	document.getElementById('tquestiont').innerHTML="Limang mag kakapatid,tig-tig-isa ng silid.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="y";
	document.getElementById('tdt').value="y";
	document.getElementById('tet').innerHTML="k";
	document.getElementById('tet').value="k";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kuko";


	}
	
	
	
	
	function ttquest64()
{

	document.getElementById('tquestiont').innerHTML="May hita ay walang binti,may ngipin ay walang labi.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="d";
	document.getElementById('tct').value="d";
	document.getElementById('tdt').innerHTML="r";
	document.getElementById('tdt').value="r";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="u";
	document.getElementById('tjt').value="u";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kudkuran";



	}
	
	
	
	
	function ttquest65()
{

	document.getElementById('tquestiont').innerHTML="Maliit pa si kumara,marunong ng humuni.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="i";
	document.getElementById('tgt').value="i";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kuliglig";


	}
	
	
	
	function ttquest66()
{

	document.getElementById('tquestiont').innerHTML="Baka ko sa Maynila abot dito ang unga.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="i";
	document.getElementById('tgt').value="i";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kulog";


	}
	
	
		function ttquest67()
{

	document.getElementById('tquestiont').innerHTML="Aling paa ang nasa ulo?";
	document.getElementById('tat').innerHTML="t";
	document.getElementById('tat').value="t";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="d";
	document.getElementById('tit').value="d";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kuto";


	}
	
	
		function ttquest68()
{

	document.getElementById('tquestiont').innerHTML="Kadena’y isinabit,sa batok nakakawit.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="k";
	document.getElementById('tdt').value="k";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kwintas";


	}
	
	
	function ttquest69()
{

	document.getElementById('tquestiont').innerHTML="Kung saan masikip doon nagpipilit.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="b";
	document.getElementById('tgt').value="b";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="v";
	document.getElementById('tjt').value="v";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "labong";


	}
	
	
	
	function ttquest70()
{

	document.getElementById('tquestiont').innerHTML="Itulak at hilahin,sigurado ang kain.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="b";
	document.getElementById('tgt').value="b";
	document.getElementById('tht').innerHTML="r";
	document.getElementById('tht').value="r";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "lagari";


	}
	
	
	
	function ttquest71()
{

	document.getElementById('tquestiont').innerHTML="Butas na tinagpian ng kapuwa butas.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="m";
	document.getElementById('tdt').value="m";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="b";
	document.getElementById('tgt').value="b";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="p";
	document.getElementById('tjt').value="p";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "lambat";


	}
	
	
	
	function ttquest72()
{

	document.getElementById('tquestiont').innerHTML="Kung kailan tahimik saka nambubuwisit.";
	document.getElementById('tat').innerHTML="h";
	document.getElementById('tat').value="h";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="m";
	document.getElementById('tdt').value="m";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="r";
	document.getElementById('tit').value="r";
	document.getElementById('tjt').innerHTML="o";
	document.getElementById('tjt').value="o";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "lamok";


	}
	
	
	function ttquest73()
{

	document.getElementById('tquestiont').innerHTML="Naghain si Lolo,unang dumulog ang tukso.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="m";
	document.getElementById('tdt').value="m";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="w";
	document.getElementById('tjt').value="w";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "langaw";


	}
	
	
	function ttquest74()
{

	document.getElementById('tquestiont').innerHTML="Baboy ko sa Marungko,balahibo'y pako.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="z";
	document.getElementById('tft').value="z";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "langka";


	}
	
	
	
	function ttquest75()
{

	document.getElementById('tquestiont').innerHTML="Munting-munti lang na hayop uliran sa pag-impok.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="z";
	document.getElementById('tft').value="z";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "langgam";


	}
	
	
	function ttquest76()
{

	document.getElementById('tquestiont').innerHTML="Aso kong si puti,inutusan ko'y hindi na umuwi.";
	document.getElementById('tat').innerHTML="n";
	document.getElementById('tat').value="n";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="y";
	document.getElementById('tdt').value="y";
	document.getElementById('tet').innerHTML="y";
	document.getElementById('tet').value="y";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="o";
	document.getElementById('tjt').value="o";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "laway";


	}
	
	
	function ttquest77()
{

	document.getElementById('tquestiont').innerHTML="Mayroon akong gatang,hindi ko matingnan.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="j";
	document.getElementById('tht').value="j";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="e";
	document.getElementById('tjt').value="e";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "leeg";


	}
	
	
	
	
	function ttquest78()
{

	document.getElementById('tquestiont').innerHTML="Nahihiya, walang kinahihiyaan.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="h";
	document.getElementById('tct').value="h";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "makahiya";


	}
	
	
	
	
	function ttquest79()
{

	document.getElementById('tquestiont').innerHTML="May sunong, may kilik, may salakab sa puwit.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="j";
	document.getElementById('tgt').value="j";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="f";
	document.getElementById('tit').value="f";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mais";

	}
	
	
	
	
	function ttquest80()
{

	document.getElementById('tquestiont').innerHTML="Pusong bibitin-bitin,mabangong parang hasmin,masarap kanin.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="g";
	document.getElementById('tft').value="g";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mangga";


	}
	
	
	
	function ttquest81()
{

	document.getElementById('tquestiont').innerHTML="Pusong bibitin-bitin,mabangong parang hasmin,masarap kanin.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="g";
	document.getElementById('tft').value="g";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mangga";


	}
	
	
	
		
	function ttquest82()
{

	document.getElementById('tquestiont').innerHTML="Tag-ulan at tag-arawhanggang tuhod ng salawal.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="a";
	document.getElementById('tct').value="a";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="g";
	document.getElementById('tft').value="g";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="n";
	document.getElementById('tjt').value="n";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "manok";


	}
	
	
	
	function ttquest83()
{

	document.getElementById('tquestiont').innerHTML="Dalawang bolang sinulid,abot hanggang langit.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="j";
	document.getElementById('tct').value="j";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="s";
	document.getElementById('tit').value="s";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mata";

	}
	
	
	function ttquest84()
{

	document.getElementById('tquestiont').innerHTML="Ang mukha'y parang tao,magaling lumukso.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="j";
	document.getElementById('tct').value="j";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="s";
	document.getElementById('tit').value="s";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "matsing";


	}
	
	
	
	function ttquest85()
{

	document.getElementById('tquestiont').innerHTML="Kastila kung natutulog kapag gising ay tagalog.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mantika";


	}
	
	
	function ttquest86()
{

	document.getElementById('tquestiont').innerHTML="Maliit pa si Tsikito,marunong nang manukso.";
	document.getElementById('tat').innerHTML="l";
	document.getElementById('tat').value="l";
	document.getElementById('tbt').innerHTML="q";
	document.getElementById('tbt').value="q";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="y";
	document.getElementById('tft').value="y";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="t";
	document.getElementById('tit').value="t";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "lamok";


	}
	
	
	function ttquest87()
{

	document.getElementById('tquestiont').innerHTML="Noong bata ay nag saya,at naghubo nung dalaga.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="y";
	document.getElementById('tbt').value="y";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="w";
	document.getElementById('tet').value="w";
	document.getElementById('tft').innerHTML="y";
	document.getElementById('tft').value="y";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="n";
	document.getElementById('tjt').value="n";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kawayan";


	}
	
	
	
		
	function ttquest88()
{

	document.getElementById('tquestiont').innerHTML="Nang aking mapatay,lalong humaba ang buhay.";
	document.getElementById('tat').innerHTML="n";
	document.getElementById('tat').value="n";
	document.getElementById('tbt').innerHTML="d";
	document.getElementById('tbt').value="d";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="m";
	document.getElementById('tht').value="m";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kandila";


	}
	
	
	function ttquest89()
{

	document.getElementById('tquestiont').innerHTML="Bugtong-bugtong,Magkakarugtong.";
	document.getElementById('tat').innerHTML="t";
	document.getElementById('tat').value="t";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="m";
	document.getElementById('tht').value="m";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "tanikala";


	}
	
	
	
		function ttquest90()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni Kiko, walang bintana, walang pinto.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="m";
	document.getElementById('tit').value="m";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "itlog";


	}
	
	
	
	
	
		function ttquest91()
{

	document.getElementById('tquestiont').innerHTML="Dalawang magkaibigan, may talim ang tiyan; matagal ng nagkakagatan di pa nagkakasakitan.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="u";
	document.getElementById('tjt').value="u";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gunting";


	}
	
	
	
		function ttquest92()
{

	document.getElementById('tquestiont').innerHTML="Malaki kung bata, maliit kung matanda dahil sa kahahasa.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="r";
	document.getElementById('tgt').value="r";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "itak";


	}
	
	
	
	
		function ttquest93()
{

	document.getElementById('tquestiont').innerHTML="nagbabahay si maitim, walang haliging itinanim.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gagamba";


	}
	
	
	
	
		function ttquest94()
{

	document.getElementById('tquestiont').innerHTML="Kung di pa sa liig pinigilan, Di pa ako bibigyan.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bote";


	}
	
	
	
	
		function ttquest95()
{

	document.getElementById('tquestiont').innerHTML="Itinanim sa kagabihan, Inani sa kaumagahan.";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bituin";


	}
	
	
	
	
		function ttquest96()
{

	document.getElementById('tquestiont').innerHTML="Alin sa buong katawan, Nasa likod ang tiyan.";
	document.getElementById('tat').innerHTML="j";
	document.getElementById('tat').value="j";
	document.getElementById('tbt').innerHTML="r";
	document.getElementById('tbt').value="r";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "binti";


	}
	
	
	
	
		function ttquest97()
{

	document.getElementById('tquestiont').innerHTML="Nagsasaing si pusong, Sa ibabaw ang tutong.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="q";
	document.getElementById('tct').value="q";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="b";
	document.getElementById('tet').value="b";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bibingka";


	}
	
	
	
	
	function ttquest98()
{

	document.getElementById('tquestiont').innerHTML="Buhay na hindi kumikibo, Patay na hindi bumabaho.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="y";
	document.getElementById('tet').value="y";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bato";


	}
	
	
		function ttquest99()
{

	document.getElementById('tquestiont').innerHTML="Nakalantay kung gabi, Kung araw ay nakatabi.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="y";
	document.getElementById('tgt').value="y";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "banig";


	}

	
	

	
	function ttquest100()
{

	document.getElementById('tquestiont').innerHTML="Tubig na nagiging bato, Bato na nagiging tubig.";
	document.getElementById('tat').innerHTML="n";
	document.getElementById('tat').value="n";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="s";
	document.getElementById('tgt').value="s";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="o";
	document.getElementById('tjt').value="o";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "asin";


	}
	
	
	
	
		
	
	
		function ttquest101()
{

	document.getElementById('tquestiont').innerHTML="Bastong hindi mahawak-hawakan, sinturong walang mapaggamit-gamitan. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="h";
	document.getElementById('tjt').value="h";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "ahas";



	}
	
	
	
		function ttquest102()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni ka huli, haligi'y balibali, ang bubong ay kawali. ";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="r";
	document.getElementById('tgt').value="r";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alimango";



	}
	
	
	
	
		function ttquest103()
{

	document.getElementById('tquestiont').innerHTML="Kahit hindi tayo magkaano-ano, ang gatas ng anak ko, ay gatas din ng anak mo.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "baka";



	}
	
	
	
	
		function ttquest104()
{

	document.getElementById('tquestiont').innerHTML="Ibon kong saan man makarating, makababalik kung saan nanggaling. ";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kalapati";



	}
	
	
	
	
		function ttquest105()
{

	document.getElementById('tquestiont').innerHTML="Bagama't maliit, marunong nang umawit. ";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kuliglig";



	}
	
	
	
	
		function ttquest106()
{

	document.getElementById('tquestiont').innerHTML="Dala mo't sunong, ikaw rin ang baon. ";
	document.getElementById('tat').innerHTML="j";
	document.getElementById('tat').value="j";
	document.getElementById('tbt').innerHTML="r";
	document.getElementById('tbt').value="r";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kuto";



	}
	
	
	
	
		function ttquest107()
{

	document.getElementById('tquestiont').innerHTML="Ang abot ng paa ko'y abot rin ng ilong ko? Hulaan mo, anong hayop ako.";
	document.getElementById('tat').innerHTML="e";
	document.getElementById('tat').value="e";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="p";
	document.getElementById('tct').value="p";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="e";
	document.getElementById('tjt').value="e";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "elepante";



	}
	
	
	
	
	function ttquest108()
{

	document.getElementById('tquestiont').innerHTML="Kung manahi'y nagbabaging at sa gitna'y tumitigil. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gagamba";



	}
	
	
		function ttquest109()
{

	document.getElementById('tquestiont').innerHTML="Kulisap na lilipad-lipad, sa ningas ng liwanag ay isang pangahas. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="m";
	document.getElementById('tet').value="m";
	document.getElementById('tft').innerHTML="o";
	document.getElementById('tft').value="o";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="m";
	document.getElementById('tht').value="m";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gamogamo";



	}

	
	

	
	function ttquest110()
{

	document.getElementById('tquestiont').innerHTML="Isang uod na puro balahibo, kapag nadikit sa iyo ang ulo, tiyak mangangati ang balat mo.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="d";
	document.getElementById('tbt').value="d";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="s";
	document.getElementById('tgt').value="s";
	document.getElementById('tht').innerHTML="h";
	document.getElementById('tht').value="h";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="o";
	document.getElementById('tjt').value="o";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "higad";



	}
	
	
	
	
	
	
	
		
	
		function ttquest111()
{

	document.getElementById('tquestiont').innerHTML="Isda ko sa tabang, pag nasa lupa ay gumagapang.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="h";
	document.getElementById('tjt').value="h";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "hito";



	}
	
	
	
		function ttquest112()
{

	document.getElementById('tquestiont').innerHTML="Ibon kong kay daldal-daldal, ginagaya lang ang inuusal.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="r";
	document.getElementById('tgt').value="r";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="o";
	document.getElementById('tjt').value="o";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "loro";



	}
	
	
	
	
		function ttquest113()
{

	document.getElementById('tquestiont').innerHTML="Hakot dito hakot doon, kahit maliit ay ipon ng ipon. ";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "langgam";



	}
	
	
	
	
		function ttquest114()
{

	document.getElementById('tquestiont').innerHTML="Pag munti'y may buntot, paglaki ay punggok. ";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "palaka";



	}
	
	
	
	
		function ttquest115()
{

	document.getElementById('tquestiont').innerHTML="Tumatanda na ang nuno, hindi pa rin naliligo. ";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="s";
	document.getElementById('tft').value="s";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pusa";



	}
	
	
	
	
		function ttquest116()
{

	document.getElementById('tquestiont').innerHTML="Narito na si pilo, sunong-sunong munting pulo. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pagong";



	}
	
	
	
	
		function ttquest117()
{

	document.getElementById('tquestiont').innerHTML="Kawangis niya'y tao, magaling manguto, mataas kung lumukso. ";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "unggoy";



	}
	
	
	
	
	function ttquest118()
{

	document.getElementById('tquestiont').innerHTML="Naghain na si Lolo, unang dumulog ay tukso.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="n";
	document.getElementById('tct').value="n";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "langaw";



	}
	
	
		function ttquest119()
{

	document.getElementById('tquestiont').innerHTML="Heto na si Ingkong, bubulong-bulong. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="y";
	document.getElementById('tet').value="y";
	document.getElementById('tft').innerHTML="o";
	document.getElementById('tft').value="o";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bubuyog";



	}

	
	

	
	function ttquest120()
{

	document.getElementById('tquestiont').innerHTML="Iisa na, kinuha pa. Ang natira ay dalawa.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="r";
	document.getElementById('tbt').value="r";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="s";
	document.getElementById('tgt').value="s";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="u";
	document.getElementById('tit').value="u";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "tulya";



	}
	
	
	
	
		
	
		
	
		function ttquest121()
{

	document.getElementById('tquestiont').innerHTML="Hindi naman bulag, di makakita sa liwanag. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="h";
	document.getElementById('tjt').value="h";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "paniki";



	}
	
	
	
		function ttquest122()
{

	document.getElementById('tquestiont').innerHTML="Maliit pa ang linsiyok, marunong nang manusok.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="k";
	document.getElementById('tft').value="k";
	document.getElementById('tgt').innerHTML="r";
	document.getElementById('tgt').value="r";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="o";
	document.getElementById('tjt').value="o";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "lamok";



	}
	
	
	
	
		function ttquest123()
{

	document.getElementById('tquestiont').innerHTML="Munting anghel na lilipad-lipad, dala-dala'y liwanag sa likod ng pakpak.  ";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="p";
	document.getElementById('tct').value="p";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="t";
	document.getElementById('tgt').value="t";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alitaptap";



	}
	
	
	
	
		function ttquest124()
{

	document.getElementById('tquestiont').innerHTML="Nakakalakad ako sa lupa, nakakalangoy din ako sa sapa, nakakalipad din ako ng kusa. ";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gansa";



	}
	
	
	
	
		function ttquest125()
{

	document.getElementById('tquestiont').innerHTML="Umuusad-usad sapagkat sa paa ay salat, pinahihirapan pa ng pasan-pasang bahay na ubod ng bigat. ";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kuhol";



	}
	
	
	
	
		function ttquest126()
{

	document.getElementById('tquestiont').innerHTML="Isang ting ting na kay tigas nang ikiskis ay nagdingas. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "palito";



	}
	
	
	
	
		function ttquest127()
{

	document.getElementById('tquestiont').innerHTML="Patpat ay biglang bumukadkad may hangin ang magandang dilag ";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pamaypay";



	}
	
	
	
	
	function ttquest128()
{

	document.getElementById('tquestiont').innerHTML="Pukpok dito, pukpok diyan, bakal na pinapantay matitigas na bisig na panghanapbuhay";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="n";
	document.getElementById('tct').value="n";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="d";
	document.getElementById('tet').value="d";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "panday";



	}
	
	
		function ttquest129()
{

	document.getElementById('tquestiont').innerHTML="Sariling- sarili mona, ginagamit pa ng iba";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pangalan";



	}

	
	

	
	function ttquest130()
{

	document.getElementById('tquestiont').innerHTML="Sa araw ay nahihimbing sa gabi ay gising ";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "paniki";



	}
	
	
	
	
	
			
	
		
	
		function ttquest131()
{

	document.getElementById('tquestiont').innerHTML="Bahay ko sa pandakan malapad ang harapan ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pantalan";



	}
	
	
	
		function ttquest132()
{

	document.getElementById('tquestiont').innerHTML="Maputing parang busilak, kalihim ko sa pagliyag";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="e";
	document.getElementById('tdt').value="e";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="p";
	document.getElementById('tft').value="p";
	document.getElementById('tgt').innerHTML="r";
	document.getElementById('tgt').value="r";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="p";
	document.getElementById('tjt').value="p";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "papel";



	}
	
	
	
	
		function ttquest133()
{

	document.getElementById('tquestiont').innerHTML="Hugis ay bituin papel na nagningning  ";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="p";
	document.getElementById('tct').value="p";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="r";
	document.getElementById('tgt').value="r";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "parol";



	}
	
	
	
	
		function ttquest134()
{

	document.getElementById('tquestiont').innerHTML="Bahay ng halaman nabubuhat kahit saan ";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "paso";



	}
	
	
	
	
		function ttquest135()
{

	document.getElementById('tquestiont').innerHTML="Kaisa-isang plato, kita sa buong Mundo. ";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="n";
	document.getElementById('tct').value="n";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="b";
	document.getElementById('tet').value="b";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "buwan";



	}
	
	
	
	
		function ttquest136()
{

	document.getElementById('tquestiont').innerHTML="Nagtago si Pedro, labas ang ulo. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pako";



	}
	
	
	
	
		function ttquest137()
{

	document.getElementById('tquestiont').innerHTML="Ate mo, ate ko, ate ng lahat ng tao";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="s";
	document.getElementById('tit').value="s";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "atis";



	}
	
	
	
	
	function ttquest138()
{

	document.getElementById('tquestiont').innerHTML="Hindi prinsesa, hindi reyna. Bakit may korona";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="d";
	document.getElementById('tet').value="d";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bayabas";



	}
	
	
		function ttquest139()
{

	document.getElementById('tquestiont').innerHTML="Nanganak ang birhen, itinapon ang lampin.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "saging";



	}

	
	

	
	function ttquest140()
{

	document.getElementById('tquestiont').innerHTML="Isang prinsesa, nakaupo sa tasa.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kasoy";



	}
	
	
	
	
				
	
		
	
		function ttquest141()
{

	document.getElementById('tquestiont').innerHTML="May langit, may lupa, May tubig, walang isda.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "niyog";



	}
	
	
	
		function ttquest142()
{

	document.getElementById('tquestiont').innerHTML="Ang alaga kong hugis bilog, barya-barya ang laman-loob.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alkansiya";



	}
	
	
	
	
		function ttquest143()
{

	document.getElementById('tquestiont').innerHTML="Ako ay may kaibigan, kasama ko kahit saan.";
	document.getElementById('tat').innerHTML="n";
	document.getElementById('tat').value="n";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="p";
	document.getElementById('tct').value="p";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "anino";



	}
	
	
	
	
		function ttquest144()
{

	document.getElementById('tquestiont').innerHTML="Palda ni Santa Maria. Ang kulay ay iba-iba.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="h";
	document.getElementById('tet').value="h";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bahaghari";



	}
	
	
	
	
		function ttquest145()
{

	document.getElementById('tquestiont').innerHTML="Sa araw ay bungbong, sa gabi ay dahon.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="n";
	document.getElementById('tct').value="n";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="b";
	document.getElementById('tet').value="b";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "banig";



	}
	
	
	
	
		function ttquest146()
{

	document.getElementById('tquestiont').innerHTML="Sa liwanag ay hindi mo makita. Sa dilim ay maliwanag sila.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bituin";



	}
	
	
	
	
		function ttquest147()
{

	document.getElementById('tquestiont').innerHTML="Hindi hari, hindi pari ang damit ay sari-sari";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="s";
	document.getElementById('tit').value="s";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sampayan";



	}
	
	
	
	
	function ttquest148()
{

	document.getElementById('tquestiont').innerHTML="May binti, walang hita, May tuktok, walang mukha.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="e";
	document.getElementById('tit').value="e";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kabute";



	}
	
	
		function ttquest149()
{

	document.getElementById('tquestiont').innerHTML="Bata pa si Nene, Marunong nang manahi";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gagamba";



	}

	
	

	
	function ttquest150()
{

	document.getElementById('tquestiont').innerHTML="Kung kailan pinatay, saka pa humaba ang buhay";
	document.getElementById('tat').innerHTML="l";
	document.getElementById('tat').value="l";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="d";
	document.getElementById('tet').value="d";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="k";
	document.getElementById('tgt').value="k";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kandila";



	}
	
	
	
	
		
	
		function ttquest151()
{

	document.getElementById('tquestiont').innerHTML="Bugtong-pala-bugtong, kadenang umuugong.";
	document.getElementById('tat').innerHTML="e";
	document.getElementById('tat').value="e";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="r";
	document.getElementById('tjt').value="r";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "tren";



	}
	
	
	
		function ttquest152()
{

	document.getElementById('tquestiont').innerHTML="Buhok ni Adan, hindi mabilang.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "ulan";



	}
	
	
	
	
		function ttquest153()
{

	document.getElementById('tquestiont').innerHTML="Bibingka ng hari, hindi mo mahati. ";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="u";
	document.getElementById('tjt').value="u";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "tubig";



	}
	
	
	
	
		function ttquest154()
{

	document.getElementById('tquestiont').innerHTML="Iisa ang pasukan, tatlo ang labasan.";
	document.getElementById('tat').innerHTML="m";
	document.getElementById('tat').value="m";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="h";
	document.getElementById('tet').value="h";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="d";
	document.getElementById('tgt').value="d";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "damit";



	}
	
	
	
	
		function ttquest155()
{

	document.getElementById('tquestiont').innerHTML="Malaking supot ni Mang Jacob, kung sisidlan ay pataob.";
	document.getElementById('tat').innerHTML="u";
	document.getElementById('tat').value="u";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="b";
	document.getElementById('tet').value="b";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kulambo";



	}
	
	
	
	
		function ttquest156()
{

	document.getElementById('tquestiont').innerHTML="Dalawang pipit nag titimbangan sa isang siit.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="w";
	document.getElementById('tdt').value="w";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="b";
	document.getElementById('tft').value="b";
	document.getElementById('tgt').innerHTML="h";
	document.getElementById('tgt').value="h";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "hikaw";



	}
	
	
	
	
		function ttquest157()
{

	document.getElementById('tquestiont').innerHTML="Nagdaan si Kabo Negro, namatay na lahat ang tao.";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="s";
	document.getElementById('tit').value="s";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gabi";



	}
	
	
	
	
	function ttquest158()
{

	document.getElementById('tquestiont').innerHTML="Ang alaga kong hugis bilog, barya-barya ang laman-loob.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="y";
	document.getElementById('tit').value="y";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alkansya";



	}
	
	
		function ttquest159()
{

	document.getElementById('tquestiont').innerHTML="Sa liwanag ay hindi mo makita. Sa dilim ay maliwanag sila.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bituin";



	}

	
	

	
	function ttquest160()
{

	document.getElementById('tquestiont').innerHTML="Nagsaing si Hudas, kinuha ang tubig itinapon ang bigas.";
	document.getElementById('tat').innerHTML="t";
	document.getElementById('tat').value="t";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="d";
	document.getElementById('tet').value="d";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gata";



	}
	
	
	
	
	
		
				
	
		
	
		function ttquest161()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni Tinyente nag-iisa ang poste.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="r";
	document.getElementById('tjt').value="r";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "payong";



	}
	
	
	
		function ttquest162()
{

	document.getElementById('tquestiont').innerHTML="Hiyas na puso, kulay ginto, mabango kung amuyin, masarap kung kainin.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="m";
	document.getElementById('tbt').value="m";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mangga";



	}
	
	
	
	
		function ttquest163()
{

	document.getElementById('tquestiont').innerHTML="Butong binalot ng bakal, bakal na binalot ng kristal.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="e";
	document.getElementById('tbt').value="e";
	document.getElementById('tct').innerHTML="l";
	document.getElementById('tct').value="l";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "lansones";



	}
	
	
	
	
		function ttquest164()
{

	document.getElementById('tquestiont').innerHTML="Nag tapis nang nag tapis nakalitaw ang bulbolis.";
	document.getElementById('tat').innerHTML="m";
	document.getElementById('tat').value="m";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="h";
	document.getElementById('tet').value="h";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="s";
	document.getElementById('tgt').value="s";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mais";



	}
	
	
	
	
		function ttquest165()
{

	document.getElementById('tquestiont').innerHTML="Aling pagkain sa mundo, ang nakalabas ang buto?";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="b";
	document.getElementById('tet').value="b";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kasoy";



	}
	
	
	
	
		function ttquest166()
{

	document.getElementById('tquestiont').innerHTML="Heto na si Ingkong, nakaupo sa lusong.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="w";
	document.getElementById('tdt').value="w";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="o";
	document.getElementById('tft').value="o";
	document.getElementById('tgt').innerHTML="h";
	document.getElementById('tgt').value="h";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kasoy";



	}
	
	
	
	
		function ttquest167()
{

	document.getElementById('tquestiont').innerHTML="Nakatalikod na ang prinsesa, mukha niya'y nakaharap pa.";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "balimbing";



	}
	
	
	
	
	function ttquest168()
{

	document.getElementById('tquestiont').innerHTML="Balat niya'y berde, buto niya'y itim,laman niya'y pula, sino siya?";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="y";
	document.getElementById('tit').value="y";
	document.getElementById('tjt').innerHTML="w";
	document.getElementById('tjt').value="w";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pakwan";



	}
	
	
		function ttquest169()
{

	document.getElementById('tquestiont').innerHTML="Kung tawagin nila'y santo, hindi naman milagroso.";
	document.getElementById('tat').innerHTML="l";
	document.getElementById('tat').value="l";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="g";
	document.getElementById('tdt').value="g";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "santol";



	}

	
	

	
	function ttquest170()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni Mang Pedro, punung-puno ng bato.";
	document.getElementById('tat').innerHTML="t";
	document.getElementById('tat').value="t";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="d";
	document.getElementById('tet').value="d";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="p";
	document.getElementById('tit').value="p";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "papaya";



	}
	
	
	
	
	
		
		
	
		function ttquest171()
{

	document.getElementById('tquestiont').innerHTML="Nakayuko ang reyna di nalalaglag ang korona.";
	document.getElementById('tat').innerHTML="b";
	document.getElementById('tat').value="b";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bayabas";



	}
	
	
	
		function ttquest172()
{

	document.getElementById('tquestiont').innerHTML="Kumpul-kumpol na uling, hayon at bibitin-bitin.";
	document.getElementById('tat').innerHTML="h";
	document.getElementById('tat').value="h";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="d";
	document.getElementById('tjt').value="d";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "duhat";



	}
	
	
	
	
		function ttquest173()
{

	document.getElementById('tquestiont').innerHTML="Bunga na ay namumunga pa.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="e";
	document.getElementById('tbt').value="e";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="u";
	document.getElementById('tit').value="u";
	document.getElementById('tjt').innerHTML="g";
	document.getElementById('tjt').value="g";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bunga";



	}
	
	
	
	
		function ttquest174()
{

	document.getElementById('tquestiont').innerHTML="Tiningnan nang tiningnan. Bago ito nginitian.";
	document.getElementById('tat').innerHTML="m";
	document.getElementById('tat').value="m";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="h";
	document.getElementById('tet').value="h";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="s";
	document.getElementById('tgt').value="s";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mais";



	}
	
	
	
	
		function ttquest175()
{

	document.getElementById('tquestiont').innerHTML="Isang magandang dalaga.‘Di mabilang ang mata.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pinya";



	}
	
	
	
	
		function ttquest176()
{

	document.getElementById('tquestiont').innerHTML="Dumaan ang hari, nagkagatan ang mga pari.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="p";
	document.getElementById('tdt').value="p";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="e";
	document.getElementById('tft').value="e";
	document.getElementById('tgt').innerHTML="h";
	document.getElementById('tgt').value="h";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="r";
	document.getElementById('tit').value="r";
	document.getElementById('tjt').innerHTML="z";
	document.getElementById('tjt').value="z";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "ziper";



	}
	
	
	
	
		function ttquest177()
{

	document.getElementById('tquestiont').innerHTML="Dalawang batong itim, malayo ang nararating.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mata";



	}
	
	
	
	
	function ttquest178()
{

	document.getElementById('tquestiont').innerHTML="Sa isang kalabit, may buhay na kapalit.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="b";
	document.getElementById('tdt').value="b";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "baril";



	}
	
	
		function ttquest179()
{

	document.getElementById('tquestiont').innerHTML="Buto't balat na malapad, kay galing kung lumipad.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sarangola";



	}

	
	

	
	function ttquest180()
{

	document.getElementById('tquestiont').innerHTML="Hinila ko ang baging, sumigaw ang matsing.";
	document.getElementById('tat').innerHTML="m";
	document.getElementById('tat').value="m";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kampana";



	}
	
	
	
	
	
		
	
		
		
	
		function ttquest181()
{

	document.getElementById('tquestiont').innerHTML="Puno ay buku-buko, Dahon ay abaniko, Bunga ay parasko Perdegones ang mga buto.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="p";
	document.getElementById('tft').value="p";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "papaya";



	}
	
	
	
		function ttquest182()
{

	document.getElementById('tquestiont').innerHTML="Hindi tao, hindi hayop, May tainga't may buhok.";
	document.getElementById('tat').innerHTML="m";
	document.getElementById('tat').value="m";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mais";



	}
	
	
	
	
		function ttquest183()
{

	document.getElementById('tquestiont').innerHTML="Ang dalawa'y tatlo na, ang maitim ay puti na, ang bakod ay lagas na.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="e";
	document.getElementById('tbt').value="e";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="d";
	document.getElementById('tit').value="d";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "matanda";



	}
	
	
	
	
		function ttquest184()
{

	document.getElementById('tquestiont').innerHTML="Pantas ka man at maalam, Angkan ka ng mga paham Turan mo kung ano.";
	document.getElementById('tat').innerHTML="m";
	document.getElementById('tat').value="m";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="s";
	document.getElementById('tgt').value="s";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "plantsa";



	}
	
	
	
	
		function ttquest185()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni Ligaya nalilibot ng mata.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pinya";



	}
	
	
	
	
		function ttquest186()
{

	document.getElementById('tquestiont').innerHTML="Maitim na parang uwak Maputing parang busilak, Walang paa'y nakalalakad At sa hari'y nakikipag-usap.";
	document.getElementById('tat').innerHTML="h";
	document.getElementById('tat').value="h";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="m";
	document.getElementById('tct').value="m";
	document.getElementById('tdt').innerHTML="p";
	document.getElementById('tdt').value="p";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="e";
	document.getElementById('tft').value="e";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="u";
	document.getElementById('tht').value="u";
	document.getElementById('tit').innerHTML="r";
	document.getElementById('tit').value="r";
	document.getElementById('tjt').innerHTML="z";
	document.getElementById('tjt').value="z";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "liham";



	}
	
	
	
	
		function ttquest187()
{

	document.getElementById('tquestiont').innerHTML="Bumuka'y walang bibig Ngumingiti nang tahimik.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="l";
	document.getElementById('tbt').value="l";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="k";
	document.getElementById('tet').value="k";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bulaklak";



	}
	
	
	
	
	function ttquest188()
{

	document.getElementById('tquestiont').innerHTML="Isda ko sa Mariveles Nasa loob ang kaliskis.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="m";
	document.getElementById('tit').value="m";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alimango";



	}
	
	
		function ttquest189()
{

	document.getElementById('tquestiont').innerHTML="Oo nga't alimango Nasa loob ang ulo.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="p";
	document.getElementById('tdt').value="p";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pagong";



	}

	
	

	
	function ttquest190()
{

	document.getElementById('tquestiont').innerHTML="Oo nga't pagong Tubig ay iniinom.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "niyog";



	}
	
	
	
	
	
		
	
		
		
	
		function ttquest191()
{

	document.getElementById('tquestiont').innerHTML="Oo nga't niyog Nasa loob ang bunot.";
	document.getElementById('tat').innerHTML="m";
	document.getElementById('tat').value="m";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="g";
	document.getElementById('tft').value="g";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="b";
	document.getElementById('tjt').value="b";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mangga";



	}
	
	
	
		function ttquest192()
{

	document.getElementById('tquestiont').innerHTML="Oo nga't mangga Kay daming mga mata.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pinya";



	}
	
	
	
	
		function ttquest193()
{

	document.getElementById('tquestiont').innerHTML="Puno'y layu-layo Dulo'y tagpu-tagpo.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="e";
	document.getElementById('tbt').value="e";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="t";
	document.getElementById('tet').value="t";
	document.getElementById('tft').innerHTML="y";
	document.getElementById('tft').value="y";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="d";
	document.getElementById('tit').value="d";
	document.getElementById('tjt').innerHTML="h";
	document.getElementById('tjt').value="h";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "bahay";



	}
	
	
	
	
		function ttquest194()
{

	document.getElementById('tquestiont').innerHTML="Nakaluluto'y walang init, Umaaso kahi't malamig.";
	document.getElementById('tat').innerHTML="e";
	document.getElementById('tat').value="e";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="s";
	document.getElementById('tgt').value="s";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="y";
	document.getElementById('tit').value="y";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "yelo";



	}
	
	
	
	
		function ttquest195()
{

	document.getElementById('tquestiont').innerHTML="Hindi tao, hindi ibon Bumabalik kung itapon.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="o";
	document.getElementById('tet').value="o";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="k";
	document.getElementById('tit').value="k";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "yoyo";



	}
	
	
	
	
		function ttquest196()
{

	document.getElementById('tquestiont').innerHTML="Eto na si bayaw Dala-dala'y ilaw.";
	document.getElementById('tat').innerHTML="t";
	document.getElementById('tat').value="t";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="m";
	document.getElementById('tct').value="m";
	document.getElementById('tdt').innerHTML="p";
	document.getElementById('tdt').value="p";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "alitaptap";



	}
	
	
	
	
		function ttquest197()
{

	document.getElementById('tquestiont').innerHTML="Eto na si Kaka May sunong na dampa.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="p";
	document.getElementById('tjt').value="p";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pagong";



	}
	
	
	
	
	function ttquest198()
{

	document.getElementById('tquestiont').innerHTML="Bahay ni Goring-goring Butas-butas ang dingding.";
	document.getElementById('tat').innerHTML="k";
	document.getElementById('tat').value="k";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="m";
	document.getElementById('tit').value="m";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kulambo";



	}
	
	
		function ttquest199()
{

	document.getElementById('tquestiont').innerHTML="Alin sa mga ibon ang di makadapo sa kahoy?";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="g";
	document.getElementById('tbt').value="g";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="p";
	document.getElementById('tdt').value="p";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pugo";



	}

	
	

	
	function ttquest200()
{

	document.getElementById('tquestiont').innerHTML="Gintong binalot sa pilak Pilak na binalot sa balat.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="n";
	document.getElementById('tet').value="n";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "itlog";



	}
	
	
	
	
	
	
		
	
		function ttquest201()
{

	document.getElementById('tquestiont').innerHTML="Mga kaloobang pinaghalu-halo na niluto sa init ng pagkakasundo.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="u";
	document.getElementById('tgt').value="u";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="d";
	document.getElementById('tjt').value="d";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "dinuguan";



	}
	
	
	
		function ttquest202()
{

	document.getElementById('tquestiont').innerHTML="Di naman isda, di naman itik Nakahuhuni kung ibig maging sa kati, maging sa tubig ang huni'y nakabubuwisit.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="l";
	document.getElementById('tdt').value="l";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "palaka";



	}
	
	
	
	
		function ttquest203()
{

	document.getElementById('tquestiont').innerHTML="May puno walang sanga May dahon, walang bunga.";
	document.getElementById('tat').innerHTML="o";
	document.getElementById('tat').value="o";
	document.getElementById('tbt').innerHTML="k";
	document.getElementById('tbt').value="k";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="y";
	document.getElementById('tft').value="y";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="d";
	document.getElementById('tit').value="d";
	document.getElementById('tjt').innerHTML="h";
	document.getElementById('tjt').value="h";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sandok";



	}
	
	
	
	
		function ttquest204()
{

	document.getElementById('tquestiont').innerHTML="Walang itak, walang kampit Gumagawa ng bahay na ipit.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="b";
	document.getElementById('tit').value="b";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "gagamba";



	}
	
	
	
	
		function ttquest205()
{

	document.getElementById('tquestiont').innerHTML="Lumalakad walang paa Lumuluha walang mata.";
	document.getElementById('tat').innerHTML="u";
	document.getElementById('tat').value="u";
	document.getElementById('tbt').innerHTML="w";
	document.getElementById('tbt').value="w";
	document.getElementById('tct').innerHTML="m";
	document.getElementById('tct').value="m";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="o";
	document.getElementById('tet').value="o";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="p";
	document.getElementById('tit').value="p";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pluma";



	}
	
	
	
	
		function ttquest206()
{

	document.getElementById('tquestiont').innerHTML="Dahong pinagbungahan, Bungang pinagdahunan.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="p";
	document.getElementById('tdt').value="p";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="p";
	document.getElementById('tht').value="p";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pinya";



	}
	
	
	
	
		function ttquest207()
{

	document.getElementById('tquestiont').innerHTML="Heto na si kurdapya may sunong na baga.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "manok";



	}
	
	
	
	
	function ttquest208()
{

	document.getElementById('tquestiont').innerHTML="Isdang parang ahas, sa karagatan pumapagaspas.";
	document.getElementById('tat').innerHTML="t";
	document.getElementById('tat').value="t";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="u";
	document.getElementById('tft').value="u";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "igat";



	}
	
	
		function ttquest209()
{

	document.getElementById('tquestiont').innerHTML="May alaga akong hayop, malaki ang mata kaysa tuhod.";
	document.getElementById('tat').innerHTML="u";
	document.getElementById('tat').value="u";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="p";
	document.getElementById('tdt').value="p";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "tutubi";



	}

	
	

	
	function ttquest210()
{

	document.getElementById('tquestiont').innerHTML="Anong insekto sa mundo na naglalakad na walang buto.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "uod";



	}
	
	
	
	
		
		
	
		function ttquest211()
{

	document.getElementById('tquestiont').innerHTML="Pinisa ko at pinirot bago sininghot.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="s";
	document.getElementById('tft').value="s";
	document.getElementById('tgt').innerHTML="u";
	document.getElementById('tgt').value="u";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="t";
	document.getElementById('tit').value="t";
	document.getElementById('tjt').innerHTML="o";
	document.getElementById('tjt').value="o";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "surot";



	}
	
	
	
		function ttquest212()
{

	document.getElementById('tquestiont').innerHTML="Koronang mapula ay katulad nito lagi nang nakakabit sa ulo.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="l";
	document.getElementById('tdt').value="l";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="o";
	document.getElementById('tit').value="o";
	document.getElementById('tjt').innerHTML="y";
	document.getElementById('tjt').value="y";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "palong";



	}
	
	
	
	
		function ttquest213()
{

	document.getElementById('tquestiont').innerHTML="May puno walang sanga May dahon, walang bunga.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "pamingwit";



	}
	
	
	
	
		function ttquest214()
{

	document.getElementById('tquestiont').innerHTML="Dumating si Canuto, nangabuhay ang mga tao.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="u";
	document.getElementById('tit').value="u";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "umaga";



	}
	
	
	
	
		function ttquest215()
{

	document.getElementById('tquestiont').innerHTML="Kung araw ay patung-patong, kung gabi'y dugtong-dugtong.";
	document.getElementById('tat').innerHTML="u";
	document.getElementById('tat').value="u";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="m";
	document.getElementById('tct').value="m";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="o";
	document.getElementById('tet').value="o";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "unan";



	}
	
	
	
	
		function ttquest216()
{

	document.getElementById('tquestiont').innerHTML="Isang hukbong sundalo, dikit-dikit ang mga ulo,";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="w";
	document.getElementById('tdt').value="w";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "walis";



	}
	
	
	
	
		function ttquest217()
{

	document.getElementById('tquestiont').innerHTML="Dumaing paa'y walang kamay, may pamigkis sa baywang, ang ulo'y parang tagayan, alagad ng kalinisan.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "walis";



	}
	
	
	
	
	function ttquest218()
{

	document.getElementById('tquestiont').innerHTML="Kung tingna'y mainit, hipui'y malamig, umuusok ang paligid.";
	document.getElementById('tat').innerHTML="e";
	document.getElementById('tat').value="e";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="y";
	document.getElementById('tft').value="y";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="g";
	document.getElementById('tit').value="g";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "yelo";



	}
	
	
		function ttquest219()
{

	document.getElementById('tquestiont').innerHTML="Mayroon akong dalawang balon, hindi ko malingon.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="p";
	document.getElementById('tdt').value="p";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="t";
	document.getElementById('tht').value="t";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="t";
	document.getElementById('tjt').value="t";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "tainga";



	}

	
	

	
	function ttquest220()
{

	document.getElementById('tquestiont').innerHTML="Nang tangan ko'y patay, nang itapon ko'y nabuhay.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="r";
	document.getElementById('tit').value="r";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "trumpo";



	}
	
	
	
	
	
	
			
		
	
		function ttquest221()
{

	document.getElementById('tquestiont').innerHTML="Binalangkas ko nang binalangkas, bago ko inihampas.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="u";
	document.getElementById('tgt').value="u";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="t";
	document.getElementById('tit').value="t";
	document.getElementById('tjt').innerHTML="o";
	document.getElementById('tjt').value="o";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "trumpo";



	}
	
	
	
		function ttquest222()
{

	document.getElementById('tquestiont').innerHTML="Munting tumataginting, kung saan nanggagaling.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="l";
	document.getElementById('tdt').value="l";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="e";
	document.getElementById('tgt').value="e";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="o";
	document.getElementById('tit').value="o";
	document.getElementById('tjt').innerHTML="e";
	document.getElementById('tjt').value="e";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "telepono";



	}
	
	
	
	
		function ttquest223()
{

	document.getElementById('tquestiont').innerHTML="Puno na naging tubig, tubig na naging bato, bato na kinain ng tao.";
	document.getElementById('tat').innerHTML="u";
	document.getElementById('tat').value="u";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="b";
	document.getElementById('tct').value="b";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="t";
	document.getElementById('tft').value="t";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="m";
	document.getElementById('tjt').value="m";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "tubo";



	}
	
	
	
	
		function ttquest224()
{

	document.getElementById('tquestiont').innerHTML="Ang ibabaw ay tawiran, ang ilalim ay lusutan.";
	document.getElementById('tat').innerHTML="y";
	document.getElementById('tat').value="y";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="l";
	document.getElementById('tht').value="l";
	document.getElementById('tit').innerHTML="u";
	document.getElementById('tit').value="u";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "tulay";



	}
	
	
	
	
		function ttquest225()
{

	document.getElementById('tquestiont').innerHTML="Bulaklak muna ang dapat gawin, bago mo ito kanin. ";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="m";
	document.getElementById('tct').value="m";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "saging";



	}
	
	
	
	
		function ttquest226()
{

	document.getElementById('tquestiont').innerHTML="Sapagkat lahat na ay nakahihipo, walang kasindumi't walang kasimbaho, bakit mahal nati't ipinakatatago.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="w";
	document.getElementById('tdt').value="w";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "salapi";



	}
	
	
	
	
		function ttquest227()
{

	document.getElementById('tquestiont').innerHTML="Aling mabuting retrato ang kuhang-kuha sa mukha mo? ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "salamin";



	}
	
	
	
	
	function ttquest228()
{

	document.getElementById('tquestiont').innerHTML="Sinampal ko muna bago inalok.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="k";
	document.getElementById('tft').value="k";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="m";
	document.getElementById('tit').value="m";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sampalok";



	}
	
	
		function ttquest229()
{

	document.getElementById('tquestiont').innerHTML="Ang ulo'y nalalaga ang katawa'y pagala-gala.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="o";
	document.getElementById('tit').value="o";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sandok";



	}

	
	

	
	function ttquest230()
{

	document.getElementById('tquestiont').innerHTML="Alipin ng hari, hindi makalakad, kung hindi itali.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="p";
	document.getElementById('tbt').value="p";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="a";
	document.getElementById('tit').value="a";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sapatos";



	}
	
	
	
	
	
				
		
	
		function ttquest231()
{

	document.getElementById('tquestiont').innerHTML="Baboy ko sa parang, namumula sa tapang.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="u";
	document.getElementById('tgt').value="u";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="l";
	document.getElementById('tjt').value="l";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sili";



	}
	
	
	
		function ttquest232()
{

	document.getElementById('tquestiont').innerHTML="Munting tampipi puno ng salapi.";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="l";
	document.getElementById('tdt').value="l";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="i";
	document.getElementById('tgt').value="i";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="o";
	document.getElementById('tit').value="o";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sili";



	}
	
	
	
	
		function ttquest233()
{

	document.getElementById('tquestiont').innerHTML="Isang lupa-lupaan sa dulo ng kawayan.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="y";
	document.getElementById('tft').value="y";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sigarilyo";



	}
	
	
	
	
		function ttquest234()
{

	document.getElementById('tquestiont').innerHTML="Hiyas akong mabilog, sa daliri isinusuot.";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="g";
	document.getElementById('tht').value="g";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "singsing";



	}
	
	
	
	
		function ttquest235()
{

	document.getElementById('tquestiont').innerHTML="Buklod na tinampukan, saksi ng pag-iibigan.";
	document.getElementById('tat').innerHTML="g";
	document.getElementById('tat').value="g";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="m";
	document.getElementById('tct').value="m";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "singsing";



	}
	
	
	
	
		function ttquest236()
{

	document.getElementById('tquestiont').innerHTML="Ipinalilok ko at ipinalubid, nang higpitan ang kapit.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="n";
	document.getElementById('tgt').value="n";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="t";
	document.getElementById('tit').value="t";
	document.getElementById('tjt').innerHTML="u";
	document.getElementById('tjt').value="u";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sinturon";



	}
	
	
	
	
		function ttquest237()
{

	document.getElementById('tquestiont').innerHTML="Nang munti pa ay paruparo, nang lumaki ay latigo.";
	document.getElementById('tat').innerHTML="t";
	document.getElementById('tat').value="t";
	document.getElementById('tbt').innerHTML="s";
	document.getElementById('tbt').value="s";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="m";
	document.getElementById('tgt').value="m";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="i";
	document.getElementById('tjt').value="i";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sitaw";



	}
	
	
	
	
	function ttquest238()
{

	document.getElementById('tquestiont').innerHTML="Bumili ako ng alipin, mataas pa sa akin.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="s";
	document.getElementById('tct').value="s";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="r";
	document.getElementById('tft').value="r";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="b";
	document.getElementById('tht').value="b";
	document.getElementById('tit').innerHTML="m";
	document.getElementById('tit').value="m";
	document.getElementById('tjt').innerHTML="e";
	document.getElementById('tjt').value="e";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sumbrero";



	}
	
	
		function ttquest239()
{

	document.getElementById('tquestiont').innerHTML="Isang tabo, laman ay pako.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="s";
	document.getElementById('tdt').value="s";
	document.getElementById('tet').innerHTML="u";
	document.getElementById('tet').value="u";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="h";
	document.getElementById('tit').value="h";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "suha";



	}

	
	

	
	function ttquest240()
{

	document.getElementById('tquestiont').innerHTML="Isang panyong parisukat, kung buksa'y nakakausap.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "sulat";



	}
	
	
	
	
	
					
		
	
		function ttquest241()
{

	document.getElementById('tquestiont').innerHTML="Dalawang magkaibigan, habulan nang habulan. ";
	document.getElementById('tat').innerHTML="s";
	document.getElementById('tat').value="s";
	document.getElementById('tbt').innerHTML="i";
	document.getElementById('tbt').value="i";
	document.getElementById('tct').innerHTML="u";
	document.getElementById('tct').value="u";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="p";
	document.getElementById('tet').value="p";
	document.getElementById('tft').innerHTML="m";
	document.getElementById('tft').value="m";
	document.getElementById('tgt').innerHTML="u";
	document.getElementById('tgt').value="u";
	document.getElementById('tht').innerHTML="y";
	document.getElementById('tht').value="y";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="a";
	document.getElementById('tjt').value="a";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "paa";



	}
	
	
	
		function ttquest242()
{

	document.getElementById('tquestiont').innerHTML="May ulo'y walang mukha, may katawa'y walang sikmura. Namamahay ng sadya. ";
	document.getElementById('tat').innerHTML="i";
	document.getElementById('tat').value="i";
	document.getElementById('tbt').innerHTML="t";
	document.getElementById('tbt').value="t";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="l";
	document.getElementById('tdt').value="l";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="i";
	document.getElementById('tgt').value="i";
	document.getElementById('tht').innerHTML="k";
	document.getElementById('tht').value="k";
	document.getElementById('tit').innerHTML="o";
	document.getElementById('tit').value="o";
	document.getElementById('tjt').innerHTML="p";
	document.getElementById('tjt').value="p";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "palito";



	}
	
	
	
	
		function ttquest243()
{

	document.getElementById('tquestiont').innerHTML="Binatak ko ang isa, pawis ang kasama.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="n";
	document.getElementById('tbt').value="n";
	document.getElementById('tct').innerHTML="r";
	document.getElementById('tct').value="r";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="y";
	document.getElementById('tft').value="y";
	document.getElementById('tgt').innerHTML="o";
	document.getElementById('tgt').value="o";
	document.getElementById('tht').innerHTML="i";
	document.getElementById('tht').value="i";
	document.getElementById('tit').innerHTML="w";
	document.getElementById('tit').value="w";
	document.getElementById('tjt').innerHTML="s";
	document.getElementById('tjt').value="s";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "panyo";



	}
	
	
	
	
		function ttquest244()
{

	document.getElementById('tquestiont').innerHTML="Ang puno'y buku-buko,ang sanga'y baril, ang bunga'y bote, ang laman ay diyamante.";
	document.getElementById('tat').innerHTML="p";
	document.getElementById('tat').value="p";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="g";
	document.getElementById('tct').value="g";
	document.getElementById('tdt').innerHTML="n";
	document.getElementById('tdt').value="n";
	document.getElementById('tet').innerHTML="a";
	document.getElementById('tet').value="a";
	document.getElementById('tft').innerHTML="h";
	document.getElementById('tft').value="h";
	document.getElementById('tgt').innerHTML="y";
	document.getElementById('tgt').value="y";
	document.getElementById('tht').innerHTML="a";
	document.getElementById('tht').value="a";
	document.getElementById('tit').innerHTML="i";
	document.getElementById('tit').value="i";
	document.getElementById('tjt').innerHTML="p";
	document.getElementById('tjt').value="p";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "papaya";



	}
	
	
	
	
		function ttquest245()
{

	document.getElementById('tquestiont').innerHTML="Ang labas ay tabla-tabla ang loob ay sala-sala.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="t";
	document.getElementById('tct').value="t";
	document.getElementById('tdt').innerHTML="i";
	document.getElementById('tdt').value="i";
	document.getElementById('tet').innerHTML="g";
	document.getElementById('tet').value="g";
	document.getElementById('tft').innerHTML="i";
	document.getElementById('tft').value="i";
	document.getElementById('tgt').innerHTML="l";
	document.getElementById('tgt').value="l";
	document.getElementById('tht').innerHTML="o";
	document.getElementById('tht').value="o";
	document.getElementById('tit').innerHTML="n";
	document.getElementById('tit').value="n";
	document.getElementById('tjt').innerHTML="p";
	document.getElementById('tjt').value="p";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "patola";



	}
	
	
	
	
		function ttquest246()
{

	document.getElementById('tquestiont').innerHTML="Dalawang bolang sinulid, abot hanggang langit. ";
	document.getElementById('tat').innerHTML="m";
	document.getElementById('tat').value="m";
	document.getElementById('tbt').innerHTML="o";
	document.getElementById('tbt').value="o";
	document.getElementById('tct').innerHTML="y";
	document.getElementById('tct').value="y";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="i";
	document.getElementById('tet').value="i";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="s";
	document.getElementById('tht').value="s";
	document.getElementById('tit').innerHTML="t";
	document.getElementById('tit').value="t";
	document.getElementById('tjt').innerHTML="u";
	document.getElementById('tjt').value="u";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "mata";



	}
	
	
	
	
		function ttquest247()
{

	document.getElementById('tquestiont').innerHTML="Araw araw bagong buhay, Taun-taon namamatay. ";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="y";
	document.getElementById('tbt').value="y";
	document.getElementById('tct').innerHTML="o";
	document.getElementById('tct').value="o";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="r";
	document.getElementById('tet').value="r";
	document.getElementById('tft').innerHTML="l";
	document.getElementById('tft').value="l";
	document.getElementById('tgt').innerHTML="e";
	document.getElementById('tgt').value="e";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="d";
	document.getElementById('tit').value="d";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kalendaryo";



	}
	
	
	
	
	function ttquest248()
{

	document.getElementById('tquestiont').innerHTML="Ako'y aklat ng panahon, Binabago taun taon.";
	document.getElementById('tat').innerHTML="r";
	document.getElementById('tat').value="r";
	document.getElementById('tbt').innerHTML="a";
	document.getElementById('tbt').value="a";
	document.getElementById('tct').innerHTML="k";
	document.getElementById('tct').value="k";
	document.getElementById('tdt').innerHTML="o";
	document.getElementById('tdt').value="o";
	document.getElementById('tet').innerHTML="y";
	document.getElementById('tet').value="y";
	document.getElementById('tft').innerHTML="d";
	document.getElementById('tft').value="d";
	document.getElementById('tgt').innerHTML="a";
	document.getElementById('tgt').value="a";
	document.getElementById('tht').innerHTML="n";
	document.getElementById('tht').value="n";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="e";
	document.getElementById('tjt').value="e";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kalendaryo";



	}
	
	
		function ttquest249()
{

	document.getElementById('tquestiont').innerHTML="May katawan walang mukha, walang mata'y lumuluha.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="b";
	document.getElementById('tbt').value="b";
	document.getElementById('tct').innerHTML="i";
	document.getElementById('tct').value="i";
	document.getElementById('tdt').innerHTML="a";
	document.getElementById('tdt').value="a";
	document.getElementById('tet').innerHTML="l";
	document.getElementById('tet').value="l";
	document.getElementById('tft').innerHTML="n";
	document.getElementById('tft').value="n";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="h";
	document.getElementById('tit').value="h";
	document.getElementById('tjt').innerHTML="k";
	document.getElementById('tjt').value="k";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "kandila";



	}

	
	

	
	function ttquest250()
{

	document.getElementById('tquestiont').innerHTML="Dalawang katawan, tagusan ang tadyang.";
	document.getElementById('tat').innerHTML="a";
	document.getElementById('tat').value="a";
	document.getElementById('tbt').innerHTML="u";
	document.getElementById('tbt').value="u";
	document.getElementById('tct').innerHTML="n";
	document.getElementById('tct').value="n";
	document.getElementById('tdt').innerHTML="t";
	document.getElementById('tdt').value="t";
	document.getElementById('tet').innerHTML="s";
	document.getElementById('tet').value="s";
	document.getElementById('tft').innerHTML="a";
	document.getElementById('tft').value="a";
	document.getElementById('tgt').innerHTML="g";
	document.getElementById('tgt').value="g";
	document.getElementById('tht').innerHTML="d";
	document.getElementById('tht').value="d";
	document.getElementById('tit').innerHTML="l";
	document.getElementById('tit').value="l";
	document.getElementById('tjt').innerHTML="h";
	document.getElementById('tjt').value="h";	
	document.getElementById("tnumerot").innerHTML = "riddle no: " + tnumbt;

tright_anst = "hagdan";



	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function tsubmitt()
{


 

if(tsagott==tright_anst)
{
tscoret++;
tnumbt++;

document.getElementById("tscoret").innerHTML = "score: " + tscoret;
document.getElementById("tanst").innerHTML = "";
alert("You are Correct!!!");


tpt++;
tsagott = "";

if(tnumbt>250)
{
document.getElementById("tsubmitt").href = "#twinner_t_u";

document.getElementById("tfscore_t_u").innerHTML = "score: " + tscoret;
}

else{
tstart_t_u();}
}
else
{

alert("You are Wrong!!!");


document.getElementById("tscoret").innerHTML = "score: " + tscoret;
document.getElementById("tanst").innerHTML = "";

if(lifet == 0)
{

document.getElementById("tsubmitt").href = "#texit_t_u";

document.getElementById("tgftscoret_t_u").innerHTML = "score: " + tscoret;

}


else{
tnumbt++;

tpt++;

tsagott = "";

if(tnumbt>250)
{
document.getElementById("tsubmitt").href = "#twinner_t_u";

document.getElementById("tfscore_t_u").innerHTML = "score: " + tscoret;
}


tstart_t_u();
}

}

changeColor5();
}





function times2()
{
document.getElementById('tlifet').innerHTML=m2+":"+s2+" remaining";
s2--;
q2=setTimeout("times2()", 1000);
if (s2<0)
{ m2=m2-1; s2=59;}

if (m2<0)
{
timesstop2();
}
}
function timesstop2()
{
clearTimeout(q2);
s2=0;
m2=0;
document.getElementById('tlifet').innerHTML=" ";
tright_anst = "" ;
tsagott = "";

$("#try2,#tquestiont,#tanst,#tat,#tbt,#tct,#tdt,#tet,#tft,#tgt,#tht,#tit,#tjt").hide();
		$("#tsubmitt,#tresett").hide();
	document.getElementById('tgfscore_t_u').innerHTML="score: " + tscoret;

	$("#tgameover").show();
	
}


	
	function tbalik()
{
$("#try2").show();
$("#tquestiont,#tanst,#tat,#tbt,#tct,#tdt,#tet,#tft,#tgt,#tht,#tit,#tjt").show();
		$("#tsubmitt,#tresett").show();

	$("#tgameover").hide();


	
document.getElementById('tgfscore_t_u').innerHTML="score: " + tscoret;
	

}




function tgokay_t_u()
{

tpt = 1 ;
tanst = "" ;
tsagott = "";
tright_anst = "" ;
tscoret = 0;
tnumbt = 1;
s2 = 59;
m2 = 9;	
q2;




}

